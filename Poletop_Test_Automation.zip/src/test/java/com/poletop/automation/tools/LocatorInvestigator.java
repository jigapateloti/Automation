package com.poletop.automation.tools;

import com.test.automation.sdk.tools.AbstractLocatorInvestigator;
import com.poletop.automation.uiActions.PoletopDashboardPage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * LocatorInvestigator — Poletop-specific crawler entry point.
 *
 * All infrastructure (single session, fail-fast login, role blacklist,
 * nav helpers, crawl summary) is provided by AbstractLocatorInvestigator in the SDK.
 *
 * Roles:
 *   admin      — -Dinv.email / -Dinv.password
 *   franchisee — -Dinv.franchisee.email / -Dinv.franchisee.password
 *
 * Run (full crawl):
 *   mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml
 *            -Denvironment=stg -DbrowserName=chrome
 *            -Dinv.email=admin@example.com -Dinv.password=secret
 *            -Dinv.franchisee.email=franchisee@example.com
 *            -Dinv.franchisee.password=secret
 *            -Dinv.page=all
 *
 * Supported -Dinv.page values:
 *   login | dashboard | checkLocation | resdetails | enrollment | all (default)
 */
public class LocatorInvestigator extends AbstractLocatorInvestigator {

    // -------------------------------------------------------------------------
    // Roles — admin + franchisee
    // -------------------------------------------------------------------------

    @Override
    protected void registerRoles() {
        registerRole("admin",
            System.getProperty("inv.email",                ""),
            System.getProperty("inv.password",             ""));
        registerRole("franchisee",
            System.getProperty("inv.franchisee.email",
                System.getProperty("inv.email",    "")),
            System.getProperty("inv.franchisee.password",
                System.getProperty("inv.password", "")));
    }

    // -------------------------------------------------------------------------
    // Login — Poletop uses PoletopDashboardPage.login()
    // -------------------------------------------------------------------------

    @Override
    protected void performLogin(String email, String password) throws Exception {
        PoletopDashboardPage dashPage = new PoletopDashboardPage(driver);
        dashPage.login(email, password);
    }

    // -------------------------------------------------------------------------
    // Session check — global search bar is only visible when logged in
    // -------------------------------------------------------------------------

    @Override
    protected boolean isSessionAlive() {
        return !driver.findElements(
            By.xpath("//input[@id='global-search-bar']")).isEmpty();
    }

    @Override
    protected String getPostLoginLandmark() {
        return "//input[@id='global-search-bar']";
    }

    // -------------------------------------------------------------------------
    // Crawl steps
    // -------------------------------------------------------------------------

    @Override
    protected void defineCrawlSteps() throws Exception {

        // Pre-auth: login page (no credentials needed)
        if (!shouldSkip("login")) {
            driver.get(baseURL);
            crawler.waitForPageReady();
            crawlPage("login", "PoletopLoginPage");
        }

        // Admin role pages
        if (!shouldSkip("dashboard", "checkLocation", "checklocation",
                        "resdetails", "reservationdetails", "construction")) {

            if (loginAs("admin")) {
                logNavStructure("//*[@id='nav-primary']");

                crawlPage("dashboard", "PoletopDashboardPage");

                if (!shouldSkip("checkLocation", "checklocation")) {
                    if (openNavDropdownAndClick("nav-item-02", "Check Location")) {
                        crawlPage("checkLocation", "PoletopCheckLocationPage");
                    } else {
                        skipped.add("PoletopCheckLocationPage");
                    }
                } else {
                    skipped.add("PoletopCheckLocationPage");
                }

                if (!shouldSkip("resdetails", "reservationdetails", "construction")) {
                    driver.get(baseURL);
                    crawler.waitForPageReady();
                    String resNumber = System.getProperty("inv.reservationNumber", "");
                    if (!resNumber.isEmpty()) {
                        log.info("=== Crawling: Reservation Details (res=" + resNumber + ") ===");
                        WebElement searchBar = new WebDriverWait(driver, Duration.ofSeconds(15))
                            .until(ExpectedConditions.elementToBeClickable(
                                By.xpath("//input[@id='global-search-bar']")));
                        searchBar.clear();
                        searchBar.sendKeys(resNumber, Keys.ENTER);
                        new WebDriverWait(driver, Duration.ofSeconds(15))
                            .until(ExpectedConditions.urlContains(resNumber));
                        crawler.waitForPageReady();
                        crawlPage("resdetails", "PoletopReservationDetailsPage");
                        if (clickStep(By.xpath("//button[normalize-space(.)='Start Construction']"),
                                "Start Construction")) {
                            crawlPage("construction", "PoletopStartConstructionForm");
                        }
                    } else {
                        log.warn("No -Dinv.reservationNumber — skipping Reservation Details");
                        skipped.add("PoletopReservationDetailsPage");
                    }
                } else {
                    skipped.add("PoletopReservationDetailsPage");
                }

            } else {
                skipped.add("PoletopDashboardPage");
                skipped.add("PoletopCheckLocationPage");
                skipped.add("PoletopReservationDetailsPage");
            }
        }

        // Franchisee role pages
        if (!shouldSkip("enrollment", "enroll", "reservation")) {
            if (loginAs("franchisee")) {
                // Log full franchisee nav so we can see what nav-item-02 links to
                logNavStructure("//*[@id='nav-primary']");

                // nav-item-02 is likely "New Reservation" for franchisee — confirm from logNavStructure output above
                // If nav-item-02 is not correct, supply the direct URL via -Dinv.enrollUrl
                boolean reached = openNavDropdownAndClick("nav-item-02", "New Reservation");
                if (!reached) reached = openNavDropdownAndClick("nav-item-01", "New Reservation");
                if (!reached || driver.getCurrentUrl().contains("/dashboard")) {
                    String enrollUrl = System.getProperty("inv.enrollUrl", "");
                    if (!enrollUrl.isEmpty()) {
                        log.info("Nav navigation failed — using direct URL: " + enrollUrl);
                        driver.get(enrollUrl);
                        crawler.waitForPageReady();
                        reached = !driver.getCurrentUrl().contains("/dashboard");
                    } else {
                        log.warn("=== ACTION REQUIRED: Check logNavStructure output above to find the correct nav path for enrollment. ===");
                        log.warn("=== Then re-run with: -Dinv.enrollUrl=<actual URL from browser after clicking New Reservation> ===");
                        reached = false;
                    }
                }
                if (reached && !driver.getCurrentUrl().contains("/dashboard")) {
                    crawlPage("enrollment", "PoletopEnrollmentPage");
                } else {
                    skipped.add("PoletopEnrollmentPage");
                }
            } else {
                skipped.add("PoletopEnrollmentPage");
            }
        } else {
            skipped.add("PoletopEnrollmentPage");
        }
    }
}
