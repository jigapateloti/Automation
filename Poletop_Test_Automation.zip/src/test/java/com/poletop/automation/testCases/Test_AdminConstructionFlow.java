package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.poletop.automation.uiActions.PoletopDashboardPage;
import com.poletop.automation.uiActions.PoletopReservationDetailsPage;
import com.test.automation.sdk.testbase.TestBase;

/***********************************************************************
 * Test Case ID : ADO-233504
 * Source       : Azure DevOps / PRJ15999 - Poletop Manager Application Re-Design
 * Title        : Admin Starts & Completes Construction on a Reservation
 * Objective    : Verify DOT-Admin can start and complete construction
 *                on a "Permits Issued" reservation, including Cancel
 *                flow (no stage change) and Save flow (stage advances).
 * User Role    : DOT-Admin
 *
 * PRECONDITION : A reservation in "Permits Issued" stage must exist in STG.
 *                Currently BLOCKED — no such reservation in STG environment.
 *                See: docs/test-case-gaps/Test_AdminConstructionFlow-blocker-report.md
 *                RunMode=N until precondition is met.
 ***********************************************************************/
public class Test_AdminConstructionFlow extends TestBase {

    private PoletopDashboardPage dashboardPage;
    private PoletopReservationDetailsPage reservationDetailsPage;

    // -- Data Provider -----------------------------------------------------

    /**
     * Reads the "AdminConstructionFlow" sheet from the environment Excel file.
     * Columns: testCaseName | userRole | email | password | reservationNumber |
     *          startMonth | startDay | startYear | startComment |
     *          completeMonth | completeDay | completeYear | completeComment | runMode
     */
    @DataProvider(name = "adminConstructionFlowData")
    public Object[][] adminConstructionFlowData() throws IOException {
        return getData("AdminConstructionFlow");
    }

    // -- Test: Start & Complete Construction (full happy path) -------------

    /***********************************************************************
     * ADO-233504 — Steps 1, 2, 3, 5, 6, 7, 8, 9
     * Verifies Admin can:
     *   - Log in and reach Dashboard
     *   - Find a Permits Issued reservation
     *   - Start Construction (Save) → stage becomes Construction Started
     *   - Complete Construction (Save) → stage becomes Construction Completed
     *   - "Review Documents" button is present after completion
     ***********************************************************************/
    @Test(dataProvider = "adminConstructionFlowData", priority = 1,
          description = "ADO-233504: Admin saves Start and Complete Construction dates")
    public void testStartAndCompleteConstruction(
            String testCaseName, String userRole,
            String email, String password,
            String reservationNumber,
            String startMonth, String startDay, String startYear, String startComment,
            String completeMonth, String completeDay, String completeYear, String completeComment,
            String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping: " + testCaseName);
        }

        log.info("=== START [" + userRole + "]: " + testCaseName + " ===");

        // Step 1 — Login and verify Dashboard
        step("[" + userRole + "] Navigate to Poletop and log in");
        driver.get(baseURL);
        waitUntillPageLoad();
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.login(email, password);
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
            "Dashboard should load after login as " + userRole);
        log.info("[" + userRole + "] Dashboard loaded");

        // Step 2 — Search for a Permits Issued reservation
        step("[" + userRole + "] Search for reservation: " + reservationNumber);
        dashboardPage.searchReservation(reservationNumber);
        reservationDetailsPage = new PoletopReservationDetailsPage(driver);
        String initialStage = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(initialStage.contains("Permits Issued"),
            "Reservation stage should be 'Permits Issued' before starting construction. Actual: " + initialStage);
        Assert.assertTrue(reservationDetailsPage.isStartConstructionVisible(),
            "'Start Construction' button should be visible for Permits Issued reservation");
        log.info("[" + userRole + "] Reservation " + reservationNumber + " confirmed at stage: " + initialStage);

        // Step 3 — Click Start Construction → verify form appears
        step("[" + userRole + "] Click 'Start Construction' and verify date form");
        reservationDetailsPage.clickStartConstruction();
        Assert.assertTrue(reservationDetailsPage.isConstructionDateFormVisible(),
            "Start Construction date form (Month/Day/Year) should be visible after clicking Start Construction");

        // Step 4 (Cancel flow) — Fill date then Cancel → stage unchanged
        step("[" + userRole + "] Fill Start Construction date then click Cancel");
        reservationDetailsPage.fillConstructionDate(startMonth, startDay, startYear, "Cancel test");
        reservationDetailsPage.clickCancel();
        String stageAfterCancel = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(stageAfterCancel.contains("Permits Issued"),
            "Stage should still be 'Permits Issued' after Cancel. Actual: " + stageAfterCancel);
        Assert.assertTrue(reservationDetailsPage.isStartConstructionVisible(),
            "'Start Construction' button should still be visible after Cancel");
        log.info("[" + userRole + "] Cancel verified — stage unchanged: " + stageAfterCancel);

        // Step 5/6 — Click Start Construction again → fill date → Save
        step("[" + userRole + "] Click 'Start Construction', fill date, Save");
        reservationDetailsPage.clickStartConstruction();
        Assert.assertTrue(reservationDetailsPage.isConstructionDateFormVisible(),
            "Start Construction date form should be visible again after re-clicking");
        reservationDetailsPage.fillConstructionDate(startMonth, startDay, startYear, startComment);
        reservationDetailsPage.clickSave();
        String stageAfterStartSave = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(stageAfterStartSave.contains("Construction Started"),
            "Stage should be 'Construction Started' after saving Start Construction date. Actual: " + stageAfterStartSave);
        Assert.assertTrue(reservationDetailsPage.isCompleteConstructionVisible(),
            "'Complete Construction' button should be visible after stage = Construction Started");
        log.info("[" + userRole + "] Start Construction saved — stage: " + stageAfterStartSave);

        // Step 7 (Cancel flow for Complete) — fill date then Cancel → stage unchanged
        step("[" + userRole + "] Click 'Complete Construction', fill date, click Cancel");
        reservationDetailsPage.clickCompleteConstruction();
        Assert.assertTrue(reservationDetailsPage.isConstructionDateFormVisible(),
            "Complete Construction date form should be visible");
        reservationDetailsPage.fillConstructionDate(completeMonth, completeDay, completeYear, "Cancel test");
        reservationDetailsPage.clickCancel();
        String stageAfterCompleteCancelled = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(stageAfterCompleteCancelled.contains("Construction Started"),
            "Stage should still be 'Construction Started' after Cancel. Actual: " + stageAfterCompleteCancelled);
        Assert.assertTrue(reservationDetailsPage.isCompleteConstructionVisible(),
            "'Complete Construction' button should still be visible after Cancel");
        log.info("[" + userRole + "] Complete Construction cancel verified — stage: " + stageAfterCompleteCancelled);

        // Step 8 — Complete Construction → Save
        step("[" + userRole + "] Click 'Complete Construction', fill date, Save");
        reservationDetailsPage.clickCompleteConstruction();
        Assert.assertTrue(reservationDetailsPage.isConstructionDateFormVisible(),
            "Complete Construction date form should be visible again");
        reservationDetailsPage.fillConstructionDate(completeMonth, completeDay, completeYear, completeComment);
        reservationDetailsPage.clickSave();
        String stageAfterCompleteSave = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(stageAfterCompleteSave.contains("Construction Completed"),
            "Stage should be 'Construction Completed' after saving Complete Construction date. Actual: " + stageAfterCompleteSave);
        Assert.assertTrue(reservationDetailsPage.isReviewDocumentsVisible(),
            "'Review Documents' button should be visible after stage = Construction Completed");
        log.info("[" + userRole + "] Complete Construction saved — stage: " + stageAfterCompleteSave);

        // Step 9 — Verify navigation options still available
        step("[" + userRole + "] Verify Sign Out and nav options are accessible");
        Assert.assertTrue(
            driver.findElements(org.openqa.selenium.By.xpath(
                "//a[contains(normalize-space(.),'Sign Out')]")).size() > 0,
            "Sign Out link should be visible after construction flow");
        log.info("[" + userRole + "] Nav verification passed");

        // Cleanup — logout
        step("[" + userRole + "] Log out");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.logout();

        log.info("=== END [" + userRole + "]: " + testCaseName + " ===");
    }

    // -- Test: Cancel-only flow (negative / boundary) ----------------------

    /***********************************************************************
     * ADO-233504 — Steps 3-4 and 6-7 in isolation
     * Verifies Cancel on both forms does NOT advance the reservation stage.
     ***********************************************************************/
    @Test(dataProvider = "adminConstructionFlowData", priority = 2,
          description = "ADO-233504: Cancel on Start/Complete Construction forms leaves stage unchanged")
    public void testCancelDoesNotAdvanceStage(
            String testCaseName, String userRole,
            String email, String password,
            String reservationNumber,
            String startMonth, String startDay, String startYear, String startComment,
            String completeMonth, String completeDay, String completeYear, String completeComment,
            String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping: " + testCaseName);
        }

        log.info("=== START Cancel-only [" + userRole + "]: " + testCaseName + " ===");

        step("[" + userRole + "] Navigate to Poletop and log in");
        driver.get(baseURL);
        waitUntillPageLoad();
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.login(email, password);
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
            "Dashboard should load after login");

        step("[" + userRole + "] Search for Permits Issued reservation");
        dashboardPage.searchReservation(reservationNumber);
        reservationDetailsPage = new PoletopReservationDetailsPage(driver);
        String stageBefore = reservationDetailsPage.getReservationStage();
        Assert.assertTrue(stageBefore.contains("Permits Issued"),
            "Reservation should be Permits Issued before test. Actual: " + stageBefore);

        step("[" + userRole + "] Open Start Construction form and Cancel");
        reservationDetailsPage.clickStartConstruction();
        Assert.assertTrue(reservationDetailsPage.isConstructionDateFormVisible(),
            "Construction date form should appear");
        reservationDetailsPage.fillConstructionDate(startMonth, startDay, startYear, "Cancel-only test");
        reservationDetailsPage.clickCancel();
        Assert.assertTrue(reservationDetailsPage.getReservationStage().contains("Permits Issued"),
            "Stage must NOT change after Cancel on Start Construction form");

        step("[" + userRole + "] Log out");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.logout();

        log.info("=== END Cancel-only [" + userRole + "]: " + testCaseName + " ===");
    }
}
