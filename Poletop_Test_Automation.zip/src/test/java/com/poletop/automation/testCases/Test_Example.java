package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;
import java.io.IOException;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.test.automation.sdk.testbase.TestBase;
import com.poletop.automation.uiActions.ExamplePage;

/***********************************************************************
 * Test Case ID : REPLACE-WITH-YOUR-ID
 * Objective    : Example test class showing the required structure.
 *                Replace this with your actual test scenario.
 ***********************************************************************/
public class Test_Example extends TestBase {

    private ExamplePage examplePage;

    @DataProvider(name = "exampleData")
    public Object[][] exampleData() throws IOException {
        return getData("ExampleSheet"); // must match sheet name in Excel file
    }

    @Test(dataProvider = "exampleData", priority = 1,
          description = "Example positive scenario")
    public void testExampleScenario(String testCaseName, String inputValue,
                                    String expectedResult, String runMode)
            throws Exception {

        if ("N".equalsIgnoreCase(runMode))
            throw new SkipException("Skipping: " + testCaseName);

        log.info("=== START: " + testCaseName + " ===");

        step("Navigate to application");
        driver.get(baseURL);
        waitUntillPageLoad();

        step("Initialize page objects");
        examplePage = new ExamplePage(driver);

        step("Perform action: enter value");
        examplePage.enterValue(inputValue);

        step("Assert expected result");
        Assert.assertTrue(true, "Replace with real assertion for: " + expectedResult);

        log.info("=== END: " + testCaseName + " ===");
    }
}