package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.sdk.testbase.TestBase;
import com.poletop.automation.uiActions.PoletopCheckLocationPage;
import com.poletop.automation.uiActions.PoletopDashboardPage;

/***********************************************************************
 * Test Case ID : ADO-233502
 * Source       : Azure DevOps - PRJ15999 Poletop Manager Application Re-Design
 * Title        : PoleTop Users check Available Locations for creating Pole Reservations
 *
 * Objective    : Verify that Franchisee and DOT-Admin users can navigate to
 *                the Check Location screen, enter XY or LatLong coordinates,
 *                submit, and receive the correct Availability status on
 *                the Location Details screen.
 *
 * Excel Sheet  : "CheckAvailableLocation"
 * Columns (in order - 11 columns):
 *   TestCaseName | UserRole | Email | Password |
 *   CoordSystem | XCoord | YCoord | Latitude | Longitude |
 *   PoleClass | RunMode
 *
 * Created By   : vkruglyak
 ***********************************************************************/
public class Test_CheckAvailableLocation extends TestBase {

    private PoletopDashboardPage dashboardPage;
    private PoletopCheckLocationPage checkLocationPage;

    @DataProvider(name = "checkAvailableLocationData")
    public Object[][] checkAvailableLocationData() throws IOException {
        return getData("CheckAvailableLocation");
    }

    private void loginUser(String userRole, String email, String password) throws Exception {
        step("[" + userRole + "] Navigate to Poletop application");
        driver.get(baseURL);
        waitUntillPageLoad();
        dashboardPage = new PoletopDashboardPage(driver);
        log.info("[" + userRole + "] Logging in with: " + email);
        dashboardPage.login(email, password);
        waitUntillPageLoad();
        step("[" + userRole + "] Verify dashboard loaded after login");
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
                "[" + userRole + "] Dashboard should be visible after login.");
    }

    @Test(dataProvider = "checkAvailableLocationData", priority = 1,
          description = "ADO-233502: User checks available location by XY or LatLong coordinates")
    public void testCheckAvailableLocationByCoordinates(
            String testCaseName,
            String userRole,
            String email,
            String password,
            String coordSystem,
            String xCoord,
            String yCoord,
            String latitude,
            String longitude,
            String poleClass,
            String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode))
            throw new SkipException("Skipping: " + testCaseName);

        log.info("=== START [" + userRole + " / " + poleClass + "]: " + testCaseName + " ===");

        loginUser(userRole, email, password);

        step("[" + userRole + "] Navigate to Maps > Check Location");
        checkLocationPage = new PoletopCheckLocationPage(driver);
        checkLocationPage.navigateToCheckLocation();
        Assert.assertTrue(checkLocationPage.isCheckLocationPageLoaded(),
                "[" + userRole + "] Check Location page should load after Maps > Check Location.");

        step("[" + userRole + "] Enter " + coordSystem + " coordinates");
        if ("XY".equalsIgnoreCase(coordSystem) || "X&Y".equalsIgnoreCase(coordSystem)) {
            checkLocationPage.enterXYCoordinates(xCoord, yCoord);
        } else {
            checkLocationPage.enterLatLongCoordinates(latitude, longitude);
        }

        step("[" + userRole + "] Click Submit");
        checkLocationPage.clickSubmit();

        step("[" + userRole + "] Verify Location Details screen loaded");
        Assert.assertTrue(checkLocationPage.isLocationDetailsLoaded(),
                "[" + userRole + "] Location Details screen should load after Submit.");

        step("[" + userRole + "] Verify Availability status is present");
        String availStatus = checkLocationPage.getAvailabilityStatus();
        Assert.assertFalse(availStatus.isEmpty(),
                "[" + userRole + "] Availability status should not be empty.");
        log.info("[" + userRole + "] (" + poleClass + ") availability: " + availStatus);

        step("[" + userRole + "] Verify 'Check Another Location' option is present");
        Assert.assertTrue(checkLocationPage.hasCheckAnotherLocationButton(),
                "[" + userRole + "] 'Check Another Location' should be visible on Location Details.");

        step("[" + userRole + "] Log out");
        dashboardPage.logout();

        log.info("=== END [" + userRole + " / " + poleClass + "]: " + testCaseName + " ===");
    }
}
