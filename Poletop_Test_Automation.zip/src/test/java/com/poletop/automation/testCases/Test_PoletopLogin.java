package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.sdk.testbase.TestBase;
import com.poletop.automation.uiActions.PoletopDashboardPage;

/************************************************************************************************************************
 * Class Name  : Test_PoletopLogin
 * Objective   : Validate login functionality on the Poletop application
 *               (https://poletop-stg.csc.nycnet/#/dashboard).
 *
 * Test Cases  :
 *   1. testValidLogin             â€“ valid credentials â†’ user lands on dashboard
 *   2. testInvalidLogin           â€“ wrong password   â†’ error message displayed
 *   3. testLoginWithEmptyFields   â€“ blank submission  â†’ validation message shown
 *
 * Excel Sheet : "PoletopLogin"  in the environment data-set file.
 *   Required columns (in order):
 *     testCaseName | email | password | expectedResult | runMode
 *
 * Created By  : vkruglyak
 ************************************************************************************************************************/
public class Test_PoletopLogin extends TestBase {

    // -- Page object  initialised inside each test from the shared driver 
    private PoletopDashboardPage dashboardPage;

    // -------------------------------------------------------------------------
    // Data Provider
    // -------------------------------------------------------------------------

    /**
     * Reads the "PoletopLogin" sheet from the environment-specific Excel file.
     * Expected columns: testCaseName | email | password | expectedResult | runMode
     */
    @DataProvider(name = "loginData")
    public Object[][] loginData() throws IOException {
        return getData("PoletopLogin");
    }

    // -------------------------------------------------------------------------
    // -- Test --------------------------------------------------
    // -------------------------------------------------------------------------

    /**
     * Verifies that a user with valid credentials can log in and is redirected
     * to the Poletop dashboard.
     *
     * runMode column must be "Y" to execute; any other value skips the row.
     */
    @Test(dataProvider = "loginData", priority = 1, description = "Valid login lands user on dashboard")
    public void testValidLogin(String testCaseName, String userRole, String email, String password,
                               String expectedResult, String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping test: " + testCaseName);
        }

        step("Navigate to Poletop application");
        log.info("=== START: " + testCaseName + " ===");
        driver.get(baseURL);
        waitUntillPageLoad();

        step("Initialise Dashboard page object");
        dashboardPage = new PoletopDashboardPage(driver);

        step("Enter valid credentials and log in");
        dashboardPage.login(email, password);

        step("Verify dashboard is loaded after login");
        waitForPageToLoad(30);
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
                "Dashboard should be visible after valid login, but it was not.");

        step("Verify dashboard heading contains expected text");
        String heading = dashboardPage.getDashboardHeadingText();
        log.info("Dashboard heading: " + heading);
        Assert.assertFalse(heading.isEmpty(),
                "Dashboard heading should not be empty after successful login.");

        step("Log out to clean up session");
        dashboardPage.logout();
        log.info("=== END: " + testCaseName + " ===");
    }

    // -------------------------------------------------------------------------
    // -- Test --------------------------------------------------
    // -------------------------------------------------------------------------

    /**
     * Verifies that an incorrect password results in an error message being
     * displayed, and the user is NOT redirected to the dashboard.
     */
    @Test(dataProvider = "loginData", priority = 2, description = "Invalid password shows error message")
    public void testInvalidLogin(String testCaseName, String userRole, String email, String password,
                                  String expectedResult, String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping test: " + testCaseName);
        }

        step("Navigate to Poletop application");
        log.info("=== START: " + testCaseName + " ===");
        driver.get(baseURL);
        waitUntillPageLoad();

        step("Initialise Dashboard page object");
        dashboardPage = new PoletopDashboardPage(driver);

        step("Enter valid email with an INVALID password");
        // Append "_WRONG" to whatever password is in the data row so we always
        // send a wrong credential regardless of what is stored in the sheet.
        String wrongPassword = password + "_WRONG";
        dashboardPage.login(email, wrongPassword);

        step("Verify error message is shown");
        waitForPageToLoad(15);
        Assert.assertTrue(dashboardPage.isLoginErrorDisplayed(),
                "An error message should be displayed for invalid credentials.");

        step("Verify user is NOT on the dashboard");
        Assert.assertFalse(dashboardPage.isDashboardLoaded(),
                "User should NOT land on the dashboard with invalid credentials.");

        log.info("=== END: " + testCaseName + " ===");
    }

    // -------------------------------------------------------------------------
    // -- Test --------------------------------------------------
    // -------------------------------------------------------------------------

    /**
     * Verifies that submitting the login form with empty fields shows validation
     * messages and does not proceed to the dashboard.
     *
     * This test does NOT use the dataProvider email/password columns; it always
     * submits blank values.  Only the first "Y" row in the sheet is used.
     */
    @Test(dataProvider = "loginData", priority = 3, description = "Empty credentials show validation messages")
    public void testLoginWithEmptyFields(String testCaseName, String userRole, String email, String password,
                                          String expectedResult, String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping test: " + testCaseName);
        }

        step("Navigate to Poletop application");
        log.info("=== START: " + testCaseName + " ===");
        driver.get(baseURL);
        waitUntillPageLoad();

        step("Initialise Dashboard page object");
        dashboardPage = new PoletopDashboardPage(driver);

        step("Submit login form with blank email and password");
        dashboardPage.login("", "");

        step("Verify a validation / error message is displayed");
        waitForPageToLoad(10);
        Assert.assertTrue(dashboardPage.isLoginErrorDisplayed(),
                "A validation message should appear when both fields are empty.");

        step("Verify user is NOT redirected to the dashboard");
        Assert.assertFalse(dashboardPage.isDashboardLoaded(),
                "User should NOT reach the dashboard with empty credentials.");

        log.info("=== END: " + testCaseName + " ===");
    }
}

