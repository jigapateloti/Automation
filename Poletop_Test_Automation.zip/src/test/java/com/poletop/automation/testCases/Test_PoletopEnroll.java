package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.sdk.testbase.TestBase;
import com.poletop.automation.uiActions.PoletopDashboardPage;
import com.poletop.automation.uiActions.PoletopEnrollmentPage;

/************************************************************************************************************************
 * Class Name  : Test_PoletopEnroll
 * Objective   : Validate the Pole Enrollment flow on the Poletop application
 *               (https://poletop-stg.csc.nycnet/#/dashboard).
 *
 * Test Cases  :
 *   1. testSuccessfulEnrollment   â€“ complete valid form â†’ enrollment confirmed
 *   2. testEnrollmentWithMissingRequiredFields â€“ submit incomplete form â†’ error shown
 *
 * Excel Sheet : "PoletopEnroll" in the environment data-set file.
 *   Required columns (in order):
 *     testCaseName | email | password | poleId | borough | address |
 *     poleType | applicantName | phone | contactEmail | notes | runMode
 *
 * Created By  : vkruglyak
 ************************************************************************************************************************/
public class Test_PoletopEnroll extends TestBase {

    private PoletopDashboardPage  dashboardPage;
    private PoletopEnrollmentPage enrollmentPage;

    // -------------------------------------------------------------------------
    // Data Provider
    // -------------------------------------------------------------------------

    /**
     * Reads the "PoletopEnroll" sheet from the environment-specific Excel file.
     * Expected columns:
     *   testCaseName | email | password | poleId | borough | address |
     *   poleType | applicantName | phone | contactEmail | notes | runMode
     */
    @DataProvider(name = "enrollData")
    public Object[][] enrollData() throws IOException {
        return getData("PoletopEnroll");
    }

    // -------------------------------------------------------------------------
    // -- Test --------------------------------------------------
    // -------------------------------------------------------------------------

    /**
     * End-to-end test:
     *   1. Navigate to Poletop dashboard URL.
     *   2. Log in with valid credentials.
     *   3. Navigate to the Enroll section.
     *   4. Fill and submit the enrollment form.
     *   5. Verify the success / confirmation message.
     *   6. Log out to clean up the session.
     */
    @Test(dataProvider = "enrollData", priority = 1,
          description = "Valid enrollment form submission returns a confirmation")
    public void testSuccessfulEnrollment(
            String testCaseName, String userRole, String email, String password,
            String poleId,       String borough,  String address,
            String poleType,     String applicantName, String phone,
            String contactEmail, String notes,    String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping test: " + testCaseName);
        }

        log.info("=== START: " + testCaseName + " ===");

        // ------------------------------------------------------------------
        step("Navigate to Poletop application");
        driver.get(baseURL);
        waitUntillPageLoad();

        // ------------------------------------------------------------------
        step("Log in with valid credentials");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.login(email, password);
        waitForPageToLoad(30);
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
                "Login failed â€“ dashboard was not loaded for user: " + email);

        // ------------------------------------------------------------------
        step("Navigate to Enroll section from the dashboard");
        dashboardPage.goToEnroll();
        waitForPageToLoad(15);

        // ------------------------------------------------------------------
        step("Initialise Enrollment page object and verify page loaded");
        enrollmentPage = new PoletopEnrollmentPage(driver);
        String heading = enrollmentPage.getPageHeadingText();
        log.info("Enrollment page heading: " + heading);
        Assert.assertFalse(heading.isEmpty(),
                "Enrollment page heading should not be empty.");

        // ------------------------------------------------------------------
        step("Fill in enrollment form");
        enrollmentPage.fillEnrollmentForm(
                poleId, borough, address, poleType,
                applicantName, phone, contactEmail, notes);

        // ------------------------------------------------------------------
        step("Submit enrollment form");
        enrollmentPage.submitEnrollment();

        // ------------------------------------------------------------------
        step("Verify enrollment success message is displayed");
        Assert.assertTrue(enrollmentPage.isEnrollmentSuccessful(),
                "Success message was not displayed after enrollment submission.");

        String successText = enrollmentPage.getSuccessMessageText();
        log.info("Enrollment success text: " + successText);
        Assert.assertFalse(successText.isEmpty(),
                "Enrollment success message text should not be empty.");

        // ------------------------------------------------------------------
        step("Capture confirmation / reference number");
        try {
            String confirmationNumber = enrollmentPage.getConfirmationNumber();
            log.info("Enrollment confirmation number: " + confirmationNumber);
            Assert.assertFalse(confirmationNumber.isEmpty(),
                    "Confirmation number should be present after successful enrollment.");
        } catch (Exception e) {
            // Confirmation number element is optional depending on the AUT flow
            log.info("Confirmation number element not found (may be embedded in success message).");
        }

        // ------------------------------------------------------------------
        step("Log out to clean up session");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.logout();

        log.info("=== END: " + testCaseName + " ===");
    }

    // -------------------------------------------------------------------------
    // -- Test --------------------------------------------------
    // -------------------------------------------------------------------------

    /**
     * Verifies that submitting the enrollment form without required fields
     * (poleId and address left blank) shows a form error and does NOT complete
     * the enrollment.
     */
    @Test(dataProvider = "enrollData", priority = 2,
          description = "Incomplete enrollment form shows validation error")
    public void testEnrollmentWithMissingRequiredFields(
            String testCaseName, String userRole, String email, String password,
            String poleId,       String borough,  String address,
            String poleType,     String applicantName, String phone,
            String contactEmail, String notes,    String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode)) {
            throw new SkipException("Skipping test: " + testCaseName);
        }

        log.info("=== START: " + testCaseName + " (missing fields) ===");

        // ------------------------------------------------------------------
        step("Navigate to Poletop application");
        driver.get(baseURL);
        waitUntillPageLoad();

        // ------------------------------------------------------------------
        step("Log in with valid credentials");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.login(email, password);
        waitForPageToLoad(30);
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
                "Login failed â€“ dashboard was not loaded for user: " + email);

        // ------------------------------------------------------------------
        step("Navigate to Enroll section from the dashboard");
        dashboardPage.goToEnroll();
        waitForPageToLoad(15);

        // ------------------------------------------------------------------
        step("Initialise Enrollment page object");
        enrollmentPage = new PoletopEnrollmentPage(driver);

        // ------------------------------------------------------------------
        step("Submit enrollment form with intentionally blank required fields");
        // Pass empty strings for poleId and address to trigger required-field
        // validation; other fields keep their data-row values.
        enrollmentPage.fillEnrollmentForm(
                "",       // poleId â€“ intentionally blank
                borough,
                "",       // address â€“ intentionally blank
                poleType,
                applicantName,
                phone,
                contactEmail,
                notes);
        enrollmentPage.submitEnrollment();

        // ------------------------------------------------------------------
        step("Verify form error message is displayed");
        Assert.assertTrue(enrollmentPage.isFormErrorDisplayed(),
                "A validation / error message should be shown for missing required fields.");

        // ------------------------------------------------------------------
        step("Verify enrollment success message is NOT displayed");
        Assert.assertFalse(enrollmentPage.isEnrollmentSuccessful(),
                "Enrollment should NOT succeed when required fields are missing.");

        // ------------------------------------------------------------------
        step("Log out to clean up session");
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.logout();

        log.info("=== END: " + testCaseName + " (missing fields) ===");
    }
}

