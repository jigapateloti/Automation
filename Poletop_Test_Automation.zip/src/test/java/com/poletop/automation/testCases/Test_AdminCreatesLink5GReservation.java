package com.poletop.automation.testCases;

import static io.qameta.allure.Allure.step;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.poletop.automation.uiActions.PoletopCheckLocationPage;
import com.poletop.automation.uiActions.PoletopDashboardPage;
import com.poletop.automation.uiActions.PoletopEnterReservationPage;
import com.test.automation.sdk.testbase.TestBase;

/***********************************************************************
 * Test Case ID : ADO-119816
 * Source       : Azure DevOps — OTI QA Automation
 * Objective    : Admin Creates Link 5G Reservation in PoleTop Manager.
 *                Flow: Login → Maps → Check Location → enter XY or LatLong
 *                coords (available location) → Enter Reservation Details →
 *                fill Link 5G form → Save → verify Reservation# screen.
 * URL          : https://poletop-stg.csc.nycnet
 * Shared Steps : 119526 (Admin Login), 119573 / 121050 (Check Location),
 *                119807 (Admin Creates Link 5G Reservation)
 ***********************************************************************/
public class Test_AdminCreatesLink5GReservation extends TestBase {

    private PoletopDashboardPage dashboardPage;
    private PoletopCheckLocationPage checkLocationPage;
    private PoletopEnterReservationPage enterReservationPage;

    @DataProvider(name = "link5GReservationData")
    public Object[][] link5GReservationData() throws IOException {
        return getData("AdminCreatesLink5GReservation");
    }

    /**
     * TC-119816 — Admin creates a Link 5G Reservation using XY or LatLong coordinates.
     *
     * Excel columns (AdminCreatesLink5GReservation sheet):
     * testCaseName | email | password | coordinateSystem | xCoord | yCoord | latitude | longitude |
     * zipCode | organization | name | poleClass | adPanels | wirelessTechnology |
     * wirelessProvider | providerService | franchiseeRefId | address | onStreet |
     * crossStreet1 | crossStreet2 | locationType | notes | doittComments |
     * expectedStage | expectedStatus | expectedPoleType | runMode
     */
    @Test(dataProvider = "link5GReservationData", priority = 1,
          description = "ADO-119816: Admin creates a Link 5G reservation in PoleTop Manager")
    public void testAdminCreatesLink5GReservation(
            String testCaseName,
            String email,
            String password,
            String coordinateSystem,
            String xCoord,
            String yCoord,
            String latitude,
            String longitude,
            String zipCode,
            String organization,
            String name,
            String poleClass,
            String adPanels,
            String wirelessTechnology,
            String wirelessProvider,
            String providerService,
            String franchiseeRefId,
            String address,
            String onStreet,
            String crossStreet1,
            String crossStreet2,
            String locationType,
            String notes,
            String doittComments,
            String expectedStage,
            String expectedStatus,
            String expectedPoleType,
            String runMode) throws Exception {

        if ("N".equalsIgnoreCase(runMode))
            throw new SkipException("Skipping: " + testCaseName);

        log.info("=== START: " + testCaseName + " ===");

        // ── Step 1: Login as Admin (Shared Step 119526) ────────────────────

        step("Navigate to Poletop and login as Admin");
        driver.get(baseURL);
        waitUntillPageLoad();
        dashboardPage = new PoletopDashboardPage(driver);
        dashboardPage.login(email, password);

        step("Verify Admin Dashboard is loaded");
        Assert.assertTrue(dashboardPage.isDashboardLoaded(),
                "ADO-119816: Dashboard did not load after Admin login");
        log.info("Dashboard heading: " + dashboardPage.getDashboardHeadingText());

        // ── Step 2: Navigate to Check Location (Shared Step 119573) ────────

        step("Navigate to Maps > Check Location");
        checkLocationPage = new PoletopCheckLocationPage(driver);
        checkLocationPage.navigateToCheckLocation();

        step("Verify Check Location page is loaded");
        Assert.assertTrue(checkLocationPage.isCheckLocationPageLoaded(),
                "ADO-119816: Check Location page did not load");

        // ── Step 3: Enter coordinates and submit ────────────────────────────

        step("Enter " + coordinateSystem + " coordinates and click Submit");
        if ("XY".equalsIgnoreCase(coordinateSystem) || "X&Y".equalsIgnoreCase(coordinateSystem)) {
            checkLocationPage.enterXYCoordinates(xCoord, yCoord);
        } else {
            checkLocationPage.enterLatLongCoordinates(latitude, longitude);
        }
        checkLocationPage.clickSubmit();

        step("Verify Location Details screen is loaded and location is Available");
        Assert.assertTrue(checkLocationPage.isLocationDetailsLoaded(),
                "ADO-119816: Location Details screen did not load after Submit");
        Assert.assertTrue(checkLocationPage.isAvailable(),
                "ADO-119816: Location is not Available — cannot create reservation. "
                + "Status was: " + checkLocationPage.getAvailabilityStatus());

        // ── Step 4: Click Enter Reservation Details ────────────────────────

        step("Click 'Enter Reservation Details' on Location Details screen");
        checkLocationPage.selectEnterReservationDetails();

        step("Verify Enter Reservation Details page is loaded");
        enterReservationPage = new PoletopEnterReservationPage(driver);
        Assert.assertTrue(enterReservationPage.isEnterReservationPageLoaded(),
                "ADO-119816: Enter Reservation Details page did not load");

        // ── Step 5: Fill reservation form (Shared Step 119807) ─────────────

        step("Select Zip Code");
        enterReservationPage.selectZipCode(zipCode);

        step("Select Organization: " + organization);
        enterReservationPage.selectOrganization(organization);

        step("Select Name: " + name);
        enterReservationPage.selectName(name);

        step("Select Pole Class: " + poleClass);
        enterReservationPage.selectPoleClass(poleClass);

        if ("Link 5G".equalsIgnoreCase(poleClass)) {
            step("Select Advertisement Panels: " + adPanels);
            enterReservationPage.selectAdvertisementPanels(adPanels);
        }

        step("Select Wireless Technology: " + wirelessTechnology);
        enterReservationPage.selectWirelessTechnology(wirelessTechnology);

        step("Select Wireless Provider: " + wirelessProvider);
        enterReservationPage.selectWirelessProvider(wirelessProvider);

        step("Select Provider Service: " + providerService);
        enterReservationPage.selectProviderService(providerService);

        step("Enter address fields");
        enterReservationPage.enterFranchiseeReferenceId(franchiseeRefId);
        enterReservationPage.enterAddress(address);
        enterReservationPage.enterOnStreet(onStreet);
        enterReservationPage.enterCrossStreet1(crossStreet1);
        enterReservationPage.enterCrossStreet2(crossStreet2);
        enterReservationPage.selectLocationType(locationType);

        step("Enter Notes and DoITT Comments");
        enterReservationPage.enterNotes(notes);
        enterReservationPage.enterDoittComments(doittComments);

        // ── Step 6: Save and verify Reservation# screen ────────────────────

        step("Click Save to create reservation");
        enterReservationPage.clickSave();

        step("Verify Reservation confirmation screen is loaded");
        Assert.assertTrue(enterReservationPage.isReservationConfirmationLoaded(),
                "ADO-119816: Reservation confirmation screen did not load after Save");

        String reservationNumber = enterReservationPage.getReservationNumber();
        Assert.assertFalse(reservationNumber.isEmpty(),
                "ADO-119816: Reservation number is empty on confirmation screen");
        log.info("Reservation created: #" + reservationNumber);

        step("Verify Reservation Stage: expected='" + expectedStage + "'");
        if (expectedStage != null && !expectedStage.isEmpty()) {
            String actualStage = enterReservationPage.getReservationStage();
            Assert.assertTrue(actualStage.toLowerCase().contains(expectedStage.toLowerCase()),
                    "ADO-119816: Expected stage '" + expectedStage + "' but got '" + actualStage + "'");
        }

        step("Verify Reservation Status: expected='" + expectedStatus + "'");
        if (expectedStatus != null && !expectedStatus.isEmpty()) {
            String actualStatus = enterReservationPage.getReservationStatus();
            Assert.assertTrue(actualStatus.toLowerCase().contains(expectedStatus.toLowerCase()),
                    "ADO-119816: Expected status '" + expectedStatus + "' but got '" + actualStatus + "'");
        }

        step("Verify Pole Type: expected='" + expectedPoleType + "'");
        if (expectedPoleType != null && !expectedPoleType.isEmpty()) {
            String actualPoleType = enterReservationPage.getPoleTypeValue();
            Assert.assertTrue(actualPoleType.toLowerCase().contains(expectedPoleType.toLowerCase()),
                    "ADO-119816: Expected pole type '" + expectedPoleType + "' but got '" + actualPoleType + "'");
        }

        // ── Cleanup ────────────────────────────────────────────────────────

        step("Logout");
        dashboardPage.logout();

        log.info("=== END: " + testCaseName + " — Reservation#" + reservationNumber + " ===");
    }
}
