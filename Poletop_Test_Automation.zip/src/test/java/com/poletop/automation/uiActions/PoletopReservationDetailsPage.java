package com.poletop.automation.uiActions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.sdk.testbase.TestBase;
import com.test.automation.sdk.utility.PageContext;

/***********************************************************************
 * Page Object  : PoletopReservationDetailsPage
 * Test Case ID : ADO-233504
 * Objective    : Admin Starts & Completes Construction on a Reservation
 * URL          : https://poletop-stg.csc.nycnet/#/reservations/<id>
 *
 * NOTE: Locators marked "NEEDS CRAWLER" must be confirmed with
 *       LocatorInvestigator against a live "Permits Issued" reservation.
 ***********************************************************************/
public class PoletopReservationDetailsPage extends TestBase {

    public static final Logger log = LogManager.getLogger(PoletopReservationDetailsPage.class.getName());

    public PoletopReservationDetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageContext.currentPage.set("PoletopReservationDetailsPage");
    }

    // -- Reservation Details Page Elements ----------------------------------

    /** Reservation stage label (e.g. "Permits Issued", "Construction Started") - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Reservation Stage')]/following-sibling::*[1]"
                  + " | //*[contains(@class,'reservation-stage')]"
                  + " | //span[contains(@class,'stage')]")
    public WebElement reservationStageLabel;

    /** Reservation status label - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Reservation Status')]/following-sibling::*[1]"
                  + " | //*[contains(@class,'reservation-status')]")
    public WebElement reservationStatusLabel;

    /** "Start Construction" button — bottom of page - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Start Construction']"
                  + " | //input[@value='Start Construction']"
                  + " | //a[normalize-space(.)='Start Construction']")
    public WebElement startConstructionButton;

    /** "Complete Construction" button — appears after stage = Construction Started - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Complete Construction']"
                  + " | //input[@value='Complete Construction']"
                  + " | //a[normalize-space(.)='Complete Construction']")
    public WebElement completeConstructionButton;

    /** "Review Documents" button — appears after stage = Construction Completed - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Review Documents']"
                  + " | //input[@value='Review Documents']"
                  + " | //a[normalize-space(.)='Review Documents']")
    public WebElement reviewDocumentsButton;

    // -- Construction Date Form Elements ------------------------------------

    /** Month field in Start/Complete Construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='month']"
                  + " | //input[@formcontrolname='month']"
                  + " | //select[contains(@name,'month') or contains(@id,'month')]"
                  + " | //input[contains(@placeholder,'Month') or contains(@aria-label,'Month')]")
    public WebElement constructionMonthField;

    /** Day field in Start/Complete Construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='day']"
                  + " | //input[@formcontrolname='day']"
                  + " | //select[contains(@name,'day') or contains(@id,'day')]"
                  + " | //input[contains(@placeholder,'Day') or contains(@aria-label,'Day')]")
    public WebElement constructionDayField;

    /** Year field in Start/Complete Construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='year']"
                  + " | //input[@formcontrolname='year']"
                  + " | //select[contains(@name,'year') or contains(@id,'year')]"
                  + " | //input[contains(@placeholder,'Year') or contains(@aria-label,'Year')]")
    public WebElement constructionYearField;

    /** Comments box in construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//textarea[@formcontrolname='comments']"
                  + " | //textarea[contains(@name,'comment') or contains(@placeholder,'Comment')]")
    public WebElement constructionCommentsField;

    /** "Save" button in construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Save']"
                  + " | //input[@type='submit' and @value='Save']")
    public WebElement saveButton;

    /** "Cancel" button in construction date form - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Cancel']"
                  + " | //input[@type='button' and @value='Cancel']")
    public WebElement cancelButton;

    // -- Actions ------------------------------------------------------------

    /**
     * Returns the current reservation stage text (e.g. "Permits Issued").
     */
    public String getReservationStage() {
        try {
            waitForElementPresent(driver, reservationStageLabel);
            String stage = safeGetText(reservationStageLabel).trim();
            log.info("Reservation stage: " + stage);
            return stage;
        } catch (Exception e) {
            log.warn("getReservationStage failed: " + e.getMessage());
            return "";
        }
    }

    /**
     * Returns true if the "Start Construction" button is visible.
     */
    public boolean isStartConstructionVisible() {
        try {
            waitForElementPresent(driver, startConstructionButton);
            return startConstructionButton.isDisplayed();
        } catch (Exception e) {
            log.warn("Start Construction button not found: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns true if the "Complete Construction" button is visible.
     */
    public boolean isCompleteConstructionVisible() {
        try {
            waitForElementPresent(driver, completeConstructionButton);
            return completeConstructionButton.isDisplayed();
        } catch (Exception e) {
            log.warn("Complete Construction button not found: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns true if the "Review Documents" button is visible.
     */
    public boolean isReviewDocumentsVisible() {
        try {
            waitForElementPresent(driver, reviewDocumentsButton);
            return reviewDocumentsButton.isDisplayed();
        } catch (Exception e) {
            log.warn("Review Documents button not found: " + e.getMessage());
            return false;
        }
    }

    /**
     * Clicks "Start Construction" to open the construction date form.
     */
    public void clickStartConstruction() {
        log.info("Clicking Start Construction");
        scrollToElement(startConstructionButton);
        fluentWaitUntilElementToBeClickable(startConstructionButton);
        safeClick(startConstructionButton);
        waitUntillPageLoad();
    }

    /**
     * Clicks "Complete Construction" to open the complete construction date form.
     */
    public void clickCompleteConstruction() {
        log.info("Clicking Complete Construction");
        scrollToElement(completeConstructionButton);
        fluentWaitUntilElementToBeClickable(completeConstructionButton);
        safeClick(completeConstructionButton);
        waitUntillPageLoad();
    }

    /**
     * Returns true if the construction date form is displayed
     * (Month, Day, Year fields visible).
     */
    public boolean isConstructionDateFormVisible() {
        try {
            waitForElementPresent(driver, constructionMonthField);
            return constructionMonthField.isDisplayed()
                && constructionDayField.isDisplayed()
                && constructionYearField.isDisplayed();
        } catch (Exception e) {
            log.warn("Construction date form not visible: " + e.getMessage());
            return false;
        }
    }

    /**
     * Fills the construction date form with the given month, day, year and optional comment.
     */
    public void fillConstructionDate(String month, String day, String year, String comment) {
        log.info("Filling construction date: " + month + "/" + day + "/" + year);
        waitForElementPresent(driver, constructionMonthField);
        clearAndType(constructionMonthField, month);
        clearAndType(constructionDayField, day);
        clearAndType(constructionYearField, year);
        if (comment != null && !comment.isEmpty()) {
            clearAndType(constructionCommentsField, comment);
        }
    }

    /**
     * Clicks the Cancel button on the construction date form.
     */
    public void clickCancel() {
        log.info("Clicking Cancel on construction date form");
        fluentWaitUntilElementToBeClickable(cancelButton);
        safeClick(cancelButton);
        waitUntillPageLoad();
    }

    /**
     * Clicks the Save button on the construction date form.
     */
    public void clickSave() {
        log.info("Clicking Save on construction date form");
        fluentWaitUntilElementToBeClickable(saveButton);
        safeClick(saveButton);
        waitUntillPageLoad();
    }
}
