package com.poletop.automation.uiActions;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.sdk.testbase.TestBase;
import com.test.automation.sdk.utility.PageContext;

/**
 * Page Object for the Poletop Dashboard.
 * URL: https://poletop-stg.csc.nycnet/#/dashboard
 * Test Case ID: ADO-233502
 * @author vkruglyak
 */
public class PoletopDashboardPage extends TestBase {

    public static final Logger log = LogManager.getLogger(PoletopDashboardPage.class.getName());

    public PoletopDashboardPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageContext.currentPage.set("PoletopDashboardPage");
    }

    // Login form - NYC.ID SSO

    /** Email/username on the NYC.ID SSO login page - UNIQUE (id=gigya-loginID) */
    @FindBy(xpath = "//input[@id='gigya-loginID']")
    public WebElement loginEmailField;

    /** Password on the NYC.ID SSO login page - UNIQUE (id=gigya-password) */
    @FindBy(xpath = "//input[@id='gigya-password']")
    public WebElement loginPasswordField;

    /** Submit button on the NYC.ID SSO login page */
    @FindBy(xpath = "//input[@type='submit']")
    public WebElement loginButton;

    /** Sign In link on the Poletop landing page before SSO redirect */
    @FindBy(xpath = "//a[contains(@class,'has-icon') and contains(normalize-space(.),'Sign In')]"
                  + " | //a[contains(@href,'authorize.htm')]")
    public WebElement signInLandingLink;

    // Dashboard elements

    /** Sign Out link — text is "Sign OutSign Out" (icon + text node) - UNIQUE ✓ */
    @FindBy(xpath = "//a[contains(normalize-space(.),'Sign OutSign Out')]")
    public WebElement logoutLink;

    /** "Reservations" nav dropdown — id=nav-item-01 - UNIQUE ✓ */
    @FindBy(xpath = "//a[@id='nav-item-01']")
    public WebElement reservationsMenuLink;

    /** "Maps" nav dropdown — id=nav-item-02 - UNIQUE ✓ */
    @FindBy(xpath = "//a[@id='nav-item-02']")
    public WebElement mapsMenuLink;

    /** Search bar — only present when authenticated - UNIQUE ✓ */
    @FindBy(xpath = "//input[@id='global-search-bar']")
    public WebElement globalSearchBar;

    /** Dashboard heading "Welcome, Pole..." - UNIQUE ✓ */
    @FindBy(xpath = "//h1[contains(normalize-space(.),'Welcome')]")
    public WebElement dashboardHeading;

    /** Nav <li> items inside nav-primary — confirmed from absolute XPath:
     *  //*[@id="nav-primary"]/nav/div[1]/div/ul/li[2]/a
     *  Stable container anchor: @id='nav-primary'
     *  Used by actOnListElement for dropdown navigation. */
    @FindBy(xpath = "//*[@id='nav-primary']//ul//li")
    public List<WebElement> navMenuItems;
    @FindBy(xpath = "//div[contains(@class,'gigya-error-msg') and normalize-space(.)!='']"
                  + " | //div[contains(@class,'alert-danger') and normalize-space(.)!='']"
                  + " | //span[contains(@class,'error') and normalize-space(.)!='']")
    public WebElement loginErrorMessage;

    // Actions

    /**
     * Clicks Sign In link if needed, then fills NYC.ID gigya form and waits
     * for the SAML redirect back to Poletop (up to 60 seconds).
     */
    public void login(String email, String password) {
        log.info("Starting login for: " + email);

        if (driver.findElements(By.xpath("//input[@id='gigya-loginID']")).isEmpty()) {
            try {
                // Use short findElements check — Sign In link may not exist if already on gigya
                List<org.openqa.selenium.WebElement> signInLinks = driver.findElements(
                    By.xpath("//a[contains(@class,'has-icon') and contains(normalize-space(.),'Sign In')]"
                           + " | //a[contains(@href,'authorize.htm')]"));
                if (!signInLinks.isEmpty()) {
                    signInLinks.get(0).click();
                    waitUntillPageLoad();
                    log.info("Clicked Sign In link, now at: " + driver.getCurrentUrl());
                }
            } catch (Exception e) {
                log.info("No Sign In link needed: " + e.getMessage());
            }
        }

        waitForElementPresent(driver, loginEmailField);
        fluentWaitUntilElementToBeClickable(loginEmailField);
        clearAndType(loginEmailField, email);
        clearAndType(loginPasswordField, password);
        log.info("Credentials entered, submitting...");
        fluentWaitUntilElementToBeClickable(loginButton);
        safeClick(loginButton);

        log.info("Waiting for SAML redirect to complete...");
        long deadline = System.currentTimeMillis() + 60_000L;
        while (System.currentTimeMillis() < deadline) {
            try { Thread.sleep(2000); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            String url = driver.getCurrentUrl();
            log.info("Current URL: " + url);
            if (url != null
                    && !url.contains("accounts-nonprd.nyc.gov")
                    && !url.contains("accounts.nyc.gov")
                    && !url.contains("gigya")) {
                log.info("Left NYC.ID domain - SAML redirect complete at: " + url);
                break;
            }
        }

        waitUntillPageLoad();
        try { Thread.sleep(3000); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
        log.info("Login finished - final URL: " + driver.getCurrentUrl());
    }

    /** Returns true when the global search bar is visible — only present when authenticated. */
    public boolean isDashboardLoaded() {
        try {
            waitForElementPresent(driver, globalSearchBar);
            log.info("Dashboard confirmed — search bar visible. URL: " + driver.getCurrentUrl());
            return globalSearchBar.isDisplayed();
        } catch (Exception e) {
            log.warn("isDashboardLoaded failed. URL was: " + driver.getCurrentUrl() + " | " + e.getMessage());
            return false;
        }
    }

    /** Returns the dashboard welcome heading text. */
    public String getDashboardHeadingText() {
        try {
            waitForElementPresent(driver, dashboardHeading);
            String text = safeGetText(dashboardHeading).trim();
            log.info("Dashboard heading: " + text);
            return text;
        } catch (Exception e) {
            log.warn("getDashboardHeadingText failed: " + e.getMessage());
            return "";
        }
    }

    /** Returns true if a login error message is visible on the page. */
    public boolean isLoginErrorDisplayed() {
        try {
            waitForElementPresent(driver, loginErrorMessage);
            return loginErrorMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /** Navigates to New Reservation via nav menu or direct URL. */
    public void goToEnroll() {
        log.info("Navigating to New Reservation");
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("window.scrollTo(0,0);");

        // nav-item-02 is the franchisee "New Reservation" direct link; nav-item-01 is "Reservations" dropdown
        boolean reached = false;
        for (String navId : new String[]{"nav-item-02", "nav-item-01"}) {
            try {
                WebElement navLink = driver.findElement(By.xpath("//a[@id='" + navId + "']"));
                fluentWaitUntilElementToBeClickable(navLink);
                safeClick(navLink);
                waitUntillPageLoad();
                if (!driver.getCurrentUrl().contains("/dashboard")) {
                    reached = true;
                    log.info("Navigated via " + navId + " — URL: " + driver.getCurrentUrl());
                    break;
                }
                // opened a dropdown; look for New Reservation sub-item
                List<WebElement> subItems = driver.findElements(
                    By.xpath("//a[@id='" + navId + "']/ancestor::li[1]//a[contains(normalize-space(.),'New Reservation')]"));
                if (!subItems.isEmpty()) {
                    fluentWaitUntilElementToBeClickable(subItems.get(0));
                    safeClick(subItems.get(0));
                    waitUntillPageLoad();
                    reached = !driver.getCurrentUrl().contains("/dashboard");
                    if (reached) {
                        log.info("Clicked New Reservation under " + navId + " — URL: " + driver.getCurrentUrl());
                        break;
                    }
                }
            } catch (Exception e) {
                log.warn("goToEnroll nav attempt via " + navId + " failed: " + e.getMessage());
            }
        }

        if (!reached) {
            log.warn("Nav navigation failed — could not reach enrollment form from dashboard");
        }
    }

    /** Logs out of the application. */
    public void logout() {
        log.info("Logging out");
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("window.scrollTo(0,0);");
        waitForElementPresent(driver, logoutLink);
        safeClick(logoutLink);
        waitUntillPageLoad();
    }

    /**
     * Types a reservation number into the global search bar and submits.
     */
    public void searchReservation(String reservationNumber) {
        log.info("Searching for reservation: " + reservationNumber);
        waitForElementPresent(driver, globalSearchBar);
        clearAndType(globalSearchBar, reservationNumber);
        globalSearchBar.sendKeys(org.openqa.selenium.Keys.ENTER);
        waitUntillPageLoad();
        log.info("Search submitted — current URL: " + driver.getCurrentUrl());
    }
}