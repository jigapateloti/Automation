package com.poletop.automation.uiActions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.sdk.testbase.TestBase;
import com.test.automation.sdk.utility.PageContext;

/***********************************************************************
 * Page Object  : PoletopEnterReservationPage
 * Test Case ID : ADO-119816 (119807)
 * Objective    : Admin fills and submits the Enter Reservation Details
 *                form to create a new Link 5G reservation.
 * URL          : https://poletop-stg.csc.nycnet/#/reservation/new
 *                (navigated to from Location Details → Enter Reservation Details)
 *
 * NOTE: Locators marked "NEEDS CRAWLER" must be confirmed by running
 *       LocatorInvestigator with admin credentials on this page.
 *       Run: mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml
 *                     -Denvironment=stg -DbrowserName=chrome
 *                     -Dinv.email=<admin> -Dinv.password=<pwd>
 *                     -Dinv.page=enterreservation
 ***********************************************************************/
public class PoletopEnterReservationPage extends TestBase {

    public static final Logger log = LogManager.getLogger(PoletopEnterReservationPage.class.getName());

    public PoletopEnterReservationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageContext.currentPage.set("PoletopEnterReservationPage");
    }

    // ── Page heading ──────────────────────────────────────────────────────

    /** "Enter Reservation Details" heading - NEEDS CRAWLER */
    @FindBy(xpath = "//h1[contains(normalize-space(.),'Enter Reservation Details')]"
                  + " | //h2[contains(normalize-space(.),'Enter Reservation Details')]")
    public WebElement pageHeading;

    // ── Read-only pole location info ──────────────────────────────────────

    /** Non-editable X coordinate display - NEEDS CRAWLER */
    @FindBy(xpath = "//*[contains(normalize-space(.),'X Coordinates') or contains(normalize-space(.),'X Coordinate')]/following-sibling::*[1]"
                  + " | //*[@id='xCoordinate']")
    public WebElement xCoordinateDisplay;

    /** Non-editable Y coordinate display - NEEDS CRAWLER */
    @FindBy(xpath = "//*[contains(normalize-space(.),'Y Coordinates') or contains(normalize-space(.),'Y Coordinate')]/following-sibling::*[1]"
                  + " | //*[@id='yCoordinate']")
    public WebElement yCoordinateDisplay;

    // ── Required form fields ──────────────────────────────────────────────

    /** Zip Code * dropdown - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='zipCode']"
                  + " | //mat-select[@formcontrolname='zipCode']"
                  + " | //select[@name='zipCode']")
    public WebElement zipCodeDropdown;

    /** Organization * dropdown - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='organization']"
                  + " | //mat-select[@formcontrolname='organization']"
                  + " | //select[@name='organization']")
    public WebElement organizationDropdown;

    /** Name * dropdown (depends on Organization) - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='name']"
                  + " | //mat-select[@formcontrolname='name']"
                  + " | //select[@name='franchiseeName']")
    public WebElement nameDropdown;

    // ── Pole Class radio buttons ──────────────────────────────────────────

    /** "City" radio button for Pole Class - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='City']"
                  + " | //input[@type='radio' and @id='city']"
                  + " | //label[normalize-space(.)='City']/preceding-sibling::input[@type='radio'][1]"
                  + " | //label[normalize-space(.)='City']/input[@type='radio']")
    public WebElement poleClassCityRadio;

    /** "Utility" radio button for Pole Class - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='Utility']"
                  + " | //input[@type='radio' and @id='utility']"
                  + " | //label[normalize-space(.)='Utility']/preceding-sibling::input[@type='radio'][1]"
                  + " | //label[normalize-space(.)='Utility']/input[@type='radio']")
    public WebElement poleClassUtilityRadio;

    /** "Link 5G" radio button for Pole Class - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='Link 5G']"
                  + " | //input[@type='radio' and @value='link5g']"
                  + " | //input[@type='radio' and @id='link5g']"
                  + " | //label[normalize-space(.)='Link 5G']/preceding-sibling::input[@type='radio'][1]"
                  + " | //label[normalize-space(.)='Link 5G']/input[@type='radio']")
    public WebElement poleClassLink5GRadio;

    // ── Advertisement Panels (visible after Link 5G selected) ────────────

    /** "Yes" radio for Advertisement Panels - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='Yes' and ancestor::*[contains(normalize-space(.),'Advertisement')]]"
                  + " | //input[@type='radio' and @id='advertisementYes']"
                  + " | //input[@type='radio' and @id='adPanelYes']")
    public WebElement adPanelsYesRadio;

    /** "No" radio for Advertisement Panels - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='No' and ancestor::*[contains(normalize-space(.),'Advertisement')]]"
                  + " | //input[@type='radio' and @id='advertisementNo']"
                  + " | //input[@type='radio' and @id='adPanelNo']")
    public WebElement adPanelsNoRadio;

    // ── Wireless fields ───────────────────────────────────────────────────

    /** Wireless Technology dropdown - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='wirelessTechnology']"
                  + " | //mat-select[@formcontrolname='wirelessTechnology']"
                  + " | //select[@name='wirelessTechnology']")
    public WebElement wirelessTechnologyDropdown;

    /** Wireless Provider dropdown - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='wirelessProvider']"
                  + " | //mat-select[@formcontrolname='wirelessProvider']"
                  + " | //select[@name='wirelessProvider']")
    public WebElement wirelessProviderDropdown;

    /** Wireless Provider Service "Active" radio - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='Active' and ancestor::*[contains(normalize-space(.),'Service')]]"
                  + " | //input[@type='radio' and @id='serviceActive']"
                  + " | //input[@type='radio' and @value='active']")
    public WebElement providerServiceActiveRadio;

    /** Wireless Provider Service "Inactive" radio - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@type='radio' and @value='Inactive' and ancestor::*[contains(normalize-space(.),'Service')]]"
                  + " | //input[@type='radio' and @id='serviceInactive']"
                  + " | //input[@type='radio' and @value='inactive']")
    public WebElement providerServiceInactiveRadio;

    // ── Address fields ────────────────────────────────────────────────────

    /** Franchisee Reference ID - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@formcontrolname='franchiseeReferenceId']"
                  + " | //input[@name='franchiseeReferenceId']"
                  + " | //input[@placeholder='Franchisee Reference ID']")
    public WebElement franchiseeReferenceIdField;

    /** Address * text input - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@formcontrolname='address']"
                  + " | //input[@name='address']"
                  + " | //input[@placeholder='Address']")
    public WebElement addressField;

    /** On Street * text input - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@formcontrolname='onStreet']"
                  + " | //input[@name='onStreet']"
                  + " | //input[@placeholder='On Street']"
                  + " | //input[@aria-label='On Street']")
    public WebElement onStreetField;

    /** Cross Street 1 * text input - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@formcontrolname='crossStreet1']"
                  + " | //input[@name='crossStreet1']"
                  + " | //input[@placeholder='Cross Street 1']"
                  + " | //input[@aria-label='Cross Street 1']")
    public WebElement crossStreet1Field;

    /** Cross Street 2 text input (optional) - NEEDS CRAWLER */
    @FindBy(xpath = "//input[@formcontrolname='crossStreet2']"
                  + " | //input[@name='crossStreet2']"
                  + " | //input[@placeholder='Cross Street 2']"
                  + " | //input[@aria-label='Cross Street 2']")
    public WebElement crossStreet2Field;

    /** Location Type dropdown - NEEDS CRAWLER */
    @FindBy(xpath = "//select[@formcontrolname='locationType']"
                  + " | //mat-select[@formcontrolname='locationType']"
                  + " | //select[@name='locationType']")
    public WebElement locationTypeDropdown;

    // ── Notes / Comments ──────────────────────────────────────────────────

    /** Notes textarea - NEEDS CRAWLER */
    @FindBy(xpath = "//textarea[@formcontrolname='notes']"
                  + " | //textarea[@name='notes']"
                  + " | //textarea[@placeholder='Notes']")
    public WebElement notesField;

    /** DoITT Comments textarea - NEEDS CRAWLER */
    @FindBy(xpath = "//textarea[@formcontrolname='doittComments']"
                  + " | //textarea[@name='doittComments']"
                  + " | //textarea[@placeholder='DoITT Comments']")
    public WebElement doittCommentsField;

    // ── Form buttons ──────────────────────────────────────────────────────

    /** Save button - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Save']"
                  + " | //input[@type='submit' and @value='Save']"
                  + " | //button[@type='submit' and normalize-space(.)='Save']")
    public WebElement saveButton;

    /** Cancel button - NEEDS CRAWLER */
    @FindBy(xpath = "//button[normalize-space(.)='Cancel']"
                  + " | //input[@type='button' and @value='Cancel']"
                  + " | //a[normalize-space(.)='Cancel']")
    public WebElement cancelButton;

    // ── Reservation confirmation screen elements ──────────────────────────

    /** Reservation number heading (e.g. "Reservation#12345") - NEEDS CRAWLER */
    @FindBy(xpath = "//h1[contains(normalize-space(.),'Reservation#') or contains(normalize-space(.),'Reservation #')]"
                  + " | //h2[contains(normalize-space(.),'Reservation#') or contains(normalize-space(.),'Reservation #')]"
                  + " | //*[contains(@class,'reservation-title') and contains(normalize-space(.),'Reservation')]")
    public WebElement reservationNumberHeading;

    /** Reservation Stage value on the confirmation screen - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Reservation Stage')]/following-sibling::*[1]"
                  + " | //*[@id='reservationStage']"
                  + " | //*[contains(@class,'stage-value')]")
    public WebElement reservationStageValue;

    /** Reservation Status value on confirmation screen - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Reservation Status')]/following-sibling::*[1]"
                  + " | //*[@id='reservationStatus']")
    public WebElement reservationStatusValue;

    /** Pole Type value on confirmation screen - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Pole Type')]/following-sibling::*[1]"
                  + " | //*[@id='poleType']")
    public WebElement poleTypeValue;

    /** Wireless Technology value on confirmation screen - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Wireless Technology')]/following-sibling::*[1]"
                  + " | //*[@id='wirelessTechnology']")
    public WebElement wirelessTechnologyValue;

    /** Wireless Provider value on confirmation screen - NEEDS CRAWLER */
    @FindBy(xpath = "//label[contains(normalize-space(.),'Wireless Provider')]/following-sibling::*[1]"
                  + " | //*[@id='wirelessProvider']")
    public WebElement wirelessProviderValue;

    // ── Actions ───────────────────────────────────────────────────────────

    public boolean isEnterReservationPageLoaded() {
        try {
            waitUntillPageLoad();
            waitForElementPresent(driver, pageHeading);
            log.info("Enter Reservation Details page loaded. URL: " + driver.getCurrentUrl());
            return pageHeading.isDisplayed();
        } catch (Exception e) {
            log.warn("Enter Reservation Details page not loaded: " + e.getMessage());
            return false;
        }
    }

    /** Selects a value from a dropdown — works for both native <select> and Angular mat-select. */
    private void selectDropdownValue(WebElement dropdown, String value) {
        String tag = dropdown.getTagName();
        if ("select".equalsIgnoreCase(tag)) {
            new org.openqa.selenium.support.ui.Select(dropdown).selectByVisibleText(value);
        } else {
            fluentWaitUntilElementToBeClickable(dropdown);
            safeClick(dropdown);
            waitUntillPageLoad();
            WebElement option = driver.findElement(
                By.xpath("//mat-option[normalize-space(.)='" + value + "']"));
            waitForElementPresent(driver, option);
            safeClick(option);
        }
        log.info("Selected '" + value + "' from dropdown");
    }

    public void selectZipCode(String zipCode) {
        log.info("Selecting Zip Code: " + zipCode);
        waitForElementPresent(driver, zipCodeDropdown);
        selectDropdownValue(zipCodeDropdown, zipCode);
    }

    public void selectOrganization(String organization) {
        log.info("Selecting Organization: " + organization);
        waitForElementPresent(driver, organizationDropdown);
        selectDropdownValue(organizationDropdown, organization);
    }

    public void selectName(String name) {
        log.info("Selecting Name: " + name);
        waitForElementPresent(driver, nameDropdown);
        selectDropdownValue(nameDropdown, name);
    }

    public void selectPoleClass(String poleClass) {
        log.info("Selecting Pole Class: " + poleClass);
        if ("Link 5G".equalsIgnoreCase(poleClass)) {
            waitForElementPresent(driver, poleClassLink5GRadio);
            scrollToElement(poleClassLink5GRadio);
            if (!poleClassLink5GRadio.isSelected()) {
                safeClick(poleClassLink5GRadio);
                waitUntillPageLoad();
            }
        } else if ("Utility".equalsIgnoreCase(poleClass)) {
            waitForElementPresent(driver, poleClassUtilityRadio);
            if (!poleClassUtilityRadio.isSelected()) {
                safeClick(poleClassUtilityRadio);
            }
        } else {
            waitForElementPresent(driver, poleClassCityRadio);
            if (!poleClassCityRadio.isSelected()) {
                safeClick(poleClassCityRadio);
            }
        }
    }

    /**
     * Selects Advertisement Panels radio (Yes/No).
     * Only visible after Link 5G pole class is selected.
     */
    public void selectAdvertisementPanels(String yesOrNo) {
        log.info("Selecting Advertisement Panels: " + yesOrNo);
        if ("Yes".equalsIgnoreCase(yesOrNo)) {
            waitForElementPresent(driver, adPanelsYesRadio);
            scrollToElement(adPanelsYesRadio);
            if (!adPanelsYesRadio.isSelected()) {
                safeClick(adPanelsYesRadio);
            }
        } else {
            waitForElementPresent(driver, adPanelsNoRadio);
            scrollToElement(adPanelsNoRadio);
            if (!adPanelsNoRadio.isSelected()) {
                safeClick(adPanelsNoRadio);
            }
        }
    }

    public void selectWirelessTechnology(String technology) {
        log.info("Selecting Wireless Technology: " + technology);
        waitForElementPresent(driver, wirelessTechnologyDropdown);
        selectDropdownValue(wirelessTechnologyDropdown, technology);
    }

    public void selectWirelessProvider(String provider) {
        log.info("Selecting Wireless Provider: " + provider);
        waitForElementPresent(driver, wirelessProviderDropdown);
        selectDropdownValue(wirelessProviderDropdown, provider);
    }

    public void selectProviderService(String activeOrInactive) {
        log.info("Selecting Provider Service: " + activeOrInactive);
        if ("Active".equalsIgnoreCase(activeOrInactive)) {
            waitForElementPresent(driver, providerServiceActiveRadio);
            scrollToElement(providerServiceActiveRadio);
            if (!providerServiceActiveRadio.isSelected()) {
                safeClick(providerServiceActiveRadio);
            }
        } else {
            waitForElementPresent(driver, providerServiceInactiveRadio);
            scrollToElement(providerServiceInactiveRadio);
            if (!providerServiceInactiveRadio.isSelected()) {
                safeClick(providerServiceInactiveRadio);
            }
        }
    }

    public void enterFranchiseeReferenceId(String refId) {
        if (refId == null || refId.isEmpty()) return;
        log.info("Entering Franchisee Reference ID: " + refId);
        waitForElementPresent(driver, franchiseeReferenceIdField);
        clearAndType(franchiseeReferenceIdField, refId);
    }

    public void enterAddress(String address) {
        log.info("Entering Address: " + address);
        waitForElementPresent(driver, addressField);
        clearAndType(addressField, address);
    }

    public void enterOnStreet(String onStreet) {
        log.info("Entering On Street: " + onStreet);
        waitForElementPresent(driver, onStreetField);
        clearAndType(onStreetField, onStreet);
    }

    public void enterCrossStreet1(String crossStreet1) {
        log.info("Entering Cross Street 1: " + crossStreet1);
        waitForElementPresent(driver, crossStreet1Field);
        clearAndType(crossStreet1Field, crossStreet1);
    }

    public void enterCrossStreet2(String crossStreet2) {
        if (crossStreet2 == null || crossStreet2.isEmpty()) return;
        log.info("Entering Cross Street 2: " + crossStreet2);
        waitForElementPresent(driver, crossStreet2Field);
        clearAndType(crossStreet2Field, crossStreet2);
    }

    public void selectLocationType(String locationType) {
        log.info("Selecting Location Type: " + locationType);
        waitForElementPresent(driver, locationTypeDropdown);
        selectDropdownValue(locationTypeDropdown, locationType);
    }

    public void enterNotes(String notes) {
        if (notes == null || notes.isEmpty()) return;
        log.info("Entering Notes: " + notes);
        waitForElementPresent(driver, notesField);
        clearAndType(notesField, notes);
    }

    public void enterDoittComments(String comments) {
        if (comments == null || comments.isEmpty()) return;
        log.info("Entering DoITT Comments: " + comments);
        waitForElementPresent(driver, doittCommentsField);
        clearAndType(doittCommentsField, comments);
    }

    public void clickSave() {
        log.info("Clicking Save to create reservation");
        scrollToElement(saveButton);
        fluentWaitUntilElementToBeClickable(saveButton);
        safeClick(saveButton);
        waitUntillPageLoad();
    }

    public void clickCancel() {
        log.info("Clicking Cancel on reservation form");
        fluentWaitUntilElementToBeClickable(cancelButton);
        safeClick(cancelButton);
        waitUntillPageLoad();
    }

    /**
     * Returns the reservation number from the confirmation screen heading.
     * Extracts the numeric portion from e.g. "Reservation#12345".
     */
    public String getReservationNumber() {
        try {
            waitForElementPresent(driver, reservationNumberHeading);
            String text = safeGetText(reservationNumberHeading).trim();
            log.info("Reservation number heading: " + text);
            return text.replaceAll("[^0-9]", "");
        } catch (Exception e) {
            log.warn("getReservationNumber failed: " + e.getMessage());
            return "";
        }
    }

    public boolean isReservationConfirmationLoaded() {
        try {
            waitUntillPageLoad();
            waitForElementPresent(driver, reservationNumberHeading);
            String heading = safeGetText(reservationNumberHeading).trim();
            log.info("Reservation confirmation heading: " + heading);
            return heading.contains("Reservation");
        } catch (Exception e) {
            log.warn("Reservation confirmation not loaded: " + e.getMessage());
            return false;
        }
    }

    public String getReservationStage() {
        try {
            waitForElementPresent(driver, reservationStageValue);
            String stage = safeGetText(reservationStageValue).trim();
            log.info("Reservation Stage: " + stage);
            return stage;
        } catch (Exception e) {
            log.warn("getReservationStage failed: " + e.getMessage());
            return "";
        }
    }

    public String getReservationStatus() {
        try {
            waitForElementPresent(driver, reservationStatusValue);
            String status = safeGetText(reservationStatusValue).trim();
            log.info("Reservation Status: " + status);
            return status;
        } catch (Exception e) {
            log.warn("getReservationStatus failed: " + e.getMessage());
            return "";
        }
    }

    public String getPoleTypeValue() {
        try {
            waitForElementPresent(driver, poleTypeValue);
            return safeGetText(poleTypeValue).trim();
        } catch (Exception e) {
            return "";
        }
    }

    public String getWirelessTechnologyValue() {
        try {
            waitForElementPresent(driver, wirelessTechnologyValue);
            return safeGetText(wirelessTechnologyValue).trim();
        } catch (Exception e) {
            return "";
        }
    }

    public String getWirelessProviderValue() {
        try {
            waitForElementPresent(driver, wirelessProviderValue);
            return safeGetText(wirelessProviderValue).trim();
        } catch (Exception e) {
            return "";
        }
    }
}
