package com.poletop.automation.uiActions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.sdk.testbase.TestBase;
import com.test.automation.sdk.utility.PageContext;

/**
 * Page Object for Poletop Check Location and Location Details screens.
 * Locators confirmed from live screenshots on 2026-08-08.
 *
 * Flow: Dashboard -> Maps (dropdown) -> Check Location -> enter coords -> Submit -> Location Details
 *
 * Test Case ID : ADO-233502
 */
public class PoletopCheckLocationPage extends TestBase {

    public static final Logger log = LogManager.getLogger(PoletopCheckLocationPage.class.getName());

    public PoletopCheckLocationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageContext.currentPage.set("PoletopCheckLocationPage");
    }

    // ------ Top navigation ------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Confirmed from screenshot: "Maps" with dropdown caret in top nav bar

    /** "Maps" nav dropdown — id=nav-item-02 - UNIQUE ✓ */
    @FindBy(xpath = "//a[@id='nav-item-02']")
    public WebElement mapsMenuLink;

    // "Check Location" appears in Maps dropdown after clicking Maps
    @FindBy(xpath = "//a[normalize-space(.)='Check Location']")
    public WebElement checkLocationMenuOption;

    // ------ Check Location page ---------------------------------------------------------------------------------------------------------------------------------------------
    // Confirmed: page has <h1> or large heading "Check Location"

    @FindBy(xpath = "//h1[normalize-space(.)='Check Location'] | //h2[normalize-space(.)='Check Location']")
    public WebElement checkLocationPageTitle;

    // Radio buttons — UNIQUE ✓ confirmed by crawler 2026-08-12
    @FindBy(xpath = "//input[@id='xy']")
    public WebElement xyRadioButton;

    @FindBy(xpath = "//input[@id='latlong']")
    public WebElement latLongRadioButton;

    // X/Y coordinate inputs — UNIQUE ✓ confirmed by crawler 2026-08-12
    @FindBy(xpath = "//input[@id='x']")
    public WebElement xCoordinateField;

    @FindBy(xpath = "//input[@id='y']")
    public WebElement yCoordinateField;

    // Submit button: confirmed "Submit" blue button at bottom
    @FindBy(xpath = "//button[normalize-space(.)='Submit']")
    public WebElement submitButton;

    // Location Details page

    @FindBy(xpath = "//h1[normalize-space(.)='Location Details'] | //h2[normalize-space(.)='Location Details']")
    public WebElement locationDetailsPageTitle;

    /** Green "Available" badge in Location Details - confirmed from screenshot */
    @FindBy(xpath = "//td[normalize-space(.)='Availability']/following-sibling::td[1]//*[normalize-space(.)!='']"
                  + " | //*[contains(@class,'badge') and normalize-space(.)!='']"
                  + " | //span[normalize-space(.)='Available']"
                  + " | //td[following-sibling::td[contains(@class,'badge')]]")
    public WebElement availabilityStatusBadge;

    /** "Check Another Location" button - confirmed from screenshot (outline button) */
    @FindBy(xpath = "//button[normalize-space(.)='Check Another Location']"
                  + " | //a[normalize-space(.)='Check Another Location']")
    public WebElement checkAnotherLocationRadio;

    /** "Enter Reservation Details" button - confirmed from screenshot (solid blue button) */
    @FindBy(xpath = "//button[normalize-space(.)='Enter Reservation Details']"
                  + " | //a[normalize-space(.)='Enter Reservation Details']")
    public WebElement enterReservationDetailsRadio;

    // checkAnotherLocationButton is the same element - alias for backward compat
    @FindBy(xpath = "//button[normalize-space(.)='Check Another Location']"
                  + " | //a[normalize-space(.)='Check Another Location']")
    public WebElement checkAnotherLocationButton;

    // Role detection helpers

    public boolean hasCheckAnotherLocationRadio() {
        return driver.findElements(By.xpath(
            "//button[normalize-space(.)='Check Another Location']"
        )).size() > 0;
    }

    public boolean hasCheckAnotherLocationButton() {
        return driver.findElements(By.xpath(
            "//button[normalize-space(.)='Check Another Location']"
        )).size() > 0;
    }

    // ------ Actions ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public void navigateToCheckLocation() {
        log.info("Navigating: Maps > Check Location");
        // Click Maps dropdown in top nav
        waitForElementPresent(driver, mapsMenuLink);
        fluentWaitUntilElementToBeClickable(mapsMenuLink);
        safeClick(mapsMenuLink);
        waitUntillPageLoad();
        // Click Check Location from dropdown
        waitForElementPresent(driver, checkLocationMenuOption);
        fluentWaitUntilElementToBeClickable(checkLocationMenuOption);
        safeClick(checkLocationMenuOption);
        waitUntillPageLoad();
        log.info("On Check Location page: " + driver.getCurrentUrl());
    }

    public void enterXYCoordinates(String x, String y) {
        log.info("Entering X=" + x + " Y=" + y);
        waitForElementPresent(driver, xyRadioButton);
        if (!xyRadioButton.isSelected()) {
            safeClick(xyRadioButton);
            waitUntillPageLoad();
        }
        // id-confirmed locators from crawler UNIQUE ✓
        waitForElementPresent(driver, xCoordinateField);
        clearAndType(xCoordinateField, x);
        waitForElementPresent(driver, yCoordinateField);
        clearAndType(yCoordinateField, y);
        log.info("X/Y coordinates entered");
    }

    public void enterLatLongCoordinates(String lat, String lon) {
        log.info("Entering Lat=" + lat + " Lon=" + lon);
        waitForElementPresent(driver, latLongRadioButton);
        if (!latLongRadioButton.isSelected()) {
            safeClick(latLongRadioButton);
            waitUntillPageLoad();
        }
        // After switching to Lat/Long, placeholders change to "e.g. 00.00000" / "e.g. -00.00000"
        WebElement latField = driver.findElement(By.xpath(
            "//input[@placeholder='e.g. 00.00000'] | (//input[@placeholder='e.g. 000000'])[1]"));
        WebElement lonField = driver.findElement(By.xpath(
            "//input[@placeholder='e.g. -00.00000'] | (//input[@placeholder='e.g. 000000'])[2]"));
        waitForElementPresent(driver, latField);
        clearAndType(latField, lat);
        waitForElementPresent(driver, lonField);
        clearAndType(lonField, lon);
        log.info("Lat/Long coordinates entered");
    }

    public void clickSubmit() {
        log.info("Clicking Submit");
        waitForElementPresent(driver, submitButton);
        // Scroll Submit into view --- it may be below the visible viewport
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitButton);
        waitForElementPresent(driver, submitButton);
        fluentWaitUntilElementToBeClickable(submitButton);
        safeClick(submitButton);
        waitUntillPageLoad();
        log.info("After submit --- URL: " + driver.getCurrentUrl());
    }

    public boolean isLocationDetailsLoaded() {
        try {
            waitUntillPageLoad();
            waitForElementPresent(driver, locationDetailsPageTitle);
            ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView(true);", locationDetailsPageTitle);
            return locationDetailsPageTitle.isDisplayed();
        } catch (Exception e) {
            log.warn("Location Details not loaded: " + e.getMessage() + " | URL: " + driver.getCurrentUrl());
            return false;
        }
    }

    public boolean isCheckLocationPageLoaded() {
        try {
            waitUntillPageLoad();
            waitForElementPresent(driver, checkLocationPageTitle);
            return checkLocationPageTitle.isDisplayed();
        } catch (Exception e) {
            log.warn("Check Location page not loaded: " + e.getMessage());
            return false;
        }
    }

    public String getAvailabilityStatus() {
        waitUntillPageLoad();
        waitForElementPresent(driver, availabilityStatusBadge);
        String status = safeGetText(availabilityStatusBadge).trim();
        log.info("Availability status: " + status);
        return status;
    }

    public boolean isAvailable() {
        return getAvailabilityStatus().toLowerCase().contains("available");
    }

    public void selectCheckAnotherLocation() {
        log.info("Clicking 'Check Another Location' button");
        waitForElementPresent(driver, checkAnotherLocationButton);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkAnotherLocationButton);
        fluentWaitUntilElementToBeClickable(checkAnotherLocationButton);
        safeClick(checkAnotherLocationButton);
        waitUntillPageLoad();
    }

    public void selectEnterReservationDetails() {
        log.info("Clicking 'Enter Reservation Details' button");
        waitForElementPresent(driver, enterReservationDetailsRadio);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", enterReservationDetailsRadio);
        fluentWaitUntilElementToBeClickable(enterReservationDetailsRadio);
        safeClick(enterReservationDetailsRadio);
        waitUntillPageLoad();
    }

    public boolean isFranchiseeView() {
        return driver.findElements(By.xpath(
            "//a[normalize-space(.)='Billing Report']")).size() > 0;
    }
}
