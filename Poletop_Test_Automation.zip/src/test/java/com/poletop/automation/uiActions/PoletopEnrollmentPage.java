package com.poletop.automation.uiActions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.test.automation.sdk.testbase.TestBase;
import com.test.automation.sdk.utility.PageContext;

/**
 * Page Object for the Poletop Enrollment form.
 * URL: https://poletop-stg.csc.nycnet/#/enroll
 *
 * Locators should be verified via LocatorInvestigator before use.
 * @author vkruglyak
 */
public class PoletopEnrollmentPage extends TestBase {

    public static final Logger log = LogManager.getLogger(PoletopEnrollmentPage.class.getName());

    public PoletopEnrollmentPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        PageContext.currentPage.set("PoletopEnrollmentPage");
    }

    // ── Enrollment form elements ──────────────────────────────────────────

    @CacheLookup
    @FindBy(xpath = "//h1[contains(normalize-space(.),'Enroll')]"
                  + " | //h2[contains(normalize-space(.),'Enroll')]")
    public WebElement pageHeading;

    @FindBy(xpath = "//input[@id='poleId']"
                  + " | //input[@formcontrolname='poleId']"
                  + " | //input[@placeholder='Enter Pole ID']")
    public WebElement poleIdField;

    @FindBy(xpath = "//select[@formcontrolname='borough']"
                  + " | //mat-select[@formcontrolname='borough']")
    public WebElement boroughDropdown;

    @FindBy(xpath = "//input[@formcontrolname='address']"
                  + " | //input[@name='address']"
                  + " | //input[@placeholder='Address']")
    public WebElement addressField;

    @FindBy(xpath = "//select[@formcontrolname='poleType']"
                  + " | //mat-select[@formcontrolname='poleType']")
    public WebElement poleTypeDropdown;

    @FindBy(xpath = "//input[@formcontrolname='applicantName']"
                  + " | //input[@placeholder='Applicant Name']")
    public WebElement applicantNameField;

    @FindBy(xpath = "//input[@formcontrolname='phone']"
                  + " | //input[@placeholder='Phone']")
    public WebElement phoneField;

    @FindBy(xpath = "//input[@formcontrolname='contactEmail']"
                  + " | //input[@placeholder='Contact Email']")
    public WebElement contactEmailField;

    @FindBy(xpath = "//textarea[@formcontrolname='notes']"
                  + " | //textarea[@placeholder='Notes']")
    public WebElement notesField;

    @FindBy(xpath = "//button[@type='submit' and normalize-space(.)='Submit']"
                  + " | //button[@type='submit' and normalize-space(.)='Enroll']"
                  + " | //button[contains(@class,'enroll')]")
    public WebElement submitButton;

    // ── Confirmation / error elements ────────────────────────────────────

    @FindBy(xpath = "//div[contains(@class,'alert-success') and normalize-space(.)!='']"
                  + " | //mat-snack-bar-container[normalize-space(.)!='']")
    public WebElement successMessage;

    @FindBy(xpath = "//*[contains(@class,'confirmation-number') and normalize-space(.)!='']"
                  + " | //*[contains(@id,'confirmationNumber') and normalize-space(.)!='']")
    public WebElement confirmationNumberElement;

    @FindBy(xpath = "//div[contains(@class,'alert-danger') and normalize-space(.)!='']"
                  + " | //mat-error[normalize-space(.)!='']")
    public WebElement formErrorMessage;

    // ── Actions ───────────────────────────────────────────────────────────

    public String getPageHeadingText() {
        waitForElementPresent(driver, pageHeading);
        log.info("Enrollment page heading: " + pageHeading.getText());
        return pageHeading.getText();
    }

    public void fillEnrollmentForm(String poleId, String borough, String address,
            String poleType, String applicantName, String phone,
            String contactEmail, String notes) {

        log.info("Filling enrollment form — poleId: " + poleId);
        fluentWaitUntilElementToBeClickable(poleIdField);
        clearAndType(poleIdField, poleId);

        if ("select".equalsIgnoreCase(boroughDropdown.getTagName())) {
            new Select(boroughDropdown).selectByVisibleText(borough);
        } else {
            safeClick(boroughDropdown);
            safeClick(driver.findElement(
                org.openqa.selenium.By.xpath("//mat-option[normalize-space(.)='" + borough + "']")));
        }

        clearAndType(addressField, address);

        if ("select".equalsIgnoreCase(poleTypeDropdown.getTagName())) {
            new Select(poleTypeDropdown).selectByVisibleText(poleType);
        } else {
            safeClick(poleTypeDropdown);
            safeClick(driver.findElement(
                org.openqa.selenium.By.xpath("//mat-option[normalize-space(.)='" + poleType + "']")));
        }

        clearAndType(applicantNameField, applicantName);
        clearAndType(phoneField, phone);
        clearAndType(contactEmailField, contactEmail);
        if (notes != null && !notes.isEmpty()) {
            clearAndType(notesField, notes);
        }
    }

    public void submitEnrollment() {
        log.info("Submitting enrollment form");
        scrollToElement(submitButton);
        fluentWaitUntilElementToBeClickable(submitButton);
        safeClick(submitButton);
        waitUntillPageLoad();
    }

    public boolean isEnrollmentSuccessful() {
        try {
            waitForElementPresent(driver, successMessage);
            log.info("Enrollment success message: " + successMessage.getText());
            return successMessage.isDisplayed();
        } catch (Exception e) {
            log.info("Success message not found: " + e.getMessage());
            return false;
        }
    }

    public String getSuccessMessageText() {
        waitForElementPresent(driver, successMessage);
        return successMessage.getText();
    }

    public String getConfirmationNumber() {
        waitForElementPresent(driver, confirmationNumberElement);
        return confirmationNumberElement.getText();
    }

    public boolean isFormErrorDisplayed() {
        try {
            waitForElementPresent(driver, formErrorMessage);
            return formErrorMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
