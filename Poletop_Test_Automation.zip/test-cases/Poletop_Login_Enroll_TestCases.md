# Poletop Automation – Test Case Specifications

**Application:** Poletop STG  
**Base URL:** `https://poletop-stg.csc.nycnet/#/dashboard`  
**Framework:** Selenium WebDriver + TestNG + Page Object Model  
**Author:** vkruglyak  
**Last Updated:** 2026-08-06  

---

## Table of Contents

- [TC-LOGIN-001 – Valid Login](#tc-login-001--valid-login)
- [TC-LOGIN-002 – Invalid Password](#tc-login-002--invalid-password)
- [TC-LOGIN-003 – Empty Credentials](#tc-login-003--empty-credentials)
- [TC-ENROLL-001 – Successful Enrollment](#tc-enroll-001--successful-enrollment)
- [TC-ENROLL-002 – Missing Required Fields](#tc-enroll-002--missing-required-fields)
- [Test Data Setup](#test-data-setup)

---

## Login Tests — `Test_PoletopLogin.java`

---

### TC-LOGIN-001 – Valid Login

| Field              | Detail |
|--------------------|--------|
| **Test Case ID**   | TC-LOGIN-001 |
| **Test Class**     | `Test_PoletopLogin` |
| **Method**         | `testValidLogin` |
| **Priority**       | P1 – Critical |
| **Type**           | Functional / Positive |
| **Excel Sheet**    | `PoletopLogin` |

**Objective**  
Verify that a registered user with valid credentials can successfully log in and is redirected to the Poletop dashboard.

**Preconditions**
- Browser is open and configured
- Application is accessible at `https://poletop-stg.csc.nycnet/#/dashboard`
- A valid user account exists in the STG environment
- Test data row has `runMode = Y`

**Test Steps**

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to `https://poletop-stg.csc.nycnet/#/dashboard` | Login page / landing screen is displayed |
| 2 | Enter valid **email** from the `PoletopLogin` Excel sheet | Email is entered in the email field |
| 3 | Enter valid **password** from the `PoletopLogin` Excel sheet | Password is entered in the password field |
| 4 | Click the **Login** button | Login form is submitted |
| 5 | Wait for page to load | Dashboard page loads successfully |
| 6 | Verify dashboard heading is visible and not empty | Dashboard heading element is displayed with text |
| 7 | Log out to clean up session | User is logged out; login screen is visible again |

**Expected Results**
- ✅ Dashboard is loaded after login (`isDashboardLoaded()` returns `true`)
- ✅ Dashboard heading text is not empty
- ✅ No error messages are displayed
- ✅ User session is terminated after logout

**Test Data (Excel – PoletopLogin sheet)**

| Column | Example Value |
|--------|---------------|
| testCaseName | TC-LOGIN-001 Valid Login |
| email | testuser@example.com |
| password | Test@1234 |
| expectedResult | Dashboard |
| runMode | Y |

---

### TC-LOGIN-002 – Invalid Password

| Field              | Detail |
|--------------------|--------|
| **Test Case ID**   | TC-LOGIN-002 |
| **Test Class**     | `Test_PoletopLogin` |
| **Method**         | `testInvalidLogin` |
| **Priority**       | P1 – Critical |
| **Type**           | Functional / Negative |
| **Excel Sheet**    | `PoletopLogin` |

**Objective**  
Verify that submitting an incorrect password shows an error message and prevents access to the dashboard.

**Preconditions**
- Browser is open and configured
- Application is accessible
- A valid user email exists; an incorrect password will be constructed by appending `_WRONG` to the data-row password
- Test data row has `runMode = Y`

**Test Steps**

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to `https://poletop-stg.csc.nycnet/#/dashboard` | Login page is displayed |
| 2 | Enter valid **email** from the Excel sheet | Email field is populated |
| 3 | Enter **wrong password** (data-row password + `_WRONG` suffix) | Password field is populated with incorrect value |
| 4 | Click the **Login** button | Login form is submitted |
| 5 | Wait for page to respond | Page finishes loading |
| 6 | Verify an error message is visible on the page | Error / alert message element is displayed |
| 7 | Verify the user is NOT on the dashboard | Dashboard heading element is NOT visible |

**Expected Results**
- ✅ Error message is displayed (`isLoginErrorDisplayed()` returns `true`)
- ✅ Dashboard is NOT loaded (`isDashboardLoaded()` returns `false`)
- ✅ User remains on the login screen

**Test Data (Excel – PoletopLogin sheet)**

| Column | Example Value |
|--------|---------------|
| testCaseName | TC-LOGIN-002 Invalid Password |
| email | testuser@example.com |
| password | Test@1234 *(wrong password constructed at runtime)* |
| expectedResult | Error message |
| runMode | Y |

---

### TC-LOGIN-003 – Empty Credentials

| Field              | Detail |
|--------------------|--------|
| **Test Case ID**   | TC-LOGIN-003 |
| **Test Class**     | `Test_PoletopLogin` |
| **Method**         | `testLoginWithEmptyFields` |
| **Priority**       | P2 – High |
| **Type**           | Functional / Negative / Boundary |
| **Excel Sheet**    | `PoletopLogin` |

**Objective**  
Verify that submitting the login form with both fields empty triggers client-side or server-side validation messages and does not proceed to the dashboard.

**Preconditions**
- Browser is open and configured
- Application is accessible
- Test data row has `runMode = Y` (only the first `Y` row is used; email/password columns are ignored — blank values are submitted)

**Test Steps**

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to `https://poletop-stg.csc.nycnet/#/dashboard` | Login page is displayed |
| 2 | Leave the **email** field blank | Field remains empty |
| 3 | Leave the **password** field blank | Field remains empty |
| 4 | Click the **Login** button | Form submission is attempted |
| 5 | Wait for page to respond | Page finishes loading |
| 6 | Verify a validation / error message is visible | Validation or error message element is displayed |
| 7 | Verify user is NOT on the dashboard | Dashboard heading element is NOT visible |

**Expected Results**
- ✅ Validation or error message is displayed (`isLoginErrorDisplayed()` returns `true`)
- ✅ Dashboard is NOT loaded (`isDashboardLoaded()` returns `false`)
- ✅ User remains on the login screen

**Test Data (Excel – PoletopLogin sheet)**

| Column | Example Value |
|--------|---------------|
| testCaseName | TC-LOGIN-003 Empty Fields |
| email | *(any – ignored at runtime, blank is submitted)* |
| password | *(any – ignored at runtime, blank is submitted)* |
| expectedResult | Validation message |
| runMode | Y |

---

## Enrollment Tests — `Test_PoletopEnroll.java`

---

### TC-ENROLL-001 – Successful Enrollment

| Field              | Detail |
|--------------------|--------|
| **Test Case ID**   | TC-ENROLL-001 |
| **Test Class**     | `Test_PoletopEnroll` |
| **Method**         | `testSuccessfulEnrollment` |
| **Priority**       | P1 – Critical |
| **Type**           | Functional / End-to-End / Positive |
| **Excel Sheet**    | `PoletopEnroll` |

**Objective**  
Verify the complete end-to-end enrollment flow: a logged-in user fills in all required fields on the enrollment form, submits it, and receives a confirmation/reference number.

**Preconditions**
- Browser is open and configured
- Application is accessible at `https://poletop-stg.csc.nycnet/#/dashboard`
- A valid user account exists in the STG environment
- Valid enrollment test data is present in the `PoletopEnroll` Excel sheet
- Test data row has `runMode = Y`

**Test Steps**

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to `https://poletop-stg.csc.nycnet/#/dashboard` | Application landing / login page loads |
| 2 | Enter valid **email** and **password** and click Login | User is authenticated |
| 3 | Verify dashboard is loaded | Dashboard heading is visible |
| 4 | Click the **Enroll** navigation link on the dashboard | Browser navigates to the Enrollment form page |
| 5 | Verify enrollment page heading is visible and not empty | Enrollment page is loaded |
| 6 | Enter **Pole ID** from the Excel sheet | Pole ID field is populated |
| 7 | Select **Borough** from the dropdown | Borough is selected |
| 8 | Enter **Address** from the Excel sheet | Address field is populated |
| 9 | Select **Pole Type** from the dropdown | Pole type is selected |
| 10 | Enter **Applicant Name** from the Excel sheet | Applicant name field is populated |
| 11 | Enter **Phone** number from the Excel sheet | Phone field is populated |
| 12 | Enter **Contact Email** from the Excel sheet | Contact email field is populated |
| 13 | Enter **Notes** if provided | Notes field is populated (skipped if empty) |
| 14 | Scroll to and click the **Submit** button | Enrollment form is submitted |
| 15 | Wait for page to respond | Page finishes processing |
| 16 | Verify success message is displayed | Success / confirmation message element is visible |
| 17 | Verify success message text is not empty | Confirmation text is present |
| 18 | Capture and verify **confirmation / reference number** | Reference number element is visible and not empty |
| 19 | Log out to clean up session | User is logged out |

**Expected Results**
- ✅ User successfully logs in and reaches the dashboard
- ✅ Enrollment page loads after clicking the Enroll link
- ✅ All form fields accept the provided input
- ✅ Success message is displayed after submission (`isEnrollmentSuccessful()` returns `true`)
- ✅ Success message text is not empty
- ✅ Confirmation / reference number is displayed and not empty
- ✅ User session is terminated after logout

**Test Data (Excel – PoletopEnroll sheet)**

| Column | Example Value |
|--------|---------------|
| testCaseName | TC-ENROLL-001 Successful Enrollment |
| email | testuser@example.com |
| password | Test@1234 |
| poleId | POLE-2026-0001 |
| borough | Manhattan |
| address | 123 Main St, New York, NY 10001 |
| poleType | Street Light Pole |
| applicantName | John Smith |
| phone | 212-555-0100 |
| contactEmail | jsmith@example.com |
| notes | Test enrollment – STG environment |
| runMode | Y |

---

### TC-ENROLL-002 – Missing Required Fields

| Field              | Detail |
|--------------------|--------|
| **Test Case ID**   | TC-ENROLL-002 |
| **Test Class**     | `Test_PoletopEnroll` |
| **Method**         | `testEnrollmentWithMissingRequiredFields` |
| **Priority**       | P2 – High |
| **Type**           | Functional / Negative / Boundary |
| **Excel Sheet**    | `PoletopEnroll` |

**Objective**  
Verify that submitting the enrollment form with required fields (**Pole ID** and **Address**) left blank shows a validation error and does not complete the enrollment.

**Preconditions**
- Browser is open and configured
- Application is accessible
- A valid user account exists in the STG environment
- Test data row has `runMode = Y`
- Note: Pole ID and Address will be submitted as empty strings regardless of the Excel data

**Test Steps**

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Navigate to `https://poletop-stg.csc.nycnet/#/dashboard` | Application landing / login page loads |
| 2 | Enter valid **email** and **password** and click Login | User is authenticated |
| 3 | Verify dashboard is loaded | Dashboard heading is visible |
| 4 | Click the **Enroll** navigation link | Browser navigates to the Enrollment form |
| 5 | Leave **Pole ID** field blank | Pole ID field is empty |
| 6 | Select **Borough** from the dropdown | Borough is selected |
| 7 | Leave **Address** field blank | Address field is empty |
| 8 | Fill remaining optional fields with valid data | Fields are populated |
| 9 | Click the **Submit** button | Form submission is attempted |
| 10 | Wait for page to respond | Page finishes processing |
| 11 | Verify form error message is displayed | Validation / error element is visible |
| 12 | Verify success message is NOT displayed | Success element is not present |
| 13 | Log out to clean up session | User is logged out |

**Expected Results**
- ✅ Form error / validation message is displayed (`isFormErrorDisplayed()` returns `true`)
- ✅ Enrollment does NOT succeed (`isEnrollmentSuccessful()` returns `false`)
- ✅ User remains on the enrollment form page
- ✅ User session is terminated after logout

**Test Data (Excel – PoletopEnroll sheet)**

| Column | Example Value |
|--------|---------------|
| testCaseName | TC-ENROLL-002 Missing Required Fields |
| email | testuser@example.com |
| password | Test@1234 |
| poleId | *(any – overridden with blank at runtime)* |
| borough | Brooklyn |
| address | *(any – overridden with blank at runtime)* |
| poleType | Street Light Pole |
| applicantName | Jane Doe |
| phone | 212-555-0200 |
| contactEmail | jdoe@example.com |
| notes | Negative test – missing required fields |
| runMode | Y |

---

## Test Data Setup

### Excel File Location
```
src/main/java/com/automation/poletop/testData/POLETOP_STG_TestData.xlsx
```

### Required Sheets

#### Sheet: `PoletopLogin`

| # | Column | Type | Notes |
|---|--------|------|-------|
| 1 | testCaseName | String | Descriptive name for the test row |
| 2 | email | String | Registered user email |
| 3 | password | String | User password |
| 4 | expectedResult | String | Human-readable expected outcome |
| 5 | runMode | String | `Y` = execute, `N` = skip |

#### Sheet: `PoletopEnroll`

| # | Column | Type | Notes |
|---|--------|------|-------|
| 1 | testCaseName | String | Descriptive name for the test row |
| 2 | email | String | Registered user email |
| 3 | password | String | User password |
| 4 | poleId | String | Unique pole / asset identifier |
| 5 | borough | String | Must match dropdown option exactly |
| 6 | address | String | Full street address |
| 7 | poleType | String | Must match dropdown option exactly |
| 8 | applicantName | String | Full name of the applicant |
| 9 | phone | String | Contact phone number |
| 10 | contactEmail | String | Contact email address |
| 11 | notes | String | Optional notes (can be blank) |
| 12 | runMode | String | `Y` = execute, `N` = skip |

---

## Test Execution Notes

### Running via TestNG XML
```xml
<suite name="Poletop Suite" verbose="1">
  <test name="Poletop Login Tests">
    <parameter name="environment" value="stg"/>
    <parameter name="browserName" value="chrome"/>
    <classes>
      <class name="com.poletop.automation.testCases.Test_PoletopLogin"/>
    </classes>
  </test>
  <test name="Poletop Enroll Tests">
    <parameter name="environment" value="stg"/>
    <parameter name="browserName" value="chrome"/>
    <classes>
      <class name="com.poletop.automation.testCases.Test_PoletopEnroll"/>
    </classes>
  </test>
</suite>
```

### Running via Maven
```bash
mvn test -Dtest=Test_PoletopLogin,Test_PoletopEnroll -Denvironment=stg -DbrowserName=chrome
```

### Pre-Run Checklist
- [ ] STG environment is accessible
- [ ] `POLETOP_STG_TestData.xlsx` contains `PoletopLogin` and `PoletopEnroll` sheets with at least one `runMode=Y` row
- [ ] All `// TODO: verify` XPath/CSS selectors in page objects have been updated to match the live UI
- [ ] ChromeDriver version matches installed Chrome version
