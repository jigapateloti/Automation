# PoleTop Manager — Test Cases
**Application:** PoleTop Manager (NYC Office of Technology & Innovation)  
**Environment:** Staging — https://poletop-stg.csc.nycnet/#/dashboard  
**Source:** Codebase analysis (page objects + test files)

---

## Table of Contents
1. [Authentication — Login](#1-authentication--login)
2. [Authentication — Social Login](#2-authentication--social-login)
3. [Authentication — Forgot Password](#3-authentication--forgot-password)
4. [Account Creation](#4-account-creation)
5. [Profile — Name Management](#5-profile--name-management)
6. [Profile — Email Address Management](#6-profile--email-address-management)
7. [Profile — Password Management](#7-profile--password-management)
8. [Profile — Security Questions](#8-profile--security-questions)
9. [Profile — Account Deactivation](#9-profile--account-deactivation)
10. [Logout](#10-logout)

---

## 1. Authentication — Login

### TC-001: Successful login with valid credentials
**Priority:** High | **Type:** Functional  
**Preconditions:** User has a registered NYC.ID account

**Steps:**
1. Navigate to `https://poletop-stg.csc.nycnet/#/dashboard`
2. Verify login page loads with "Log in using one of these options" label
3. Enter a valid registered email/username in the Login ID field
4. Enter the correct password
5. Click the **Log In** button

**Expected Result:** User is authenticated and redirected to the dashboard

---

### TC-002: Login with invalid credentials
**Priority:** High | **Type:** Functional  
**Preconditions:** Application is accessible

**Steps:**
1. Navigate to the login page
2. Enter an incorrect email/username
3. Enter an incorrect password
4. Click **Log In**

**Expected Result:** Error message: "The combination of email address or username and password was not found."

---

### TC-003: Login with empty username field
**Priority:** Medium | **Type:** Functional  
**Preconditions:** Application is accessible

**Steps:**
1. Navigate to the login page
2. Leave the Login ID field empty
3. Enter any value in the Password field
4. Click **Log In**

**Expected Result:** Validation message "This field is required." appears under the Login ID field

---

### TC-004: Login with empty password field
**Priority:** Medium | **Type:** Functional  
**Preconditions:** Application is accessible

**Steps:**
1. Navigate to the login page
2. Enter a valid username
3. Leave the Password field empty
4. Click **Log In**

**Expected Result:** Validation message "This field is required." appears under the Password field

---

### TC-005: Login with both fields empty
**Priority:** Medium | **Type:** Functional  
**Preconditions:** Application is accessible

**Steps:**
1. Navigate to the login page
2. Leave both Login ID and Password fields empty
3. Click **Log In**

**Expected Result:** Validation messages appear for both required fields; login is not attempted

---

### TC-006: Login page displays all expected UI elements
**Priority:** Medium | **Type:** Smoke & Sanity  
**Preconditions:** Application is accessible

**Steps:**
1. Navigate to `https://poletop-stg.csc.nycnet/#/dashboard`
2. Inspect the login page

**Expected Result:** Page displays: Login ID field, Password field, Log In button, Forgot Password link, Create Account link, social login options (NYC Employees, Facebook, Google, Microsoft, LinkedIn, Yahoo, Apple), Report an Issue link

---

### TC-007: Login with locked/suspended account
**Priority:** Medium | **Type:** Functional  
**Preconditions:** A locked or suspended account exists

**Steps:**
1. Navigate to the login page
2. Enter credentials for a locked/suspended account
3. Click **Log In**

**Expected Result:** Appropriate error message displayed (unsuccessful login error code 403041)

---

## 2. Authentication — Social Login

### TC-008: Login via NYC Employees button
**Priority:** High | **Type:** Functional  
**Preconditions:** User has NYC Employee credentials

**Steps:**
1. Navigate to the login page
2. Click the **NYC Employees** button
3. Complete the NYC Employee SSO authentication flow

**Expected Result:** User is redirected to NYC Employee SSO and can authenticate successfully

---

### TC-009: Login via Google
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User has a Google account linked to their NYC.ID

**Steps:**
1. Navigate to the login page
2. Click the **Google** social login button
3. Complete Google OAuth flow

**Expected Result:** User is redirected to Google login; upon success is authenticated into PoleTop Manager

---

### TC-010: Login via Microsoft
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User has a Microsoft account linked to their NYC.ID

**Steps:**
1. Navigate to the login page
2. Click the **Microsoft** social login button
3. Complete Microsoft OAuth flow

**Expected Result:** User is redirected to Microsoft login; upon success is authenticated into PoleTop Manager

---

### TC-011: Login via LinkedIn
**Priority:** Low | **Type:** Functional  
**Preconditions:** User has a LinkedIn account linked to their NYC.ID

**Steps:**
1. Navigate to the login page
2. Click the **LinkedIn** social login button
3. Complete LinkedIn OAuth flow

**Expected Result:** User is redirected to LinkedIn login; upon success is authenticated into PoleTop Manager

---

### TC-012: Login via Facebook
**Priority:** Low | **Type:** Functional  

**Steps:**
1. Navigate to the login page
2. Click the **Facebook** social login button

**Expected Result:** User is redirected to Facebook OAuth login page

---

### TC-013: Login via Yahoo
**Priority:** Low | **Type:** Functional  

**Steps:**
1. Navigate to the login page
2. Click the **Yahoo** social login button

**Expected Result:** User is redirected to Yahoo OAuth login page

---

### TC-014: Login via Apple
**Priority:** Low | **Type:** Functional  

**Steps:**
1. Navigate to the login page
2. Click the **Apple** social login button

**Expected Result:** User is redirected to Apple ID login page

---

## 3. Authentication — Forgot Password

### TC-015: Forgot Password link is accessible
**Priority:** High | **Type:** Functional  

**Steps:**
1. Navigate to the login page
2. Click the **Forgot Password** link

**Expected Result:** User is redirected to the password reset page/flow

---

### TC-016: Password reset with valid registered email
**Priority:** High | **Type:** Functional  
**Preconditions:** User has a registered account

**Steps:**
1. Click **Forgot Password** on the login page
2. Enter a valid registered email address
3. Submit the form

**Expected Result:** Password reset email is sent; confirmation message displayed

---

### TC-017: Password reset with unregistered email
**Priority:** Medium | **Type:** Functional  

**Steps:**
1. Click **Forgot Password** on the login page
2. Enter an email address not registered in the system
3. Submit the form

**Expected Result:** Generic message displayed (no account enumeration); no reset email sent

---

## 4. Account Creation

### TC-018: Successful new account creation
**Priority:** High | **Type:** Functional  
**Preconditions:** User does not have an existing NYC.ID account; valid email available

**Steps:**
1. Navigate to the login page and click **Create Account**
2. Enter a valid email address
3. Enter the same email in Confirm Email Address
4. Enter a valid password (min 8 chars, at least 1 letter + 1 number/special char)
5. Enter the same password in Confirm Password
6. Select a security question from the dropdown
7. Enter an answer for the security question
8. Click the Show toggle
9. Check the Terms of Use checkbox
10. Click **Create Account**

**Expected Result:** Account created; confirmation email sent page displayed; user receives confirmation email

---

### TC-019: Account creation with mismatched email addresses
**Priority:** High | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Enter a valid email in Email Address field
3. Enter a different email in Confirm Email Address
4. Fill in all other required fields correctly
5. Click **Create Account**

**Expected Result:** Validation error: email addresses do not match

---

### TC-020: Account creation with mismatched passwords
**Priority:** High | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Fill in email fields correctly
3. Enter a valid password in Password field
4. Enter a different value in Confirm Password
5. Click **Create Account**

**Expected Result:** Validation error: passwords do not match

---

### TC-021: Account creation with weak/invalid password
**Priority:** High | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Fill in email fields correctly
3. Enter a password shorter than 8 characters (e.g., "abc123")
4. Click **Create Account**

**Expected Result:** Validation error: password must be at least 8 characters with at least one letter and one number or special character

---

### TC-022: Account creation without accepting Terms of Use
**Priority:** High | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Fill in all fields correctly
3. Do NOT check the Terms of Use checkbox
4. Click **Create Account**

**Expected Result:** Form submission blocked; error prompts user to accept Terms of Use

---

### TC-023: Account creation with already-registered email
**Priority:** High | **Type:** Functional  
**Preconditions:** An account with the test email already exists

**Steps:**
1. Navigate to Create Account page
2. Enter an already-registered email address
3. Fill in all other fields correctly
4. Click **Create Account**

**Expected Result:** Error message indicating the email is already registered

---

### TC-024: Account creation with all fields empty
**Priority:** Medium | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Leave all fields empty
3. Click **Create Account**

**Expected Result:** Validation errors displayed for all required fields

---

### TC-025: Show/Hide password toggle on Create Account page
**Priority:** Low | **Type:** Functional  

**Steps:**
1. Navigate to Create Account page
2. Enter a password in the Password field
3. Click the **Show** toggle
4. Verify password is visible as plain text
5. Click the **Hide** toggle
6. Verify password is masked

**Expected Result:** Password visibility toggles correctly between shown and hidden states

---

## 5. Profile — Name Management

### TC-026: Successfully change first, middle, and last name
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Log in and navigate to the Profile page
2. Click the **NAME** tab
3. Clear and enter a new First Name
4. Clear and enter a new Middle Initial
5. Clear and enter a new Last Name
6. Click **Save Changes**

**Expected Result:** Success message: "Name successfully changed."; profile reflects updated name

---

### TC-027: Change name with empty First Name field
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Name tab

**Steps:**
1. Navigate to Profile → NAME tab
2. Clear the First Name field and leave it empty
3. Click **Save Changes**

**Expected Result:** Validation error displayed; name is not saved

---

### TC-028: Change name with empty Last Name field
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Name tab

**Steps:**
1. Navigate to Profile → NAME tab
2. Clear the Last Name field and leave it empty
3. Click **Save Changes**

**Expected Result:** Validation error displayed; name is not saved

---

### TC-029: Profile tab navigation works correctly
**Priority:** Low | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Navigate to Profile page
2. Click EMAIL ADDRESS tab → verify content loads
3. Click NAME tab → verify First Name, Middle Initial, Last Name fields and Save Changes button appear
4. Click PASSWORD tab → verify password fields appear
5. Click SECURITY QUESTIONS tab → verify question/answer fields appear
6. Click DEACTIVATE tab → verify deactivate button appears

**Expected Result:** Each tab loads its correct content without errors

---

## 6. Profile — Email Address Management

### TC-030: Successfully change email address
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; new email is not already registered

**Steps:**
1. Navigate to Profile → EMAIL ADDRESS tab
2. Enter a new valid email address
3. Enter the same email in Confirm Email Address
4. Enter the current password in Current Password field
5. Click **Save Changes**

**Expected Result:** Success message displayed; confirmation email sent to new address

---

### TC-031: Change email with mismatched email addresses
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Email tab

**Steps:**
1. Navigate to Profile → EMAIL ADDRESS tab
2. Enter a new email address
3. Enter a different email in Confirm Email Address
4. Enter current password
5. Click **Save Changes**

**Expected Result:** Validation error: email addresses do not match

---

### TC-032: Change email with incorrect current password
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Email tab

**Steps:**
1. Navigate to Profile → EMAIL ADDRESS tab
2. Enter a valid new email (both fields matching)
3. Enter an incorrect current password
4. Click **Save Changes**

**Expected Result:** Error message: current password is incorrect

---

### TC-033: Change email with already-registered email
**Priority:** Medium | **Type:** Functional  
**Preconditions:** Target email is already registered to another account

**Steps:**
1. Navigate to Profile → EMAIL ADDRESS tab
2. Enter an email already registered to another account (both fields matching)
3. Enter correct current password
4. Click **Save Changes**

**Expected Result:** Error message indicating the email is already in use

---

## 7. Profile — Password Management

### TC-034: Successfully change password
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter the current password in Current Password field
3. Enter a new valid password in New Password field
4. Enter the same new password in Confirm New Password
5. Click **Save Changes**

**Expected Result:** Success message: "Password successfully changed."

---

### TC-035: Change password with incorrect current password
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Password tab

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter an incorrect value in Current Password
3. Enter a valid new password (both fields matching)
4. Click **Save Changes**

**Expected Result:** Error message: "Current password is incorrect."

---

### TC-036: Change password with mismatched new passwords
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Password tab

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter the correct current password
3. Enter a new password in New Password field
4. Enter a different value in Confirm New Password
5. Click **Save Changes**

**Expected Result:** Error message: "New passwords must match."

---

### TC-037: Change password with invalid new password (too short)
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Password tab

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter the correct current password
3. Enter a password shorter than 8 characters as new password
4. Enter the same short password in Confirm New Password
5. Click **Save Changes**

**Expected Result:** Error: "Enter a valid new password. The password must be at least eight characters and must contain at least one letter and one number or special character."

---

### TC-038: Change password to same as current password
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Password tab

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter the current password in all three fields
3. Click **Save Changes**

**Expected Result:** Error message: "You may not reuse your current password."

---

### TC-039: Password containing spaces is rejected
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Password tab

**Steps:**
1. Navigate to Profile → PASSWORD tab
2. Enter current password correctly
3. Enter a new password containing spaces (e.g., "pass word1!")
4. Click **Save Changes**

**Expected Result:** Validation error: passwords cannot contain spaces

---

## 8. Profile — Security Questions

### TC-040: Successfully update security question
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Navigate to Profile → SECURITY QUESTIONS tab
2. Select a new security question from the dropdown
3. Enter an answer in the Answer field
4. Click the Show toggle
5. Enter the current password
6. Click **Save Changes**

**Expected Result:** Success message: "Security question successfully updated."

---

### TC-041: Update security question with empty answer
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Security Questions tab

**Steps:**
1. Navigate to Profile → SECURITY QUESTIONS tab
2. Select a security question
3. Leave the Answer field empty
4. Enter current password
5. Click **Save Changes**

**Expected Result:** Validation error displayed; security question not updated

---

### TC-042: Update security question with incorrect password
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; on Security Questions tab

**Steps:**
1. Navigate to Profile → SECURITY QUESTIONS tab
2. Select a question and enter an answer
3. Enter an incorrect password
4. Click **Save Changes**

**Expected Result:** Error message indicating incorrect password

---

### TC-043: Security question dropdown contains valid options
**Priority:** Low | **Type:** Functional  
**Preconditions:** User is logged in; on Security Questions tab

**Steps:**
1. Navigate to Profile → SECURITY QUESTIONS tab
2. Click the security question dropdown

**Expected Result:** Dropdown displays multiple selectable security question options

---

## 9. Profile — Account Deactivation

### TC-044: Successfully deactivate account
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; account is active

**Steps:**
1. Navigate to Profile → DEACTIVATE tab
2. Click the **Deactivate** button
3. Confirm deactivation in the modal dialog

**Expected Result:** Account is deactivated; user is logged out or redirected to confirmation page

---

### TC-045: Deactivation confirmation modal appears
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in; on Profile Deactivate tab

**Steps:**
1. Navigate to Profile → DEACTIVATE tab
2. Click the **Deactivate** button

**Expected Result:** Confirmation modal dialog appears before proceeding with deactivation

---

### TC-046: Cancel account deactivation
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in; deactivation modal is open

**Steps:**
1. Navigate to Profile → DEACTIVATE tab
2. Click the **Deactivate** button
3. In the confirmation modal, click **Cancel** or close the modal

**Expected Result:** Modal closes; account remains active; user stays on the profile page

---

## 10. Logout

### TC-047: Successful logout from profile page
**Priority:** High | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Log in with valid credentials
2. Navigate to the Profile page
3. Click the **Log Out** link

**Expected Result:** User is logged out and redirected to the logout success/login page

---

### TC-048: Session is invalidated after logout
**Priority:** High | **Type:** Security  
**Preconditions:** User has just logged out

**Steps:**
1. Log in and then log out
2. Press the browser Back button
3. Attempt to navigate directly to a protected page URL

**Expected Result:** User is redirected to the login page; session is not restored

---

### TC-049: Log Out link visible on all profile tabs
**Priority:** Medium | **Type:** Functional  
**Preconditions:** User is logged in

**Steps:**
1. Log in and navigate to Profile
2. Check each tab (NAME, EMAIL ADDRESS, PASSWORD, SECURITY QUESTIONS, DEACTIVATE) for the Log Out link

**Expected Result:** Log Out link is consistently visible and accessible on all profile tabs

---

### TC-050: Report an Issue link is accessible
**Priority:** Low | **Type:** Functional  

**Steps:**
1. Navigate to the login page
2. Click the **Report an Issue** link

**Expected Result:** User is redirected to the issue reporting page/form

---

## Summary

| Category | Test Cases | Count |
|---|---|---|
| Authentication — Login | TC-001 to TC-007 | 7 |
| Social Login | TC-008 to TC-014 | 7 |
| Forgot Password | TC-015 to TC-017 | 3 |
| Account Creation | TC-018 to TC-025 | 8 |
| Profile — Name | TC-026 to TC-029 | 4 |
| Profile — Email | TC-030 to TC-033 | 4 |
| Profile — Password | TC-034 to TC-039 | 6 |
| Profile — Security Questions | TC-040 to TC-043 | 4 |
| Account Deactivation | TC-044 to TC-046 | 3 |
| Logout | TC-047 to TC-050 | 4 |
| **Total** | | **50** |