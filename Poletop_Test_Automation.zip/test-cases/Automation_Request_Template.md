# Automation Request Template (Reusable)

Use this template from the project root for every Azure DevOps test automation request.

```text
[AUTOMATION REQUEST FORM]

Mode:
[ bootstrap-mcp | automate-testcase ]: <value>

Connection (required for bootstrap-mcp, optional for automate-testcase if already saved):
Azure DevOps Organization URL: <value>
PAT Token: <value>

Automation scope (required for automate-testcase):
Project Name: <value>
Test Case ID(s) (comma-separated): <value>   // Example: 12345,12346,12347
Source Type: Azure DevOps MCP
Execution Type:
[ single-test | multi-test ]: <value>

Instructions to agent:
1. If mode=bootstrap-mcp:
   - Configure Azure DevOps MCP connection.
   - Save credentials for current workspace/session only (never commit).
   - Validate connection with read-only call (list projects/test plans).
   - Confirm ready status.

2. If mode=automate-testcase:
   - Ensure MCP is connected (bootstrap first if needed).
   - Fetch all provided test case IDs from Azure DevOps MCP.
   - Preserve formal step order and expected results.
   - Generate automation scripts using repository instruction files and conventions.
   - For multiple test cases (comma-separated IDs), process each case and generate corresponding test coverage.
   - Run required compile/test validation and report outcome.

Security:
- Do not print PAT in logs or output.
- Do not store PAT in tracked repository files.
```

## Multi-test example

```text
Mode: automate-testcase
Project Name: OTI QA Automation
Test Case ID(s): 12345,12346,12347
Execution Type: multi-test
```
