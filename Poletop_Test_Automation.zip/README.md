# Poletop Automation

> **Selenium + TestNG automated test suite for the Poletop application**  
> Java 8 · Maven · SDK `com.test.automation:functional-test-automation-sdk:1.3.0`

End-to-end regression automation for Poletop (NYC DOT pole reservation system).
Built on the `functional-test-automation-sdk` consumer template using Page Object Model (POM).

---

## Prerequisites

| Tool | Required Version |
|------|-----------------|
| Java JDK | 8 or higher |
| Maven | 3.6 or higher |
| Chrome + ChromeDriver | Latest stable (versions must match) |
| IntelliJ IDEA | Any recent |

---

## Getting Started

**1. Clone the repository**
```bash
git clone https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/OTI%20QA%20Automation/_git/Poletop_Automation
```

**2. Add Maven credentials** â€” in `~/.m2/settings.xml`:
```xml
<server>
  <id>functional-test-automation-sdk</id>
  <username>clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d</username>
  <password>YOUR_PAT_HERE</password>
</server>
```

**3. Copy and configure sdk-config.yaml**
```bash
cp configuration/sdk-config.yaml.template configuration/sdk-config.yaml
```

**4. Build**
```bash
mvn clean compile test-compile
```

---

## Running Tests

```bash
# Full regression suite (STG, Chrome)
mvn test -Dsurefire.suiteXmlFiles=regression_suite.xml \
         -Denvironment=stg -DbrowserName=chrome

# Single test class
mvn test -Dtest=Test_CheckAvailableLocation \
         -Denvironment=stg -DbrowserName=chrome

# Crawler â€” generate page object locators (admin role)
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=admin@example.com -Dinv.password=secret

# Crawler â€” enrollment page (requires Franchisee credentials)
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=admin@example.com -Dinv.password=secret \
         -Dinv.franchisee.email=franchisee@example.com \
         -Dinv.franchisee.password=secret \
         -Dinv.page=enrollment \
```

---

## Project Structure

```
Poletop_Automation/
â”œâ”€â”€ pom.xml                          â† SDK dependency: functional-test-automation-sdk:1.3.0
â”œâ”€â”€ regression_suite.xml             â† All test classes
â”œâ”€â”€ crawler_suite.xml                â† LocatorInvestigator (page object generator)
â”œâ”€â”€ configuration/
â”‚   â”œâ”€â”€ config.properties            â† App URLs per environment
â”‚   â”œâ”€â”€ sdk-config.yaml              â† Browser/screenshot settings (not committed)
â”‚   â””â”€â”€ sdk-config.yaml.template     â† Template â€” copy to sdk-config.yaml
â”œâ”€â”€ docs/
â”‚   â”œâ”€â”€ sdk/CHANGELOG.md             â† SDK version history
â”‚   â””â”€â”€ test-case-gaps/              â† Blocker reports
â”œâ”€â”€ .github/
â”‚   â”œâ”€â”€ instructions/                â† Copilot coding rules (auto-managed)
â”‚   â””â”€â”€ prompts/                     â† Copilot prompt templates (auto-managed)
â””â”€â”€ src/
    â””â”€â”€ test/
        â”œâ”€â”€ java/com/poletop/automation/
        â”‚   â”œâ”€â”€ uiActions/           â† Page Objects (extend TestBase)
        â”‚   â”‚   â”œâ”€â”€ PoletopDashboardPage.java
        â”‚   â”‚   â”œâ”€â”€ PoletopCheckLocationPage.java
        â”‚   â”‚   â”œâ”€â”€ PoletopEnrollmentPage.java
        â”‚   â”‚   â””â”€â”€ PoletopReservationDetailsPage.java
        â”‚   â”œâ”€â”€ testCases/           â† Test Classes (extend TestBase)
        â”‚   â”‚   â”œâ”€â”€ Test_CheckAvailableLocation.java
        â”‚   â”‚   â”œâ”€â”€ Test_PoletopEnroll.java
        â”‚   â”‚   â””â”€â”€ Test_AdminConstructionFlow.java
        â”‚   â””â”€â”€ tools/
        â”‚       â””â”€â”€ LocatorInvestigator.java   â† Smart page crawler
        â””â”€â”€ resources/
            â””â”€â”€ testData/
                â””â”€â”€ POLETOP_STG_TestData.xlsx
```

---

## Test Coverage

| Test Class | Sheet | Description | Status |
|---|---|---|---|
| `Test_CheckAvailableLocation` | `CheckAvailableLocation` | Pole ID/XY/LatLong search, availability check | âœ… Active |
| `Test_PoletopEnroll` | `PoletopEnroll` | New Reservation enrollment flow | ðŸ”„ In progress |
| `Test_AdminConstructionFlow` | `AdminConstructionFlow` | DOT-Admin construction phase transitions | â³ Blocked (needs STG data) |

---

## SDK Version

Current: **1.3.0** — see [`docs/sdk/CHANGELOG.md`](docs/sdk/CHANGELOG.md)

Key additions in 1.3.0:
- `AbstractLocatorInvestigator` — zero-duplication crawler base class; consumer projects override 3 methods only

Key additions in 1.2.5:
- `actOnListElement` â€” generic list element resolver (iterate â†’ match â†’ confirm XPath â†’ act)
- `getPageLabels` â€” harvests all `<label>` elements from a scope, returns `Map<String,WebElement>`
- `getElementTexts`, `listDifference` â€” assertion helpers for element collections
- `getTableRows`, `clickTableRowByColumnValue`, `getTableColumnValues` â€” table interaction helpers
- `getDropdownMenuItems`, `clickDropdownMenuItemByText` â€” Bootstrap/custom dropdown helpers
- ElementCrawler 6-strategy intelligence pipeline (ancestor scoping, role groups, label associations)

Full API reference: [`TESTBASE-API.md`](TESTBASE-API.md)  
Full user guide: [`SDK-USER-GUIDE.md`](SDK-USER-GUIDE.md)

---

## Key Conventions

- All Page Objects and Test Classes **must extend `TestBase`** â€” never use raw Selenium directly.
- Use `clearAndType()` for text entry, never raw `sendKeys`.
- Use `fluentWaitUntilElementToBeClickable()` before every click.
- Only XPath in `@FindBy` â€” no CSS selectors.
- Only locators marked `UNIQUE âœ“` by the crawler.
- Test rows with `runMode=N` in Excel are auto-skipped.

See [`.github/instructions/`](.github/instructions/) for full coding rules (auto-managed by SDK).
