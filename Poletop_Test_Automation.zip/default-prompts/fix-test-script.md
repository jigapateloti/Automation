# Prompt Template: Fix a Failing / Broken Test Script

> **How to use:**
> 1. Copy the block below into GitHub Copilot Chat
> 2. Replace every `< >` placeholder with your actual values
> 3. Paste the error/stack trace if you have it — the more context, the faster the fix
> 4. Send — Copilot will diagnose and fix systematically

---

```
Fix the following failing automated test in this project.

## Failing Test
- Test class name  : <Test_FeatureName>
- Test method name : <testMethodName>  (leave blank if all methods fail)
- Environment      : <stg | tst | dev>
- Browser          : chrome

## Failure Type (check what applies)
<!-- Tick the closest match — leave blank if unknown -->
- [ ] Element not found  (NoSuchElementException / TimeoutException)
- [ ] Assertion failure  (expected X but was Y)
- [ ] Test data issue    (NullPointerException / wrong Excel column)
- [ ] Page never loaded  (WebDriverException / timeout on navigation)
- [ ] Compile error      (BUILD FAILURE before tests run)
- [ ] Test logic drifted from ADO test case
- [ ] Unknown — see error below

## Error / Stack Trace
<!-- Paste from: target/surefire-reports/<TestClassName>.txt  OR console output -->
```
<paste error here>
```

## What Changed Recently (if known)
<e.g. "UI was updated last week", "Added new Excel column", "Upgraded SDK version">

## Additional Notes (optional)
<Any other context — environment issues, known flakiness, etc.>

---

Follow all rules in .github/instructions/ and use #fix-failed-test workflow.
If the locator broke, also run the crawler: mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml -Denvironment=<env> -DbrowserName=chrome -Dinv.email=<email> -Dinv.password=<password>
Validate fix with: mvn compile test-compile && mvn test -Dtest=<Test_FeatureName> -Denvironment=<env> -DbrowserName=chrome
```
