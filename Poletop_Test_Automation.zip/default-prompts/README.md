# Default Prompts

Ready-to-use Copilot Chat prompt templates. Copy, fill in the placeholders, and paste into Copilot.

| File | When to Use |
|---|---|
| `create-test-script.md` | Creating a new automated test from scratch |
| `fix-test-script.md` | Diagnosing and fixing a failing or broken test |

> **Tip:** For advanced agent-mode prompts (invokable with `#` syntax), see `.github/prompts/`.
