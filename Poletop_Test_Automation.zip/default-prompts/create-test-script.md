# Prompt Template: Create Automated Test Script

> **How to use:**
> 1. Copy the block below into GitHub Copilot Chat
> 2. Replace every `< >` placeholder with your actual values
> 3. Send — Copilot will handle the rest

---

```
Create an automated test script using Selenium + TestNG + POM for this project.

## Test Details
- Test class name   : <Test_FeatureName>
- Excel sheet name  : <SheetName>
- Target page URL   : <https://...>
- Environment       : <stg | tst | dev>
- Browser           : chrome

## Test Case Source
<!-- Pick ONE and fill in -->
- [ ] Local file  : <path/to/test-case-file.md or .txt>
- [ ] Azure DevOps: Test Case ID(s) — <ADO-XXXXX, ADO-XXXXX>

## Scope
<!-- Describe in plain English what needs to be automated -->
<e.g. "Automate the login flow: enter valid credentials, click Login,
       assert the dashboard title is displayed">

## Login / Preconditions (if required)
- Username : <test user email>
- Password : <test user password>

## Additional Notes (optional)
<Any known UI quirks, special waits, or data setup steps>

## Email Verification (if test involves email flows)
<!-- Fill in if the test requires reading from Mailinator -->
- Email address used in test : <testuser@mailinator.com>
- Email type(s)              : <confirmation link | password reset link | OTP code | other>
- Template name(s) needed    : <confirmation | passwordReset | otpCode | custom>

---

Follow all rules in .github/instructions/ and use #create-test workflow.
Run the crawler before writing any @FindBy locator.
For email flows: use getEmailUrl / getEmailText / getConfirmationEmailUrl from TestBase — never import MailinatorEmailReader directly.
Validate with: mvn compile test-compile && mvn test -Dtest=<Test_FeatureName> -Denvironment=<env> -DbrowserName=chrome
```
