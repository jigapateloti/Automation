# Azure DevOps Integration – Environment Setup Runbook

This runbook describes how to configure the local environment so that
GitHub Copilot CLI (and any automation scripts) can communicate with the
Poletop Azure DevOps instance to retrieve test cases, shared steps, and
other work items.

---

## 1. Prerequisites

| Requirement | Minimum Version | Notes |
|---|---|---|
| Java JDK | 8+ | Must be on `PATH` |
| Maven | 3.6+ | Must be on `PATH` |
| Git | 2.x | Must be on `PATH` |
| Chrome / ChromeDriver | Latest stable | Must match each other |
| curl | Any | Used to verify connectivity |

---

## 2. Azure DevOps Organization Details

| Field | Value |
|---|---|
| Organization URL | `https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/` |
| Project | `PRJ15999` |
| API Version | `7.1` |

---

## 3. Create a Personal Access Token (PAT)

1. Open a browser and go to:
   `https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/`
2. Click your profile avatar (top-right) → **Personal access tokens**.
3. Click **+ New Token**.
4. Configure:
   - **Name**: `poletop-automation` (or any descriptive name)
   - **Organization**: `clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d`
   - **Expiration**: set as required by your org policy
   - **Scopes** → select **Custom defined**, then enable:
     - `Work Items` → **Read**
     - `Test Management` → **Read**
5. Click **Create** and **copy the token immediately** — it is shown only once.

---

## 4. Store the PAT Locally

### Option A — Environment variable (recommended, no secrets in files)

**Windows (PowerShell, current session):**
```powershell
$env:AZDO_PAT = "YOUR_PAT_HERE"
```

**Windows (persist across sessions):**
```powershell
[System.Environment]::SetEnvironmentVariable("AZDO_PAT", "YOUR_PAT_HERE", "User")
```

**macOS / Linux:**
```bash
export AZDO_PAT="YOUR_PAT_HERE"
# Add the line above to ~/.bashrc or ~/.zshrc to persist it
```

### Option B — `.env` file (never commit to Git)

Create a file named `.env` in the project root:
```
AZDO_PAT=YOUR_PAT_HERE
AZDO_ORG_URL=https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/
AZDO_PROJECT=PRJ15999
```

> ⚠️ **The `.env` file is already listed in `.gitignore`. Never commit it.**

---

## 5. Verify Connectivity

Run the following `curl` command to confirm the PAT works and the API is reachable:

```powershell
# Replace YOUR_PAT_HERE with your actual token
$pat = "YOUR_PAT_HERE"
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
Invoke-WebRequest `
  -Uri "https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/PRJ15999/_apis/wit/workitems/233502?api-version=7.1" `
  -Headers @{ Authorization = "Basic $b64" } `
  -UseBasicParsing | Select-Object StatusCode, StatusDescription
```

Expected response: `StatusCode 200`.

**Unix / macOS equivalent:**
```bash
curl -s -o /dev/null -w "%{http_code}" \
  -u ":$AZDO_PAT" \
  "https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/PRJ15999/_apis/wit/workitems/233502?api-version=7.1"
# Expected: 200
```

---

## 6. Configure GitHub Copilot CLI MCP Server (if applicable)

If the project uses the **Azure DevOps MCP server** to let Copilot CLI fetch
test cases automatically:

1. Open (or create) the MCP server config file at:
   - Windows: `%APPDATA%\GitHub Copilot\mcp_config.json`
   - macOS/Linux: `~/.config/github-copilot/mcp_config.json`

2. Add the Azure DevOps server entry:
```json
{
  "mcpServers": {
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@tiberriver256/mcp-server-azure-devops"],
      "env": {
        "AZURE_DEVOPS_ORG_URL": "https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/",
        "AZURE_DEVOPS_AUTH_METHOD": "pat",
        "AZURE_DEVOPS_PAT": "${AZDO_PAT}"
      }
    }
  }
}
```

3. Restart GitHub Copilot CLI.

4. Verify the server is active — Copilot should now be able to call ADO tools
   such as `get_work_item`, `list_test_cases`, etc.

---

## 7. Maven Test Execution with Environment Flag

All tests are executed with an `-Denvironment` flag that selects the correct
test data Excel file:

```bash
# Run all tests against STG
mvn test -Denvironment=stg -DbrowserName=chrome

# Run a specific test class
mvn test -Dtest=Test_CheckAvailableLocation \
         -Denvironment=stg \
         -DbrowserName=chrome

# Run the locator crawler / page object generator
mvn test -Dtest=LocatorInvestigator \
         -Denvironment=stg \
         -DbrowserName=chrome \
         -Dinv.email=YOUR_EMAIL \
         -Dinv.password=YOUR_PASSWORD
```

| Environment flag | Excel data file used |
|---|---|
| `stg` | `POLETOP_STG_TestData.xlsx` |
| `uat` | `POLETOP_UAT_TestData.xlsx` |
| `prod` | `POLETOP_TestData.xlsx` |

---

## 8. Relevant ADO Work Items

| ID | Type | Title |
|---|---|---|
| 233502 | Test Case | PoleTop Users check Available Locations for creating Pole Reservations |
| 119526 | Shared Step | Admin Login |
| 119573 | Shared Step | Admin Check Location |
| 123324 | Shared Step | Franchisee Login |
| 123323 | Shared Step | Franchisee Check Location |

---

## 9. Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| `401 Unauthorized` from API | PAT expired or wrong scope | Regenerate PAT with `Work Items: Read` and `Test Management: Read` |
| `203 Non-Authoritative` (HTML login page) | PAT not passed / wrong org URL | Confirm `AZDO_PAT` env var is set in the current session |
| `NegativeArraySizeException: -1` at test start | Excel sheet tab name not found | Verify the sheet name exactly matches the `@DataProvider` string (case-sensitive) |
| Tests stuck on phone MFA page | Test account requires MFA | Use a dedicated automation account with MFA disabled in NYC.ID |
| `isDashboardLoaded()` returns false | Dashboard H1 locator mismatch | Re-run `LocatorInvestigator` with a valid non-MFA account and update `PoletopDashboardPage.dashboardHeading` |
| ChromeDriver version mismatch | Chrome auto-updated | Download matching ChromeDriver from https://chromedriver.chromium.org/downloads |
