# Changelog

All notable changes to the Poletop Automation project are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

> ⚠️ **Rule: update this file for every automation change before committing.**
> Use the `[Unreleased]` section during development; move entries to a dated
> version heading when a sprint/release is complete.

---

## [Unreleased]

### Added
<!-- List new test classes, page objects, or features here -->

### Changed
<!-- List updated locators, modified test scenarios, page object refactors -->

### Fixed
<!-- List fixed tests, healed locators, resolved gaps -->

---

## [1.2.9] — 2026-08-13

### Changed
- **SDK upgraded** `functional-test-automation-sdk` `1.2.5` → `1.2.9`
- **All `.github/instructions/` and `.github/prompts/` re-synced** from SDK v1.2.9 template
- **`docs/sdk/CHANGELOG.md`** updated — now reflects SDK history through v1.2.9
- **`pom.xml`** — added `sdk.config.dir` override comment in surefire plugin

### SDK v1.2.9 — What's New (crawler improvements)
- **28 total XPath strategies** — crawler can now resolve any element pattern:
  - New: `@value`, `@src`, `@alt`, `@data-value`, form-row label (sibling `<label>/<th>/<legend>`)
  - New: `collectImageButtons()` — discovers `input[type=image]` and `button//img`
  - New: `collectTableColumns()` — maps table headers → column cell XPaths + dynamic row templates
- **Label-following engine** (v1.2.8) — `<label for>`, `aria-labelledby`, Angular Material `mat-label`
- **iframe/frame crawling** (v1.2.7) — same-origin frames fully crawled; elements tagged `inFrame=true`
- **Extended strategies** (v1.2.7) — `data-testid/cy/qa`, `@title`, `@autocomplete`, `<select>` options, file inputs, `contenteditable`
- **Mailinator v2 API fixes** (v1.2.6) — duplicate class removed, `deleteAllEmails` URL corrected

---

<!-- Example entry:
## [1.0.0] — YYYY-MM-DD

### Added
- `Test_Login` — automated ADO-12345 / Valid login scenario
- `Test_ForgotPassword` — automated ADO-12346 / Password reset flow
- `LoginPage` — page object for /login

### Fixed
- `Test_Enrollment` — healed 2 broken locators after UI update on enrollment form
-->
