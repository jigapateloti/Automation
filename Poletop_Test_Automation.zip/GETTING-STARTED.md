# Getting Started with Poletop Automation SDK

This guide walks through creating a new automation project using the
`poletop-automation-sdk` as the base framework.

---

## Prerequisites

| Tool | Version | Notes |
|---|---|---|
| Java JDK | 8+ | Must be on PATH |
| Maven | 3.6+ | Must be on PATH |
| Chrome + ChromeDriver | Latest stable | Must match |
| Node.js | 18+ | Required for MCP server |

---

## Step 1 — Copy the Consumer Template

```bash
# Copy the template to your new project location
cp -r IdeaProjects/poletop-automation-consumer-template IdeaProjects/your-app-automation
cd IdeaProjects/your-app-automation
```

Or create from scratch with the structure:
```
your-app-automation/
 pom.xml
 configuration/
   config.properties        <- fill in your app URLs
   log4j2.properties        <- logging config
 regression_suite.xml       <- add your test classes here
 crawler_suite.xml          <- crawler entry point
 webDrivers/
   chromedriver.exe         <- local ChromeDriver binary
 src/test/java/com/<yourcompany>/automation/
   uiActions/               <- page objects (extend TestBase)
   testCases/               <- test classes (extend TestBase)
   tools/
     LocatorInvestigator.java
 src/test/resources/testData/
   YourApp_STG_TestData.xlsx
```

---

## Step 2 — Update pom.xml

Replace the groupId and artifactId:
```xml
<groupId>com.yourcompany.automation</groupId>
<artifactId>your-app-automation</artifactId>
```

The SDK dependency is already declared — no other framework deps needed:
```xml
<dependency>
    <groupId>com.poletop.automation</groupId>
    <artifactId>poletop-automation-sdk</artifactId>
    <version>1.0.0</version>
</dependency>
```

---

## Step 3 — Configure Your Application

Edit `configuration/config.properties`:
```properties
stg_base_url     = https://your-app-stg.example.com/
stg_data_set     = YourApp_STG_TestData.xlsx
testDataDir      = /src/test/resources/testData/
browser          = chrome
```

---

## Step 4 — Run the Crawler for Each New Page

Before writing any page object:
```bash
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=your@email.com -Dinv.password=yourPassword
```

The crawler generates:
- `src/test/java/.../uiActions/LoginPage.java`  (ready-to-use page object)
- `test-output/crawler/LoginPage_<timestamp>.txt`  (full locator report)

Review the report — only use locators marked `UNIQUE OK`.

---

## Step 5 — Write a Test Class

```java
package com.yourcompany.automation.testCases;

import static io.qameta.allure.Allure.step;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.test.automation.sdk.testbase.TestBase;  // from SDK
import com.yourcompany.automation.uiActions.LoginPage;

public class Test_Login extends TestBase {

    @DataProvider(name = "loginData")
    public Object[][] loginData() throws Exception {
        return getData("LoginSheet");
    }

    @Test(dataProvider = "loginData", priority = 1)
    public void testValidLogin(String testCaseName, String email,
                               String password, String runMode) throws Exception {
        if ("N".equalsIgnoreCase(runMode))
            throw new SkipException("Skipping: " + testCaseName);

        step("Navigate to app");
        driver.get(baseURL);

        step("Login");
        LoginPage page = new LoginPage(driver);
        page.login(email, password);

        step("Assert dashboard loaded");
        Assert.assertTrue(page.isDashboardLoaded(), "Dashboard not visible");
    }
}
```

---

## Step 6 — Run Tests

```bash
# Full regression
mvn test -Denvironment=stg -DbrowserName=chrome

# Single class
mvn test -Dtest=Test_Login -Denvironment=stg -DbrowserName=chrome

# With custom config directory
mvn test -Dsdk.config.dir=/path/to/config -Denvironment=stg -DbrowserName=chrome
```

---

## Package Conventions

| Your Package | Purpose |
|---|---|
| `com.<yourco>.automation.uiActions` | Page Objects — extend `com.test.automation.sdk.testbase.TestBase` |
| `com.<yourco>.automation.testCases` | Test Classes — extend `TestBase`, use `@DataProvider` |
| `com.<yourco>.automation.tools` | Dev tools — `LocatorInvestigator` only |

---

## Key SDK Classes

| Class | Package | Use for |
|---|---|---|
| `TestBase` | `sdk.testbase` | Base class for all page objects and tests |
| `WebDriverFactory` | `sdk.testbase` | Browser initialization (handled by TestBase) |
| `SdkConfig` | `sdk.testbase` | Config path resolution (`-Dsdk.config.dir`) |
| `PageObjectGenerator` | `sdk.utility` | Generates page object from a URL |
| `ElementCrawler` | `sdk.utility` | Locator discovery engine |
| `Excel_Reader` | `sdk.utility` | Reads test data from .xlsx |
| `Listener` | `sdk.listener` | Screenshot-on-failure, Extent reports |
| `RetryListener` | `sdk.listener` | Automatic test retry |