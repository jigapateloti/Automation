# Blocker Report — Test_AdminConstructionFlow

**Test Class :** `Test_AdminConstructionFlow`
**ADO Test Case :** ADO-233504 — Admin Starts & Completes Construction on a Reservation
**Project :** PRJ15999 — Poletop Manager Application Re-Design
**Date :** 2026-08-12
**Status :** BLOCKED

---

## Blocker

**No "Permits Issued" reservation exists in STG environment.**

TC-233504 requires a reservation that is already in **"Permits Issued"** stage as a
precondition. The STG environment currently has no such reservation.

Without this precondition:
- The crawler cannot reach the Reservation Details page to confirm locators
- `PoletopReservationDetailsPage` locators remain unconfirmed (NEEDS CRAWLER)
- Both test rows in `AdminConstructionFlow` Excel sheet are set to `runMode=N`

---

## Resolution Required

One of the following must happen before this test can be enabled:

| Option | Steps |
|--------|-------|
| **A — Create test data** | Log in as Franchisee, enroll for a pole (e.g. pole 13137), advance the reservation through all stages until "Permits Issued" |
| **B — Use existing reservation** | QA/DEV team to provide a reservation number in "Permits Issued" stage from STG |

Once a reservation number is available:
1. Update `AdminConstructionFlow` Excel sheet — replace `REPLACE_WITH_PERMITS_ISSUED_RESERVATION_NUMBER`
2. Run crawler: `mvn test -DsuiteXmlFile=crawler_suite.xml -Dinv.page=resdetails -Dinv.reservationNumber=<number>`
3. Update `PoletopReservationDetailsPage` locators with `UNIQUE ✓` values from report
4. Set `runMode=Y` in Excel
5. Run tests: `mvn test -Dtest=Test_AdminConstructionFlow`

---

## Affected Files

- `src/test/java/com/poletop/automation/testCases/Test_AdminConstructionFlow.java`
- `src/test/java/com/poletop/automation/uiActions/PoletopReservationDetailsPage.java`
- `src/test/resources/testData/POLETOP_STG_TestData.xlsx` — sheet `AdminConstructionFlow`