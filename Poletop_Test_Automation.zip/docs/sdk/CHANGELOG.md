# Changelog â€” Framework Automation SDK

All notable changes to `com.test.automation:functional-test-automation-sdk` are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/): `MAJOR.MINOR.PATCH`

| Increment | When |
|-----------|------|
| `PATCH` | Bug fixes, no API change |
| `MINOR` | New helpers, backward-compatible additions |
| `MAJOR` | Breaking changes â€” package rename, method removal, signature change |

> âš ï¸ **Rule: every SDK change must have a changelog entry before deployment.**
> Write the entry first, then run `mvn deploy`.

---

## [Unreleased]
<!-- Add entries here during development; move to a version heading on release -->

---

## [1.2.9] — 2026-08-14

### Added — Crawler: complete strategy coverage for all element patterns

**New XPath strategies in `buildAllXPaths()`** (in priority order):

| Strategy | Attribute | Use case |
|---|---|---|
| BY VALUE | `@value` | `<select>` options, pre-filled inputs (skips password/hidden) |
| BY SRC | `@src` | Image buttons — `<input type=image>`, `<img>` inside `<button>` |
| BY ALT | `@alt` | Image elements used as buttons |
| BY DATA-VALUE | `@data-value` | Angular chips, autocomplete options, custom dropdowns |
| BY FORM-ROW LABEL | sibling `<label>/<th>/<legend>` | `//div[label[.='Email']]//input` — covers label-without-for patterns |

**New collection strategies:**

- **`collectImageButtons()`** — discovers `input[type=image]` and `button//img | a//img`;
  flags with `isImageButton=true`; builds locators from `@alt`, `@src`, `@title`

- **`collectTableColumns()`** — discovers every `<th>` with visible text; emits:
  - Header locator: `//th[normalize-space(.)='Status']`
  - Column cells XPath: `//table//tr/td[count(//th[.='Status']/preceding-sibling::th)+1]`
  - Dynamic row+cell template: replace `{ROW_KEY}` with a row identifier value
  - Covers manual tester assertions like "verify Status column for row with Pole ID 'ABC'"

- **`buildFormRowLabelXpath()`** — JS walks up to 5 DOM levels to find a sibling
  `<label>`, `<th>`, or `<legend>`; tries container patterns (`div`, `td`, `li`,
  `section`, `tr`) and returns first UNIQUE ✓ match

**New `ElementInfo` fields**: `alt`, `src`, `dataValue`, `isImageButton`,
`isTableHeader`, `tableColumnText`, `tableColumnCellsXpath`, `tableColumnDynamicTemplate`

**Updated `toString()`**: includes `IMAGE-BUTTON`, `TABLE-HEADER=<text>`,
`label='<text>'` markers

**10 new unit tests** (295 total, all passing)

**Complete strategy pipeline** — all 28 locator strategies now implemented:
standalone (17), contextual (4), collection (7). The crawler can resolve any
element pattern encountered in real-world Angular/HTML applications.

---

## [1.2.8] — 2026-08-14

### Added — Crawler: label-following resolution engine

Manual testers describe elements by their visible label text — "enter value in the
**Borough** field", "click the **Email** input". This release makes the crawler follow
labels to their target controls so generated page object field names and locators
reflect the human-readable label.

Three resolution mechanisms implemented in `collectLabelAssociations()`:

**A) `<label for="X">` — explicit HTML association**
- Resolves label text from the `<label>` element
- Finds the associated control by `[@id='X']` across `input`, `textarea`, `select`, `mat-select`
- Falls back to proximity XPath `//label[...]/following-sibling::input[1]` when no `for` attr
- Sets `linkedInputXpath` on the label ElementInfo

**B) `aria-labelledby="Y"` — ARIA pointer to label element**
- Finds every element with `@aria-labelledby`
- Resolves the text of the referenced element (`//*[@id='Y']`)
- Sets `labelText` and `isLabelledBy=true` on the control ElementInfo

**C) Angular Material `<mat-form-field>` proximity**
- Finds every `<mat-form-field>` container
- Reads the `<mat-label>` sibling text inside the container
- Resolves the child `input`, `mat-select`, or `textarea`
- Builds a label-following XPath:
  `//mat-form-field[.//mat-label[normalize-space(.)='Borough']]//mat-select`
- Sets `labelText`, `isMatLabelled=true`, `labelFollowingXpath` on the control

**New `ElementInfo` fields:**
- `labelText` — human-readable label text resolved from any mechanism
- `labelFollowingXpath` — stable XPath targeting element via its visible label
- `isLabel` — true when the element is a `<label>` element
- `isLabelledBy` — true when resolved via `aria-labelledby`
- `isMatLabelled` — true when resolved via Angular Material `mat-label`

**6 new unit tests** (285 total, all passing)

---

## [1.2.7] — 2026-08-14

### Added — ElementCrawler coverage improvements

- **iframe/frame crawling** — `crawlCurrentPage()` now enumerates all `<iframe>` and
  `<frame>` elements, switches into each same-origin frame, crawls its contents, and
  switches back to the default document. Cross-origin frames are silently skipped.
  Elements found inside frames are tagged with `inFrame=true` and `frameIndex=N` so
  `PageObjectGenerator` can emit `driver.switchTo().frame(N)` in action methods.

- **Extended Angular Material interactive tags** — `INTERACTIVE_TAGS` now includes:
  `mat-slide-toggle`, `mat-datepicker`, `mat-autocomplete`, `mat-chip-list`,
  `mat-chip-input`, `mat-expansion-panel`, `mat-slider`, `mat-button-toggle`

- **Extended `data-*` attribute strategy** — XPath strategy ladder now probes all
  common testing-specific data attributes in priority order: `data-testid`, `data-cy`,
  `data-qa`, `data-automation`, `data-id`, `data-test`

- **`title` attribute strategy** — added to strategy ladder for icon buttons and
  elements that use title as their only stable attribute

- **`autocomplete` attribute strategy** — added for semantic form fields
  (`autocomplete="email"`, `given-name`, etc.); `"on"` and `"off"` are excluded as
  they are not stable selectors

- **`<select>` option collection** — `collectSelectOptions()` now discovers all
  `<option>` children under every `<select>`, builds scoped XPath
  `//select[@id='X']/option[normalize-space(.)='Value']`, and flags each with
  `isSelectOption=true`

- **File input detection** — `input[type=file]` elements are flagged with
  `isFileInput=true` so generated page objects emit upload handlers instead of
  `clearAndType()`

- **`contenteditable` div collection** — `collectContentEditable()` finds all
  `[contenteditable='true']` elements and flags them with `isContentEditable=true`
  for rich-text-aware action generation

- **Hidden element flagging** — `input[type=hidden]` elements are included but
  flagged with `isHidden=true` to reduce noise in primary locator selection

- **New `ElementInfo` fields**: `title`, `autocomplete`, `inFrame`, `frameIndex`,
  `isHidden`, `isFileInput`, `isContentEditable`, `isSelectOption`

- **Configurable ancestor walk depth** — `ANCESTOR_WALK_DEPTH` constant (12 levels,
  up from hardcoded 8) passed as JS argument to `resolveStableAncestor()`

- **15 new unit tests** in `ElementCrawlerTest` covering all new fields and constants
  (total: 279 tests, all passing)

---

## [1.2.6] — 2026-08-14

### Fixed
- **`Mailinator.java` — removed duplicate legacy class definition**: File contained two
  `public class Mailinator` blocks — the original v1 implementation (using `?token=` query
  param and `https://mailinator.com/api/v2`) was left as dead code below the new v2 class.
  Removed the legacy block entirely. Only the v2 implementation (Authorization header,
  `https://api.mailinator.com/api/v2`) is now present.
- **`deleteAllEmails` URL bug**: `MAILINATOR_DELETE_ALL_URL` was targeting
  `DELETE /api/v2/domains/{domain}/inboxes` (domain-level delete — wipes ALL messages).
  Corrected to `DELETE /api/v2/domains/{domain}/inboxes/{inbox}` per the official
  Mailinator OpenAPI spec (inbox-level delete only).
- **Removed dead `boolean privateDomain` overloads** from `Mailinator.java`: Four
  overloaded methods accepted the `privateDomain` boolean parameter but ignored it
  entirely. Per the v2 API spec, private vs. public routing is determined by the domain
  name in the URL path, not a separate flag. The overloads are removed; callers use
  the canonical `(apikey, domain, inbox, ...)` signatures.
- **Removed dead `isPrivateDomain()` from `MailinatorEmailReader`**: Read
  `api.mailinator.privateDomain` from yaml but the return value was never used anywhere.
  Removed to eliminate misleading dead code.

### Notes
- Official Mailinator API v2 spec confirms both `Authorization` header and `?token=`
  query param are supported for authentication; the SDK correctly uses the header form.
- To target a private domain, set `api.mailinator.domain` in `sdk-config.yaml` to your
  private domain name (e.g., `yourcompany.com`). No boolean flag is needed.

---

## [1.2.4] — 2026-08-13

### Added
- **`README.md` as live status page** — mandatory update rule added to all processing
  flows (create-test, modify-test, fix-failed-test, fix-broken-locator, SDK publish):
  - Consumer project `README.md` must have a `## Test Coverage` table with one row
    per test class showing status (`✅ Automated`, `⚠️ Partial`, `❌ Blocked`, `🔧 Fixing`, `⛔ Retired`)
    and last-updated date — updated on every create/modify/fix/block action
  - SDK `README.md` must be updated on every version bump (component table,
    config snippet, prompts table, version badge)
  - Every completion report now shows a diff-style summary of README.md changes
- **`copilot-instructions.md`** — new Rule 7: README.md Is the Live Project Status Page;
  defines `## Test Coverage` table format, status values, and update rules
- **`SDK-PUBLISHING.md`** — Section 5 Version Bump now includes README.md update
  as mandatory step 3 before deploy

---

## [1.2.3] â€” 2026-08-12

### Added
- **`CHANGELOG.md`** â€” standalone changelog file in SDK root (this file);
  extracted to consumer projects as `docs/sdk/CHANGELOG.md` by `InstructionExtractor`
- **`InstructionExtractor`** â€” now also copies `CHANGELOG.md` to `docs/sdk/CHANGELOG.md`
  in consumer projects; updated completion message to mention `docs/sdk/`
- **Prompts** â€” `create-test`, `modify-test`, `fix-failed-test`, `fix-broken-locator`:
  mandatory `CHANGELOG.md` update step added to every consumer project flow
  (completion report box, step in workflow, output checklist)
- **`SDK-PUBLISHING.md`** â€” Section 5 (Version Bump) now mandates changelog entry
  before deploy; Section 6 replaced inline version list with reference to `CHANGELOG.md`

### Changed
- Changelog content moved from `SDK-PUBLISHING.md` Section 6 into `CHANGELOG.md`

---

## [1.2.2] â€” 2026-08-12

### Added
- **`GapReportWriter`** â€” new utility class that writes `gap-report.md` and
  `blocker-report.md` files to a configurable output directory.
  Resolution order: `-Dsdk.gapOutputDir` system property â†’ `sdk-config.yaml
  reporting.gapOutputDir` â†’ default `docs/test-case-gaps/`
- **`YamlConfigReader`** â€” new default key `reporting.gapOutputDir`
  (value: `docs/test-case-gaps/`)
- **`sdk-config.yaml.template`** â€” new `reporting:` section with `gapOutputDir` key
  and inline comments
- **`test-case-gap.instructions.md`** â€” directory resolution priority table;
  Gap vs Blocker decision guide; blocker naming convention (`<ClassName>-blocker-report.md`)
- **`SDK-USER-GUIDE.md`** â€” `GapReportWriter` in component table; `reporting:` yaml
  block in Section 6.2; new Section 13.1 "Gap & Blocker Reports â€” Configurable Output"
- **`sdk-migration.instructions.md`** â€” `reporting:` section in Step 6 yaml snippet;
  two new checklist items
- **Prompts** â€” `create-test`, `modify-test`, `fix-failed-test`, `fix-broken-locator`:
  mandatory `CHANGELOG.md` update step added to every flow
- **`SDK-PUBLISHING.md`** â€” changelog update made a mandatory pre-deploy step

### Tests
- 14 new tests in `GapReportWriterTest` covering all three resolution tiers,
  trailing separator normalisation, file naming, content write, auto-directory creation
- **60 total unit tests passing**

---

## [1.2.1] â€” 2026-08-11

### Added
- **`create-test.prompt.md`** â€” autonomous mode consent block; Step 3 1-to-1
  step/assertion coverage rule (`assertTrue(true)` forbidden); Step 6 Blocker Output
  (writes to `docs/test-case-gaps/`); Step 7 mandatory Completion Report
- **`fix-failed-test.prompt.md`** â€” Step 0 ADO Pre-Fix Change Check: fetches ADO test
  case, compares `lastModifiedDate` vs last git commit, routes to `#ado-sync-test` when
  ADO changed, retires test when ADO is `Closed`/`Inactive`; autonomous mode block;
  completion report includes ADO pre-check section
- **`modify-test.prompt.md`** â€” autonomous mode consent; coverage rules; completion report
- **`test-creation.instructions.md`** â€” Autonomous Mode Consent section; full step
  coverage rules; blocker file requirement; Step 8 Completion Report
- **`formal-testcase-to-script.instructions.md`** â€” autonomous mode; 1-to-1 mapping rule;
  blocker output section
- **`test-fix.instructions.md`** â€” Rule 0 ADO Pre-Fix Check with full decision table
- **`PageObjectGenerator`** â€” project-agnostic output: `uiActionsPackage`, `outputSrc`,
  `outputReport` resolved at runtime via `-Dpog.*` system properties â†’
  `sdk-config.yaml crawler.pageObject.*` â†’ built-in Poletop defaults (backward compat)
- **`sdk-config.yaml.template`** â€” new `crawler:` section
- **`YamlConfigReader`** â€” three new default keys for `crawler.pageObject.*`
- **`SDK-USER-GUIDE.md`** â€” Sections 6.2 and 7 updated for project-agnostic crawler config

### Tests
- `YamlConfigReaderTest`: +7 tests for crawler defaults and YAML overrides
- `PageObjectGeneratorConfigTest` (new): 15 tests covering all three resolution tiers
- **46 total unit tests passing**

---

## [1.1.0] â€” 2026-07-XX

### Added
- **Mailinator â€” TestBase wrappers**: `getEmailUrl`, `getEmailText`,
  `getConfirmationEmailUrl`, `getDeactivationEmailUrl`, `deleteEmailById` â€”
  email flows accessible from TestBase without importing any Mailinator class
- **Mailinator â€” configurable templates**: `mailinator-email-templates.yaml` with
  `subjectContains`, `urlPathPatterns`, `excludePatterns`, `textPattern`, `masks`
- **Mailinator â€” value masks**: `EmailValueMask` â€” `trim`, `uppercase`, `lowercase`,
  `substring`, `dateFormat`, `replaceAll`
- **Mailinator â€” smart cleanup**: auto-delete removes only the single processed message
  (not the entire inbox) â€” safe for shared domains across projects
- **Mailinator â€” retry polling**: configurable initial wait, poll interval, and timeout
  via `sdk-config.yaml`
- **`scrollIntoView(WebElement)`**: new public method â€” viewport-aware scroll using
  Selenium Actions wheel input with JS fallback; returns element for fluent chaining

### Changed
- **TestBase visibility**: 15 internal methods changed from `public` to `protected`
  to reduce API surface clutter

### Documentation
- `TESTBASE-API.md` section 23 updated
- `SDK-USER-GUIDE.md` sections 9.1 and 6.2 updated

---

## [1.0.0] â€” Initial Release

- Initial release: TestBase, WebDriverFactory, SdkConfig, ElementCrawler,
  PageObjectGenerator, Excel_Reader, Listener, RetryListener, WebEventListener,
  YamlConfigReader
