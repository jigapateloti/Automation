# LocatorInvestigator Redesign — SDK v1.2.9 Sync

**Date:** 2026-08-13  
**Applies to:** `Poletop_Automation` + `functional-automation-consumer-template`

---

## Problem: Old Architecture Caused Account Lockouts

The original `LocatorInvestigator` used **multiple `@Test` methods** (one per page).  
TestNG's `@BeforeMethod` from `TestBase` fired before **every** test, which:

1. Killed the existing WebDriver session (`driver.quit()`)
2. Created a brand-new browser instance
3. Left `generator` and `crawler` holding a **stale driver reference**
4. Caused each page test to **re-login independently**

With 5 test methods → up to **5 login attempts per run** → account lockout.

```
Before (broken flow):
  @BeforeClass  → session #1 created, generator/crawler bound to #1
  @BeforeMethod → session #1 KILLED, session #2 created
  @Test dashboardPage  → generator uses stale session #1 → FAIL / re-login
  @BeforeMethod → session #2 KILLED, session #3 created
  @Test checkLocationPage → re-login #2
  @BeforeMethod → session #3 KILLED, session #4 created
  @Test enrollmentPage    → re-login #3
  ... → account locked after N failed/repeated logins
```

---

## Solution: Single-Test Continuous Session

### Two architectural changes:

#### 1. One `@Test` method — `runFullCrawl()`
All pages crawled inside a **single test method** in sequential order.  
`@BeforeMethod` from TestBase fires exactly **once** → one session, one login per role.

#### 2. Fail-Fast Login — `loginAs(role)`
Replaces the old `ensureLoggedIn()` with strict one-attempt-per-role logic.

---

## New Flow

```
@BeforeClass setUp()
  └── initialization() → session created
      generator / crawler bound to driver

@BeforeMethod (TestBase, fires ONCE for single @Test)
  └── new session created — driver reference refreshed

@Test runFullCrawl()
  ├── generator = new PageObjectGenerator(driver)   ← rebind to fresh session
  ├── crawler   = new ElementCrawler(driver)        ← rebind to fresh session
  │
  ├── [no login needed]
  │     driver.get(baseURL) → crawl LoginPage
  │
  ├── loginAs("admin")                              ← ONE attempt only
  │     ├── success → crawl Dashboard
  │     │             crawl Check Location
  │     │             crawl Reservation Details
  │     └── fail   → admin added to failedRoles
  │                  all admin pages skipped (no retry)
  │
  └── loginAs("franchisee")                        ← ONE attempt only
        ├── success → crawl Enrollment
        └── fail   → franchisee added to failedRoles
                     enrollment skipped (no retry)

@AfterClass
  └── prints: crawled=[] skipped=[] failedRoles=[]
      closeBrowser()
```

---

## `loginAs(role)` — Decision Rules

| Condition | Action |
|---|---|
| Role is in `failedRoles` | Return `false` immediately — **zero network calls** |
| No credentials provided (`inv.email` empty) | Add to `failedRoles`, return `false` |
| Already logged in as this role + session alive | **Reuse session** — no login needed |
| Session expired mid-crawl | Add to `failedRoles`, return `false` — **no retry** |
| Login attempt throws / times out | Add to `failedRoles`, return `false` — **no retry** |
| Login succeeds | `loggedIn = true`, proceed |

> **Account lockout protection:** Once a role fails, it is blacklisted for the entire run.  
> No amount of session issues, retries, or re-runs within the same JVM will trigger a second attempt.

---

## Files Changed

| File | Change |
|---|---|
| `src/test/java/.../tools/LocatorInvestigator.java` | Full redesign — single `@Test`, `loginAs()`, `failedRoles` blacklist, driver rebind |
| `functional-automation-consumer-template/.../LocatorInvestigator.java` | Same pattern propagated — generic, project-neutral, with `CUSTOMIZE` comments |

---

## Comparison

| | Before | After |
|---|---|---|
| `@Test` methods | 5 (one per page) | **1** (`runFullCrawl`) |
| `@BeforeMethod` fires | 5× per run | **1×** per run |
| Browser sessions created | 5 | **1** (+ 1 from `@BeforeMethod`) |
| Login attempts — admin | Up to 5 | **1** |
| Login attempts — franchisee | Up to 5 | **1** |
| Failed login behavior | Would retry on next test | **Blacklisted** — never retried |
| `generator`/`crawler` driver | Stale after first `@BeforeMethod` | Rebound at start of test |
| Crawl summary | None | Logged on `@AfterClass` |

---

## Run Commands

```bash
# Full crawl — all pages, both roles
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
  -Denvironment=stg -DbrowserName=chrome \
  -Dinv.email=DOT-PTM_2026@mailinator.com \
  -Dinv.password=DOTPTM2026 \
  -Dinv.franchisee.email=PoleTop_2025@mailinator.com \
  -Dinv.franchisee.password=PoleTop2025 \
  -Dinv.page=all

# Single page — login only (no credentials needed)
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
  -Denvironment=stg -DbrowserName=chrome \
  -Dinv.page=login

# Single page — dashboard only
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
  -Denvironment=stg -DbrowserName=chrome \
  -Dinv.email=DOT-PTM_2026@mailinator.com \
  -Dinv.password=DOTPTM2026 \
  -Dinv.page=dashboard

# With reservation details
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
  -Denvironment=stg -DbrowserName=chrome \
  -Dinv.email=DOT-PTM_2026@mailinator.com \
  -Dinv.password=DOTPTM2026 \
  -Dinv.page=resdetails \
  -Dinv.reservationNumber=RES-12345
```

---

## SDK v1.2.9 — New Crawler Capabilities

The following SDK improvements are now active after the version bump (`1.2.5 → 1.2.9`):

| Version | Feature |
|---|---|
| v1.2.9 | **28 XPath strategies** — `@value`, `@src`, `@alt`, `@data-value`, form-row label (sibling `<label>/<th>/<legend>`) |
| v1.2.9 | `collectImageButtons()` — discovers `input[type=image]` and `button//img` |
| v1.2.9 | `collectTableColumns()` — maps table headers → column cell XPaths + dynamic row templates |
| v1.2.8 | **Label-following engine** — `<label for>`, `aria-labelledby`, Angular Material `mat-label` |
| v1.2.7 | **iframe/frame crawling** — same-origin frames fully crawled; elements tagged `inFrame=true` |
| v1.2.7 | Extended strategies — `data-testid/cy/qa`, `@title`, `@autocomplete`, `<select>` options, file inputs, `contenteditable` |
| v1.2.6 | Mailinator v2 API fixes — duplicate class removed, `deleteAllEmails` URL corrected |
