---
applyTo: "src/test/java/**/*.java"
---

# Skill: Formal Test Case to Automation Script

## Trigger
Apply this skill when creating or updating automated tests from formal test cases.

## Autonomous Mode Consent
Request this confirmation before starting and proceed autonomously once granted:

> **"I will proceed autonomously. I accept all standard implementation decisions
> without further questions. Interrupt me only when: (1) a step cannot be automated
> due to a missing stable locator or inaccessible system, (2) a step is ambiguous
> and two different implementations would produce materially different test outcomes."**

## Supported Test Case Sources
1. Local files (for example: `test-cases/*.md`, docs, exported case sheets)
2. Azure DevOps test cases via MCP service

## Intake Workflow
1. Collect test case source (file path or ADO work item/test case ID).
2. Extract structured fields:
   - test case ID/title
   - preconditions
   - test data
   - ordered steps
   - expected result per step
3. Convert each expected result into assertions.
4. Map UI actions to existing `uiActions` methods.
5. If required Page Object methods/locators are missing, update `uiActions` first using crawler rules.

## Azure DevOps MCP Workflow
When source is Azure DevOps:
1. Use MCP tools for Azure DevOps to fetch the test case details and steps.
2. Preserve the original step order and wording intent.
3. Keep traceability in code:
   - class/method JavaDoc includes ADO test case ID
   - `testCaseName` data value includes the same ID/title
4. If MCP data is incomplete (missing steps/expected), stop and request clarification.

## Script Generation Rules
- One `@Test` method per formal scenario.
- Use `@DataProvider` backed by Excel if test data varies by row.
- Always enforce `runMode` skip logic first.
- **Add `step("...")` for every formal test case step — 1-to-1 mapping, no merging.**
- **Every formal expected result must have a matching `Assert.*` call — no expected result may be skipped.**
- Steps where the expected result is "no error / page loads" require an explicit element-presence or title assertion — `assertTrue(true)` is never acceptable.
- No hidden logic branches without assertions.

## When a Step Cannot Be Automated — Blocker Output
If any step or expected result cannot be automated:

1. **Do NOT silently skip it** — create ``\${reporting.gapOutputDir}` (default: docs/test-case-gaps/)${ClassName}-blocker-report.md`:
   ```markdown
   # Implementation Blocker Report
   **Test Class**: ${TestClassName}
   **Source**: ${ADO-ID or file}
   **Generated**: ${timestamp}

   ## Blocked Steps
   | Step # | Description | Expected Result | Reason | Suggested Fix |
   |--------|-------------|-----------------|--------|---------------|
   | N | ... | ... | No stable locator / env not reachable / ambiguous | ... |

   ## Implementable Steps
   All steps NOT listed above were successfully automated.
   ```

2. Mark the blocked test method with `@Test(enabled=false)` and throw `SkipException`
   with a reference to the blocker file.

3. Implement all other steps normally.

## Traceability Template (required)
```java
/***********************************************************************
 * Test Case ID : ADO-12345
 * Source       : Azure DevOps / test-cases/<file>.md
 * Objective    : <formal objective text>
 ***********************************************************************/
```

## Completion Checklist
- [ ] Autonomous mode confirmed by user
- [ ] Formal steps fully mapped to automation steps (1-to-1)
- [ ] Every expected result covered by an `Assert.*` call
- [ ] Page object actions reused (no duplicated Selenium logic in test class)
- [ ] Locators updated through crawler flow when needed
  - Crawler: `com.test.automation.tools.LocatorInvestigator` via `crawler_suite.xml`
- [ ] Blocker report created for any steps that could not be automated
- [ ] `mvn compile test-compile` passes with zero errors
- [ ] Impacted tests **executed** via `mvn test -Dtest=<ClassName>` and passed (or skipped intentionally)
- [ ] Completion report produced (see `test-creation.instructions.md` Step 8 format)
- [ ] Task is NOT marked complete while any test fails or was never run