---
applyTo: "src/main/java/**/uiActions/*.java"
---

# Skill: Creating Page Objects with the Crawler

## Trigger
Apply this skill whenever creating or updating a `uiActions/` Page Object class.

## Golden Rule
**Never write `@FindBy` locators by hand.**  
Always run `PageObjectGenerator` / `LocatorInvestigator` first.  
Only use locators the crawler marks as **`UNIQUE ✓`**.

## ElementCrawler Instruction (Mandatory)
`ElementCrawler` is the locator engine behind both entry points:
- `LocatorInvestigator` — TestNG class at `src/test/java/com/poletop/automation/tools/LocatorInvestigator.java`
- `PageObjectGenerator.main()` — standalone utility at `src/main/java/com/automation/poletop/utility/PageObjectGenerator.java`

> ⚠️ `LocatorInvestigator` lives in the **`tools`** package (`com.test.automation.tools`), NOT in `testCases`.
> Always invoke it via `crawler_suite.xml` or with the fully qualified class name.
> It must never appear in `regression_suite.xml`.

Run one of these before creating/updating any `uiActions` class:

```bash
# Option A – dedicated crawler suite (recommended)
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=<email> -Dinv.password=<password>

# Option B – single investigation method
mvn test "-Dtest=com.test.automation.tools.LocatorInvestigator#<methodName>" \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=<email> -Dinv.password=<password>

# Option C – standalone PageObjectGenerator (output path controlled by sdk-config.yaml)
mvn exec:java -Dexec.mainClass="com.test.automation.sdk.utility.PageObjectGenerator" \
              -Dexec.args="<PageName>Page <URL> <email> <password>"
# To override package/path per-run:
# -Dpog.package=com.mycompany.uiActions -Dpog.outputDir=src/main/java/com/mycompany/uiActions/
```

Do not proceed with manual locators if the crawler report lacks `UNIQUE ✓` strategies for required elements.

---

## Step-by-Step Process

### Step 1 — Run the Crawler

> ⚠️ **`LocatorInvestigator` is in package `com.test.automation.tools`** — use the fully qualified name or `crawler_suite.xml`.

```bash
# Option A – dedicated crawler suite (recommended)
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=user@example.com \
         -Dinv.password=<password>

# Option B – single page method
mvn test "-Dtest=com.test.automation.tools.LocatorInvestigator#generate<PageName>Page" \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=user@example.com -Dinv.password=<password>

# Option C – PageObjectGenerator standalone (output path from sdk-config.yaml)
mvn exec:java -Dexec.mainClass="com.test.automation.sdk.utility.PageObjectGenerator" \
              -Dexec.args="<PageName>Page <URL> <email> <password>"
# Override per-run: -Dpog.package=com.mycompany.uiActions -Dpog.outputDir=src/.../uiActions/
```

**Output produced:**
- `<outputDir>/<ClassName>.java` — generated page object (path from `crawler.pageObject.outputDir` in sdk-config.yaml)
- `test-output/crawler/<ClassName>_<timestamp>.txt` — full discovery report

### Step 2 — Read the Discovery Report
Open `test-output/crawler/<ClassName>_<timestamp>.txt`.  
For each element check the **ALL LOCATOR STRATEGIES** table:

```
│  ── ALL LOCATOR STRATEGIES (6) ──────────────────────────────
│  BY ID                              //input[@id='email']           ← UNIQUE ✓ USE THIS
│  BY FORM-CONTROL-NAME               //input[@formcontrolname='email']
│  BY NAME + TYPE                     //input[@name='email' and @type='email']
│  BY ARIA-LABEL (exact)              //input[@aria-label='Email Address']
│  BY PLACEHOLDER (contains)          //input[contains(@placeholder,'Email')]
│  STRUCTURAL [fallback]              //form[1]/div[2]/input[1]      ← NEVER USE
```

### Step 3 — Locator Selection Rules

#### ✅ USE (stable, unique)
| Strategy | Example | Use when |
|---|---|---|
| `BY ID` | `//input[@id='email']` | ID is meaningful (not auto-generated) |
| `BY DATA-TESTID` | `//button[@data-testid='submit']` | App has data-testid attributes |
| `BY FORM-CONTROL-NAME` | `//input[@formcontrolname='poleId']` | Angular reactive forms |
| `BY NAME + TYPE` | `//input[@name='email' and @type='email']` | No id/formcontrol |
| `BY ARIA-LABEL (exact)` | `//button[@aria-label='Close dialog']` | Accessibility label present |
| `BY PLACEHOLDER (exact)` | `//input[@placeholder='Enter Pole ID']` | Input with unique placeholder |
| `BY TEXT (normalize-space)` | `//button[normalize-space(.)='Submit']` | Button/link with unique label |
| `BY ROUTER-LINK` | `//a[@routerlink='/enroll']` | Angular navigation links |

#### ❌ NEVER USE (dynamic or non-unique)
| Pattern | Example | Why |
|---|---|---|
| Auto-generated Material ID | `//input[@id='mat-input-0']` | Changes on every page load |
| Auto-generated CDK ID | `//*[@id='cdk-overlay-3']` | Runtime-generated |
| Structural / positional | `//div[3]/input[1]` | Breaks on any UI change |
| Index-only | `(//input)[2]` | Non-semantic, fragile |
| Dynamic numeric suffix | `//input[@id='field-12345']` | Random at runtime |
| Pure class-based | `//*[@class='ng-pristine ng-valid']` | Angular lifecycle classes |

### Step 4 — Review and Clean the Generated File

The generated file looks like this:
```java
// ── emailField ──────────────────────────────────────────
//   OPTIONS  ↓  uncomment preferred strategy:
//   BY ID                       @FindBy(xpath = "//input[@id='email']")
//   BY FORM-CONTROL-NAME        @FindBy(xpath = "//input[@formcontrolname='email']")
//   BY NAME + TYPE              @FindBy(xpath = "//input[@name='email' and @type='email']")
//   BY ARIA-LABEL (exact)       @FindBy(xpath = "//input[@aria-label='Email Address']")
//   STRUCTURAL [fallback]       @FindBy(xpath = "//form[1]/div[2]/input[1]")
//
@FindBy(xpath = "//input[@id='email']")    // ← auto-selected primary
public WebElement emailField;
```

**Actions to take:**
1. Confirm the active `@FindBy` is `UNIQUE ✓` in the report
2. Delete all comment lines — keep only the active `@FindBy`
3. Remove `[HIDDEN]` elements you don't need
4. Remove `[STRUCTURAL]` locators — rerun crawler or inspect DevTools
5. Rename fields to match your domain language

### Step 5 — Page Object Quality Checklist
Before using the generated page object in tests:
- [ ] Every `@FindBy` is verified `UNIQUE ✓` in the crawler report
- [ ] No dynamic IDs (`mat-input-N`, `cdk-*`, numeric-only IDs)
- [ ] No structural/positional XPaths
- [ ] No CSS selectors — XPath only
- [ ] Constructor has `PageFactory.initElements(driver, this)`
- [ ] Constructor sets `PageContext.currentPage.set("<ClassName>")`
- [ ] All action methods use `TestBase` helpers (not raw Selenium calls)
- [ ] **Every action method follows the interaction safety pattern (see below)**
- [ ] File compiles: `mvn compile -q`

---

## ⚠️ Mandatory Interaction Safety Pattern

> **Rule: Before interacting with ANY element, the page/DOM must be fully ready.**

Every action method MUST follow this sequence — no exceptions:

### After a click that causes navigation or DOM change:
```java
element.click();
waitUntillPageLoad();                    // 1. wait for page/DOM to settle
waitForElementPresent(driver, nextEl);   // 2. confirm next element is in DOM
fluentWaitUntilElementToBeClickable(nextEl); // 3. confirm it is interactable
```

### Before reading or typing into any element:
```java
waitUntillPageLoad();                    // DOM must be settled
waitForElementPresent(driver, element);  // element must be in DOM
// then interact:
clearAndType(element, value);            // or safeGetText(element)
```

---

## ⚠️ Mandatory Method-Level Retry Rule

> **Rule: Every element interaction must retry up to 3 times before failing.**  
> This guards against transient DOM re-renders, stale references, and timing races in Angular/SPA apps.

### Use SDK retry helpers — never raw Selenium calls in page objects:

| Operation | Use this | Never use this |
|---|---|---|
| Click any element | `safeClick(element)` | `element.click()` |
| Type into a field | `clearAndType(element, value)` | `element.sendKeys(value)` |
| Read element text | `safeGetText(element)` | `element.getText()` |

All three helpers are built into `TestBase` with **3-attempt retry** and appropriate waits built in.

### Complete example — correct pattern:
```java
public void navigateToCheckLocation() {
    waitForElementPresent(driver, mapsMenuLink);
    safeClick(mapsMenuLink);                              // retry-safe click
    waitUntillPageLoad();
    waitForElementPresent(driver, checkLocationMenuOption);
    safeClick(checkLocationMenuOption);                   // retry-safe click
    waitUntillPageLoad();
    waitForElementPresent(driver, checkLocationPageTitle); // confirm arrival
}

public void enterXYCoordinates(String x, String y) {
    waitForElementPresent(driver, xyRadioButton);
    if (!xyRadioButton.isSelected()) {
        safeClick(xyRadioButton);                         // retry-safe click
        waitUntillPageLoad();
    }
    waitForElementPresent(driver, xCoordinateField);
    clearAndType(xCoordinateField, x);                    // 3-retry type
    waitForElementPresent(driver, yCoordinateField);
    clearAndType(yCoordinateField, y);
}

public String getStatus() {
    waitUntillPageLoad();
    waitForElementPresent(driver, statusBadge);
    return safeGetText(statusBadge);                      // 3-retry getText
}
```

### Forbidden patterns:
```java
// ❌ WRONG — raw click, no retry, no wait
element.click();
nextElement.sendKeys("value");

// ❌ WRONG — no waitUntillPageLoad after navigation click
menuLink.click();
anotherElement.click();

// ❌ WRONG — raw Thread.sleep() 
element.click();
Thread.sleep(3000);
nextElement.getText();

// ❌ WRONG — raw getText without wait or retry
String text = element.getText();  // may be stale or empty
```

---

## Test-Level Retry

Every `@Test` method automatically gets **3 retry attempts** via `RetryListener` registered in `regression_suite.xml`:
```xml
<listener class-name="com.test.automation.sdk.listener.RetryListener"/>
```

`RetryListener` auto-applies `Retry.class` to every `@Test` — **no annotation needed on individual methods**.  
If a test fails due to transient infrastructure/network/timing issues it will retry up to 3 times before reporting failure.

**Do NOT** add `retryAnalyzer = Retry.class` manually to `@Test` — it is already applied globally.

### Step 6 — Re-Validate After Every Modification (Required)
Any time a `uiActions` class is edited (even small locator/action changes):
1. Re-run locator validation with crawler (`LocatorInvestigator` or `PageObjectGenerator`)
2. Keep only `UNIQUE ✓` locators in active `@FindBy` annotations
3. Re-run compile check: `mvn compile test-compile`
4. Re-run impacted tests that use the changed page object
5. Only then treat the update as complete
