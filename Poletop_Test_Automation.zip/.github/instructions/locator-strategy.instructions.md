---
applyTo: "**"
---

# Skill: Locator Strategy & Uniqueness Rules

## Purpose
This skill defines the mandatory locator selection policy for all Page Objects
in this project. It is enforced by `ElementCrawler` (uniqueness validation) and
reviewed by the developer before finalizing any `@FindBy` annotation.

---

## Uniqueness is Mandatory
A locator is only acceptable if `driver.findElements(By.xpath("...")).size() == 1`.  
The crawler validates this automatically and marks each strategy:

| Marker | Meaning | Action |
|---|---|---|
| `UNIQUE ✓` | Exactly 1 element found | ✅ Safe to use |
| `NOT UNIQUE (N found)` | Multiple elements match | ❌ Do not use |
| `DYNAMIC` | Pattern is auto-generated | ❌ Do not use |
| `STALE` | 0 elements found | ❌ Element may be conditional |
| `STRUCTURAL` | Position-based fallback | ❌ Do not use unless absolutely last resort |

---

## Locator Priority Ladder
Always use the **first applicable unique strategy**:

```
1.  @id                   — most stable; use only if not auto-generated
2.  @data-testid          — second best; intentional test attribute
3.  @formcontrolname      — Angular reactive forms; stable
4.  @name + @type         — reliable for standard HTML forms
5.  @name                 — reliable when type is not needed
6.  @aria-label (exact)   — accessibility attribute; usually stable
7.  @placeholder (exact)  — good for inputs; use exact match
8.  normalize-space(.)    — for buttons/links with unique visible text
9.  @routerlink           — Angular navigation; stable
10. @href (contains)      — for static links; use last path segment
─────────────────────────────────────────────────────
❌  @class                — NEVER as primary; use only with contains() + another attribute
❌  position [N]          — NEVER; breaks on any UI change
❌  auto-generated IDs    — NEVER (see dynamic ID patterns below)
```

---

## Dynamic ID Patterns — Always Reject
Any locator matching these patterns must be rejected:

| Pattern | Example | Reason |
|---|---|---|
| `mat-input-\d+` | `//input[@id='mat-input-3']` | Angular Material auto-increment |
| `mat-select-\d+` | `//mat-select[@id='mat-select-0']` | Angular Material auto-increment |
| `cdk-\w+-\d+` | `//*[@id='cdk-overlay-2']` | Angular CDK runtime ID |
| `ngb-\w+-\d+` | `//*[@id='ngb-nav-0']` | ng-bootstrap auto-increment |
| Pure numeric | `//input[@id='12345']` | No semantic meaning |
| UUID/hash | `//div[@id='a3f2c1d9']` | Random per session |
| `_nghost-*` | `//*[@_nghost-abc-c0]` | Angular view encapsulation attr |
| `ng-reflect-*` | `//*[@ng-reflect-model]` | Angular debug attribute |

---

## Writing XPath — Best Practices

### Prefer exact match over contains()
```xpath
✅  //input[@placeholder='Enter Pole ID']
⚠️  //input[contains(@placeholder,'Pole')]   — only if exact is not unique
```

### Use normalize-space() for text with whitespace
```xpath
✅  //button[normalize-space(.)='Save Changes']
❌  //button[text()='Save Changes']           — fails if there is whitespace
```

### Combine attributes for specificity
```xpath
✅  //input[@name='password' and @type='password']
✅  //button[@type='submit' and normalize-space(.)='Login']
```

### Parent context when needed
```xpath
✅  //form[@id='loginForm']//input[@name='email']
✅  //section[@class='enrollment-panel']//button[normalize-space(.)='Submit']
```

### Cross-layout fallback with union (`|`)
Use `|` only when the same business element is rendered by different layouts and each branch is stable.

```xpath
✅  (
      //table[contains(@class,'product-grid-view')]//tr[contains(@class,'product-row') and .//td[normalize-space(.)='{{PRODUCT_NAME}}']]
      |
      //section[contains(@class,'clearance-layout')]//div[contains(@class,'product-row') and .//*[normalize-space(.)='{{PRODUCT_NAME}}']]
      |
      //ul[contains(@class,'legacy-product-list')]//li[contains(@class,'product-row') and .//*[normalize-space(.)='{{PRODUCT_NAME}}']]
    )
```

Rules:
- Keep each branch independently meaningful (no positional `[N]`).
- Prefer exact business anchors (name/sku/label text) inside each branch.
- Accept only if the full union locator is `UNIQUE ✓` in crawler output.

### Angular Material dropdowns
```xpath
# The mat-select trigger:
✅  //mat-select[@formcontrolname='borough']

# The option panel (used in action methods, not @FindBy):
✅  //mat-option[normalize-space(.)='Manhattan']
```

---

## Crawler Uniqueness Validation
`ElementCrawler.buildAllXPaths()` tests every generated XPath against the live page:

```
For each strategy XPath:
  count = driver.findElements(By.xpath(xp)).size()
  if  count == 1  → label as  UNIQUE ✓
  if  count >  1  → label as  NOT UNIQUE (N found)  → excluded from @FindBy block
  if  count == 0  → label as  STALE
  if  matches dynamic pattern → label as  DYNAMIC  → always excluded
```

Only `UNIQUE ✓` locators appear in the active `@FindBy` annotation.  
All others are still shown in comments for reference but must not be activated.

---

## Quick Reference Card

```java
// ✅ Correct — stable, unique, meaningful
@FindBy(xpath = "//input[@id='email']")
@FindBy(xpath = "//input[@formcontrolname='password']")
@FindBy(xpath = "//button[normalize-space(.)='Log In']")
@FindBy(xpath = "//input[@name='poleId' and @type='text']")
@FindBy(xpath = "//mat-select[@formcontrolname='borough']")
@FindBy(xpath = "//a[@routerlink='/dashboard']")

// ❌ Wrong — dynamic, fragile, or non-unique
@FindBy(xpath = "//input[@id='mat-input-0']")        // dynamic
@FindBy(xpath = "(//input)[2]")                       // positional
@FindBy(xpath = "//div[3]/form/input[1]")             // structural
@FindBy(css  = "input.form-control")                  // CSS not allowed
@FindBy(xpath = "//*[contains(@class,'ng-valid')]")   // Angular lifecycle class
```
