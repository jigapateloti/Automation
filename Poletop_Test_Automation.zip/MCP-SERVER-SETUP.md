# MCP Server Configuration – IntelliJ IDEA + GitHub Copilot CLI

This document describes how the Azure DevOps MCP server is configured in
**IntelliJ IDEA 2026.2** with the **GitHub Copilot** plugin, and how to
restore or update that configuration when needed.

---

## Overview

The Azure DevOps MCP server allows GitHub Copilot (in both the IDE chat and
the CLI terminal) to directly query Azure DevOps — fetching test cases, work
items, shared steps, and more — without copy-pasting URLs or JSON by hand.

| Component | Value |
|---|---|
| MCP server package | `@azure-devops/mcp` (official Microsoft package) |
| Transport | `stdio` (spawned as a local child process via `npx`) |
| Auth method | Personal Access Token (PAT) |
| ADO Organization | `clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d` |

---

## File Locations

### 1. GitHub Copilot CLI — primary MCP config
```
%USERPROFILE%\.copilot\mcp-config.json
```
This is the **authoritative config** read by the Copilot CLI agent.
It controls which MCP servers are available in terminal / CLI sessions.

### 2. IntelliJ IDEA — MCP server registry
```
%APPDATA%\JetBrains\IntelliJIdea2026.2\options\llm.mcpServers.xml
```
This file registers the `azure-devops` server name with IntelliJ's
AI Assistant / Copilot plugin. It does **not** store the PAT — that stays
in the Copilot CLI config above.

### 3. IntelliJ IDEA — MCP feature toggle
```
%APPDATA%\JetBrains\IntelliJIdea2026.2\options\mcpServer.xml
```
Must have `enableMcpServer = true` for the MCP panel to appear in the IDE.

---

## mcp-config.json — Full Structure

Location: `%USERPROFILE%\.copilot\mcp-config.json`

```json
{
  "mcpServers": {
    "azure-devops": {
      "tools": ["*"],
      "type": "stdio",
      "command": "npx",
      "args": [
        "-y",
        "@azure-devops/mcp",
        "clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d",
        "--authentication",
        "pat"
      ],
      "env": {
        "AZURE_DEVOPS_EXT_PAT": "<YOUR_PAT_HERE>"
      }
    }
  }
}
```

> ⚠️ Replace `<YOUR_PAT_HERE>` with your own PAT (see PAT creation steps in
> `AZDO-SETUP-RUNBOOK.md`). Never commit a real PAT to source control.

**Field explanations:**

| Field | Purpose |
|---|---|
| `tools: ["*"]` | Allow all tools exposed by the server (wildcard) |
| `type: "stdio"` | Server runs as a subprocess — no HTTP port needed |
| `command: "npx"` | Launcher — `npx` auto-downloads the package on first run |
| `args[2]` | The ADO organization slug (not the full URL) |
| `--authentication pat` | Tells the server to read `AZURE_DEVOPS_EXT_PAT` |
| `AZURE_DEVOPS_EXT_PAT` | The PAT injected as an env var into the subprocess |

---

## llm.mcpServers.xml — IntelliJ Registration

Location: `%APPDATA%\JetBrains\IntelliJIdea2026.2\options\llm.mcpServers.xml`

```xml
<application>
  <component name="McpApplicationServerCommands"
             modifiable="true"
             autoEnableExternalChanges="true">
    <commands>
      <McpServerConfigurationProperties>
        <option name="allowedToolsNames" />
        <option name="enabled" value="true" />
        <option name="name" value="azure-devops" />
        <option name="source" value="USER" />
      </McpServerConfigurationProperties>
    </commands>
    <urls />
  </component>
</application>
```

**Key attributes:**

| Attribute | Purpose |
|---|---|
| `modifiable="true"` | IntelliJ can update this file |
| `autoEnableExternalChanges="true"` | IDE picks up edits without restart |
| `name="azure-devops"` | Must match the key in `mcp-config.json` |
| `source="USER"` | Server was added by the user (not a project config) |
| `enabled="true"` | Server is active |

---

## Step-by-Step: Configure from Scratch

### Prerequisites
- Node.js 18+ installed and on `PATH` (needed for `npx`)
- GitHub Copilot plugin installed in IntelliJ IDEA
- A valid Azure DevOps PAT (see `AZDO-SETUP-RUNBOOK.md` §3)

### Step 1 — Write the Copilot CLI config

Open PowerShell and run:
```powershell
$pat = Read-Host "Enter your ADO PAT" -AsSecureString
$plainPat = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($pat))

$config = @{
    mcpServers = @{
        "azure-devops" = @{
            tools   = @("*")
            type    = "stdio"
            command = "npx"
            args    = @("-y","@azure-devops/mcp",
                        "clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d",
                        "--authentication","pat")
            env     = @{ AZURE_DEVOPS_EXT_PAT = $plainPat }
        }
    }
} | ConvertTo-Json -Depth 6

New-Item -Force -Path "$env:USERPROFILE\.copilot" -ItemType Directory | Out-Null
$config | Set-Content "$env:USERPROFILE\.copilot\mcp-config.json" -Encoding UTF8
Write-Host "Written to $env:USERPROFILE\.copilot\mcp-config.json"
```

### Step 2 — Enable MCP in IntelliJ

1. In IntelliJ: **Settings → Tools → GitHub Copilot** (or **AI Assistant**).
2. Find the **MCP Servers** section and confirm the `azure-devops` entry is listed and enabled.
3. If it is missing, click **+** and add a new server with:
   - **Name**: `azure-devops`
   - **Type**: `Process (stdio)`
   - **Command**: `npx -y @azure-devops/mcp clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d --authentication pat`
   - **Environment variable**: `AZURE_DEVOPS_EXT_PAT = <your PAT>`

### Step 3 — Verify the server starts

In IntelliJ: open the **Copilot Chat** panel, type:
```
@azure-devops list projects
```
Expected: a list of projects in the organization (including `PRJ15999`).

Alternatively, in a terminal inside IntelliJ or the Copilot CLI:
```powershell
# Smoke-test: fetch work item 233502
# (Copilot CLI will route this through the MCP server automatically)
gh copilot suggest "get work item 233502 from PRJ15999"
```

---

## Stability — What Can Break and How to Fix It

| Symptom | Root Cause | Fix |
|---|---|---|
| `Error: spawn npx ENOENT` | Node.js / npx not on `PATH` | Install Node.js 18+; ensure `node` and `npx` are in system `PATH` |
| `401 Unauthorized` from MCP server | PAT expired or revoked | Generate a new PAT; update `AZURE_DEVOPS_EXT_PAT` in `mcp-config.json` |
| `azure-devops` server not shown in IDE | `llm.mcpServers.xml` missing entry | Re-add via Settings → MCP Servers (see Step 2 above) |
| Server listed but disabled | `enabled="false"` in XML | Toggle on in IDE settings or edit the XML directly |
| IDE ignores `mcp-config.json` changes | `autoEnableExternalChanges="false"` | Set to `true` in `llm.mcpServers.xml` or restart the IDE |
| `npx` re-downloads package every run | npm cache cleared | Run `npm install -g @azure-devops/mcp` to install globally |

---

## PAT Rotation Procedure

When the PAT expires or is revoked:

1. Generate a new PAT in Azure DevOps (see `AZDO-SETUP-RUNBOOK.md` §3).
2. Open `%USERPROFILE%\.copilot\mcp-config.json` in a text editor.
3. Replace the value of `AZURE_DEVOPS_EXT_PAT` with the new PAT.
4. Save the file — no IDE restart needed (`autoEnableExternalChanges="true"`).
5. Verify with a test query in Copilot Chat (Step 3 above).

> 💡 **Tip**: Set a calendar reminder before the PAT expiry date so rotation
> is planned, not reactive.

---

## Project-Level Config Template

A template (with no real PAT) is stored at:
```
.github\mcp-config.template.json
```
New team members copy this file to `%USERPROFILE%\.copilot\mcp-config.json`
and replace `<YOUR_PAT_HERE>` with their own PAT.
