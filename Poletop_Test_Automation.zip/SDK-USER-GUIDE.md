# Framework Automation SDK Ã¢â‚¬â€ User Guide

**Version:** 1.2.5  
**Artifact:** `com.test.automation:functional-test-automation-sdk:1.2.5`
**Repository:** `OTI QA Automation / functional-test-automation-sdk`

This guide is the **single document** a QA engineer needs to start a new Selenium
automation project on top of this SDK. No Selenium or TestNG expertise required
beyond what is described here.

---

## Table of Contents

1. [What the SDK Provides](#1-what-the-sdk-provides)
2. [Prerequisites](#2-prerequisites)
3. [Set Up a New Project](#3-set-up-a-new-project)
4. [Maven Dependency](#4-maven-dependency)
5. [Project Structure](#5-project-structure)
6. [Configuration Reference](#6-configuration-reference)
7. [The Element Crawler Ã¢â‚¬â€ Generating Page Objects](#7-the-element-crawler--generating-page-objects)
8. [Writing Page Objects (uiActions)](#8-writing-page-objects-uiactions)
9. [TestBase API Ã¢â‚¬â€ What You Can Use](#9-testbase-api--what-you-can-use)
10. [Writing Test Classes](#10-writing-test-classes)
11. [Test Data (Excel)](#11-test-data-excel)
12. [Running Tests](#12-running-tests)
13. [Reports & Screenshots](#13-reports--screenshots)
14. [Retry & Listeners](#14-retry--listeners)
15. [Locator Rules Ã¢â‚¬â€ Non-Negotiable](#15-locator-rules--non-negotiable)
16. [Complete End-to-End Example](#16-complete-end-to-end-example)
17. [Troubleshooting](#17-troubleshooting)

---

## 1. What the SDK Provides

The SDK is a single JAR that replaces every manual framework dependency. Your
automation project only needs **one** Maven dependency.

| Component | Class | What it gives you |
|-----------|-------|-------------------|
| **TestBase** | `sdk.testbase.TestBase` | Base class with 60+ ready-to-use Selenium helpers |
| **WebDriverFactory** | `sdk.testbase.WebDriverFactory` | Browser initialization (Chrome, Firefox, Edge, headless, Grid) |
| **SdkConfig** | `sdk.testbase.SdkConfig` | Auto-resolves config file paths via system property or env variable |
| **ElementCrawler** | `sdk.utility.ElementCrawler` | Scans a live page and generates a `@FindBy`-annotated Page Object |
| **PageObjectGenerator** | `sdk.utility.PageObjectGenerator` | Standalone runner for ElementCrawler |
| **Excel_Reader** | `sdk.utility.Excel_Reader` | Reads `.xlsx` test data into `Object[][]` for `@DataProvider` |
| **Listener** | `sdk.listener.Listener` | Auto-screenshot on failure, Extent report integration |
| **RetryListener** | `sdk.listener.RetryListener` | Automatic test retry on failure |
| **WebEventListener** | `sdk.listener.WebEventListener` | Logs every browser action for debugging |
| **Mailinator** | `sdk.utility.mailinator` | Reads emails from Mailinator API for email-flow testing |
| **YamlConfigReader** | `sdk.utility.YamlConfigReader` | Reads `sdk-config.yaml` for advanced SDK settings |

All Selenium, TestNG, Allure, Extent, and Apache POI transitive dependencies
are declared in the SDK's `pom.xml` Ã¢â‚¬â€ **you do not add them yourself**.

---

## 2. Prerequisites

| Tool | Required Version | Notes |
|------|-----------------|-------|
| Java JDK | 8 or higher | Must be on `PATH`. SDK is compiled at Java 8 source level. |
| Maven | 3.6 or higher | Must be on `PATH`. |
| Chrome + ChromeDriver | Latest stable | Versions must match. |
| IntelliJ IDEA | Any recent | Recommended IDE. |

---

## 3. Set Up a New Project

**Option A Ã¢â‚¬â€ Consumer Template (recommended)**

Clone the `framework_automation_consumer_template` repository. It is a
ready-to-run project with all folders, config files, and example tests already
in place.

```
git clone https://clt-40ea1dd4-1b0b-4f09-89ee-422fdfbba51d.visualstudio.com/OTI%20QA%20Automation/_git/framework_automation_consumer_template
```

Then rename the project:
1. Rename the folder to your app name.
2. Update `groupId` / `artifactId` / `name` in `pom.xml`.
3. Update `configuration/config.properties` with your app URLs.
4. Rename the Java packages under `src/test/java/` to match your company/app.

**Option B Ã¢â‚¬â€ Manual Project**

Create a Maven project and follow Sections 4Ã¢â‚¬â€œ6 to configure it from scratch.

---

## 4. Maven Dependency

Add exactly one dependency to your `pom.xml`. No other framework deps are needed.

```xml
<dependency>
    <groupId>com.test.automation</groupId>
    <artifactId>functional-test-automation-sdk</artifactId>
    <version>1.2.5</version>
</dependency>
```

If the SDK is hosted in an Azure Artifacts feed, also add the repository:

```xml
<repositories>
    <repository>
        <id>framework-automation-sdk</id>
        <url>https://pkgs.dev.azure.com/YOUR-ORG/YOUR-PROJECT/_packaging/YOUR-FEED/maven/v1</url>
        <releases><enabled>true</enabled></releases>
        <snapshots><enabled>false</enabled></snapshots>
    </repository>
</repositories>
```

And add credentials to `~/.m2/settings.xml`:

```xml
<server>
    <id>framework-automation-sdk</id>
    <username>AZDO</username>
    <password>YOUR_PAT_HERE</password>  <!-- scope: Packaging Read -->
</server>
```

---

## 5. Project Structure

```
your-app-automation/
Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ pom.xml
Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ regression_suite.xml          Ã¢â€ Â TestNG suite Ã¢â‚¬â€ add your test classes here
Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ crawler_suite.xml             Ã¢â€ Â Runs the page object generator
Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ configuration/
Ã¢â€â€š   Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ config.properties         Ã¢â€ Â App URLs, Excel file names, paths
Ã¢â€â€š   Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ sdk-config.yaml           Ã¢â€ Â Browser, proxy, screenshot settings
Ã¢â€â€š   Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ log4j.properties          Ã¢â€ Â Log4j1 config (legacy)
Ã¢â€â€š   Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ log4j2.properties         Ã¢â€ Â Log4j2 config (active)
Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ webDrivers/
Ã¢â€â€š   Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ chromedriver.exe          Ã¢â€ Â Local ChromeDriver binary
Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ src/
    Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ test/
        Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ java/
        Ã¢â€â€š   Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ com/<yourco>/automation/
        Ã¢â€â€š       Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ uiActions/    Ã¢â€ Â Page Objects Ã¢â‚¬â€ ALWAYS extend TestBase
        Ã¢â€â€š       Ã¢â€Å“Ã¢â€â‚¬Ã¢â€â‚¬ testCases/    Ã¢â€ Â Test Classes Ã¢â‚¬â€ ALWAYS extend TestBase
        Ã¢â€â€š       Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ tools/
        Ã¢â€â€š           Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ LocatorInvestigator.java
        Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ resources/
            Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ testData/
                Ã¢â€â€Ã¢â€â‚¬Ã¢â€â‚¬ YourApp_STG_TestData.xlsx
```

---

## 6. Configuration Reference

### 6.1 `configuration/config.properties` Ã¢â‚¬â€ Required

This file controls which URLs and Excel files the framework uses per environment.
The environment is selected at run time with `-Denvironment=stg`.

```properties
# Base URLs Ã¢â‚¬â€ one per environment
dev_base_url     = https://your-app-dev.example.com/
tst_base_url     = https://your-app-tst.example.com/
stg_base_url     = https://your-app-stg.example.com/
nonprod_base_url = https://your-app-nonprod.example.com/
prod_base_url    = https://your-app-prod.example.com/

# Browser (overridden at run time with -DbrowserName=chrome)
browser = chrome

# Paths Ã¢â‚¬â€ relative to project root
testDataDir    = /src/test/resources/testData/
screenshotsDir = /test-output/screenshots/
extReportDir   = /test-output/reports/

# Excel test data files Ã¢â‚¬â€ one per environment
dev_data_set     = YourApp_DEV_TestData.xlsx
tst_data_set     = YourApp_TST_TestData.xlsx
stg_data_set     = YourApp_STG_TestData.xlsx
nonprod_data_set = YourApp_NONPROD_TestData.xlsx
prod_data_set    = YourApp_PROD_TestData.xlsx
```

### 6.2 `configuration/sdk-config.yaml` Ã¢â‚¬â€ Optional Advanced Settings

Controls browser behavior, proxy, screenshots, and external services.

```yaml
browser:
  default: chrome            # chrome | firefox | edge
  headless: false            # true for CI/CD
  windowSize: "1920x1080"
  pageLoadTimeoutSeconds: 30
  implicitWaitSeconds: 0     # keep 0 Ã¢â‚¬â€ use TestBase explicit waits

proxy:
  enabled: false
  host: "bcpxy.nycnet"       # your corporate proxy
  port: 8080

screenshots:
  captureOnFailure: true
  outputDir: "test-output/screenshots"

api:
  mailinator:
    apiKey: "YOUR_MAILINATOR_API_KEY"
    domain: "mailinator.com"
```

### 6.3 Config Path Override

By default, the SDK reads from `./configuration/`. You can override this:

```bash
# Override via system property
mvn test -Dsdk.config.dir=/opt/ci/config -Denvironment=stg

# Override via environment variable
set SDK_CONFIG_DIR=C:\ci\config
mvn test -Denvironment=stg
```

---

## 7. The Element Crawler Ã¢â‚¬â€ Generating Page Objects

**Never write `@FindBy` locators by hand.** Always run the crawler first.

The crawler opens a live page, scans every element, tests each candidate locator
for uniqueness, and generates a ready-to-use Page Object Java file with only the
stable locators.

### Run the crawler

```bash
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg \
         -DbrowserName=chrome \
         -Dinv.email=your@email.com \
         -Dinv.password=yourPassword
```

### Outputs

| File | Location | Purpose |
|------|----------|---------|
| Page Object `.java` | `src/test/java/.../uiActions/` | Ready-to-edit page object |
| Locator report `.txt` | `test-output/crawler/` | Full list of all locators with uniqueness markers |

### Uniqueness markers in the report

| Marker | Meaning | Action |
|--------|---------|--------|
| `UNIQUE Ã¢Å“â€œ` | Exactly 1 element Ã¢â‚¬â€ safe to use | Ã¢Å“â€¦ Keep |
| `NOT UNIQUE (N found)` | Multiple matches | Ã¢ÂÅ’ Delete |
| `DYNAMIC` | Auto-generated ID (e.g. `mat-input-3`) | Ã¢ÂÅ’ Delete |
| `STALE` | 0 elements found | Ã¢ÂÅ’ Delete |
| `STRUCTURAL` | Position-based fallback | Ã¢ÂÅ’ Delete |

> After generating, open the `.java` file and **remove all locators that are not `UNIQUE Ã¢Å“â€œ`**.

---

## 8. Writing Page Objects (uiActions)

Every Page Object must follow this exact template.

```java
package com.yourcompany.automation.uiActions;

import com.test.automation.sdk.testbase.TestBase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends TestBase {

    public static final Logger log = LogManager.getLogger(LoginPage.class.getName());

    // Ã¢â€â‚¬Ã¢â€â‚¬ Locators Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬
    // Only UNIQUE Ã¢Å“â€œ locators from the crawler report. XPath only Ã¢â‚¬â€ no CSS.

    @FindBy(xpath = "//input[@id='email']")
    public WebElement emailField;

    @FindBy(xpath = "//input[@id='password']")
    public WebElement passwordField;

    @FindBy(xpath = "//button[normalize-space(.)='Log In']")
    public WebElement loginButton;

    @FindBy(xpath = "//h1[normalize-space(.)='Dashboard']")
    public WebElement dashboardHeader;

    // Ã¢â€â‚¬Ã¢â€â‚¬ Constructor Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Ã¢â€â‚¬Ã¢â€â‚¬ Actions Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬

    public void enterEmail(String email) {
        waitForElementPresent(driver, emailField);
        clearAndType(emailField, email);
    }

    public void enterPassword(String password) {
        waitForElementPresent(driver, passwordField);
        clearAndType(passwordField, password);
    }

    public void clickLogin() {
        fluentWaitUntilElementToBeClickable(loginButton);
        safeClick(loginButton);
        waitUntillPageLoad();
    }

    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickLogin();
    }

    public boolean isDashboardLoaded() {
        try {
            waitForElementPresent(driver, dashboardHeader);
            return dashboardHeader.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
```

### Rules
- Always `extends TestBase`.
- Always `PageFactory.initElements(driver, this)` in the constructor.
- Only XPath in `@FindBy` Ã¢â‚¬â€ no CSS selectors.
- No raw `sendKeys()` Ã¢â‚¬â€ always use `clearAndType()`.
- No `Thread.sleep()` Ã¢â‚¬â€ always use a TestBase wait method.
- No `new WebDriverWait(...)` Ã¢â‚¬â€ always use a TestBase wait method.

---

## 9. TestBase API Ã¢â‚¬â€ What You Can Use

All methods below are available in any class that extends `TestBase`.

### Waiting Ã¢â‚¬â€ before interacting with elements

| Method | When to use |
|--------|-------------|
| `waitForElementPresent(driver, element)` | Before reading text or attributes |
| `fluentWaitUntilElementToBeClickable(element)` | Before every click |
| `waitUntillPageLoad()` | After any navigation or page transition |
| `waitForElementToDisappear(By locator)` | After form submit Ã¢â‚¬â€ wait for spinner to disappear |
| `waitForAttributeToContain(element, "class", "active", 30)` | Wait for CSS state changes |
| `waitForTextPresent(element, "text")` | Wait for dynamic text to appear |

### Text input

| Method | When to use |
|--------|-------------|
| `clearAndType(element, value)` | **Any** text field input |

### Clicks

| Method | When to use |
|--------|-------------|
| `safeClick(element)` | Standard clicks Ã¢â‚¬â€ retries on timing issues |
| `clickOnElementbyJavaScript(element)` | When a normal click is blocked by an overlay |

### Reading element text

| Method | When to use |
|--------|-------------|
| `safeGetText(element)` | Any `getText()` call Ã¢â‚¬â€ handles stale element retries |

### Verification (in test classes)

| Method | When to use |
|--------|-------------|
| `verifyText(expected, actual)` | Assert element text equals expected value |

### Dropdowns

| Method | When to use |
|--------|-------------|
| `selectOptionInDropDownBox(element, text)` | Native HTML `<select>` |
| `visibleInDropDownList(element, text)` | Native HTML `<select>` by visible text |
| `getSelectedOption(element)` | Read current selection |
| `getAllDropdownOptions(element)` | Get all options as a list |

> For Angular `<mat-select>`: click the trigger Ã¢â€ â€™ click the `mat-option` element directly.

### Scrolling

| Method | When to use |
|--------|-------------|
| `scrollToElement(element)` | Before interacting with elements below the fold |
| `scrollToTop()` / `scrollToBottom()` | Full-page scrolling |

### Checkboxes

| Method | When to use |
|--------|-------------|
| `selectCheckbox(element)` | Check a box (idempotent Ã¢â‚¬â€ won't double-click) |
| `deselectCheckbox(element)` | Uncheck a box (idempotent) |

### Windows & Tabs

| Method | When to use |
|--------|-------------|
| `switchToNewWindow()` | After an action opens a new tab |
| `closeCurrentTabAndSwitchToParent()` | Close the new tab and return |
| `openNewTab()` | Programmatically open a new tab |

### Frames

| Method | When to use |
|--------|-------------|
| `switchtoFrame(frameName)` | Enter a named iframe |
| `switchtoDefaultFrame()` | Return to main page content |

### Alerts

| Method | When to use |
|--------|-------------|
| `acceptAlert()` | Confirm a browser alert dialog |
| `dismissAlert()` | Cancel a browser alert dialog |
| `getAlertText()` | Read alert message text |

### Mouse & Keyboard (Advanced)

| Method | When to use |
|--------|-------------|
| `hoverOverElement(element)` | Reveal hover menus |
| `doubleClick(element)` | Double-click interaction |
| `pressKey(element, Keys.TAB)` | Send keyboard keys |
| `dragAndDrop(source, target)` | Drag-and-drop interactions |

### Screenshots

| Method | When to use |
|--------|-------------|
| `getScreenShot(name)` | Manual screenshot at any test step |
| `captureScreen(fileName)` | Returns the file path after capturing |

> Failure screenshots are taken **automatically** by `Listener` Ã¢â‚¬â€ no manual code needed.

### Data Generators

| Method | Returns |
|--------|---------|
| `randomEmailAddress()` | `test123456@doitt.nyc.gov` |
| `randomEmailAddress("domain.com")` | `test12345678@domain.com` |
| `randomPassword()` | `test123456` |
| `newUniqueUsername()` | `user2606111503001` (timestamp-based) |
| `randomString()` | 5-digit numeric string |

### File Upload

| Method | When to use |
|--------|-------------|
| `uploadFile(fileInputElement, "C:\\path\\to\\file.pdf")` | Upload via `<input type="file">`. Works with Selenium Grid. |

---

## 10. Writing Test Classes

Every test class must follow this exact template.

```java
package com.yourcompany.automation.testCases;

import static io.qameta.allure.Allure.step;

import com.test.automation.sdk.testbase.TestBase;
import com.yourcompany.automation.uiActions.LoginPage;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;

public class Test_Login extends TestBase {

    // Ã¢â€â‚¬Ã¢â€â‚¬ DataProvider Ã¢â‚¬â€ maps to one sheet in the Excel test data file Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬

    @DataProvider(name = "loginData")
    public Object[][] loginData() throws IOException {
        return getData("LoginSheet");
    }

    // Ã¢â€â‚¬Ã¢â€â‚¬ Test method Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬Ã¢â€â‚¬

    @Test(dataProvider = "loginData", priority = 1)
    public void testValidLogin(String testCaseName,
                               String email,
                               String password,
                               String runMode) throws Exception {

        // 1. Skip check Ã¢â‚¬â€ ALWAYS first
        if ("N".equalsIgnoreCase(runMode))
            throw new SkipException("Skipping: " + testCaseName);

        // 2. Test steps with Allure reporting
        step("Navigate to application");
        driver.get(baseURL);
        waitUntillPageLoad();

        step("Enter credentials and log in");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(email, password);

        step("Assert dashboard is loaded");
        Assert.assertTrue(loginPage.isDashboardLoaded(),
            "Dashboard header was not displayed after login");
    }
}
```

### Rules
- Always `extends TestBase`.
- Always `@DataProvider` backed by an Excel sheet.
- First line of every `@Test` method: check `runMode` Ã¢â‚¬â€ skip if `"N"`.
- Use `step("Ã¢â‚¬Â¦")` for every logical step (visible in Allure report).
- Use `Assert.assertTrue/assertFalse/assertEquals` Ã¢â‚¬â€ never an `if` without assertion.
- Navigate back to the base URL or log out at the end of each test.

---

## 11. Test Data (Excel)

Each test class reads from a sheet in the environment Excel file.

### Excel file naming
```
YourApp_STG_TestData.xlsx      (declared as stg_data_set in config.properties)
```

### Required sheet columns

Every sheet must start with these two columns and end with `runMode`:

| Column | Example | Description |
|--------|---------|-------------|
| `testCaseName` | `TC_001 Ã¢â‚¬â€ Valid Login` | Identifies the row in reports |
| (your data cols) | `user@email.com` | Any columns your test needs |
| `runMode` | `Y` or `N` | `Y` = execute, `N` = skip |

### DataProvider method

```java
@DataProvider(name = "loginData")
public Object[][] loginData() throws IOException {
    return getData("LoginSheet");         // reads ExcelName set by @BeforeClass
}
```

Each row in the sheet maps to one test execution. The columns map positionally
to the `@Test` method parameters.

---

## 12. Running Tests

### Full regression suite

```bash
mvn test -Denvironment=stg -DbrowserName=chrome
```

### Single test class

```bash
mvn test -Dtest=Test_Login -Denvironment=stg -DbrowserName=chrome
```

### Run via TestNG suite XML

```bash
mvn test -Dsurefire.suiteXmlFiles=regression_suite.xml \
         -Denvironment=stg -DbrowserName=chrome
```

### Run the page object crawler

```bash
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=your@email.com -Dinv.password=yourPassword
```

### Environment options

| `-Denvironment` | URL used |
|-----------------|---------|
| `dev` | `dev_base_url` |
| `tst` | `tst_base_url` |
| `stg` | `stg_base_url` (default) |
| `nonprod` | `nonprod_base_url` |
| `prod` | `prod_base_url` |

### Browser options

| `-DbrowserName` | Browser |
|----------------|---------|
| `chrome` | Google Chrome (default) |
| `firefox` | Mozilla Firefox |
| `edge` | Microsoft Edge |

---

## 13. Reports & Screenshots

The SDK generates two report types automatically Ã¢â‚¬â€ no configuration required.

### Allure Report

```bash
# Generate and open Allure report after test run
mvn allure:serve
```

Steps recorded via `step("Ã¢â‚¬Â¦")` are visible in the Allure timeline.

### Extent Report

HTML report generated at `test-output/reports/` after every run.

### Screenshots

Failure screenshots are captured automatically by `Listener` and attached to both
reports. Manual screenshots:

```java
getScreenShot("my-screenshot");           // saves to test-output/screenshots/
String path = captureScreen("my-file");   // saves and returns the path
```

---

## 14. Retry & Listeners

These are pre-configured in the SDK Ã¢â‚¬â€ declare them in your TestNG suite XML.

```xml
<!-- regression_suite.xml -->
<suite name="Regression" verbose="1">
    <listeners>
        <listener class-name="com.test.automation.sdk.listener.Listener"/>
        <listener class-name="com.test.automation.sdk.listener.RetryListener"/>
    </listeners>
    <test name="All Tests">
        <classes>
            <class name="com.yourco.automation.testCases.Test_Login"/>
        </classes>
    </test>
</suite>
```

| Listener | What it does |
|---------|--------------|
| `Listener` | Takes a screenshot and logs to Extent report on test failure |
| `RetryListener` | Automatically retries a failed test once |
| `WebEventListener` | Logs every driver action (enabled per WebDriverFactory config) |

---

## 15. Locator Rules Ã¢â‚¬â€ Non-Negotiable

These rules exist to prevent flaky tests.

### Ã¢Å“â€¦ Allowed XPath strategies (priority order)

```
1.  @id                 Ã¢â‚¬â€ stable non-generated ID
2.  @data-testid        Ã¢â‚¬â€ intentional test attribute
3.  @formcontrolname    Ã¢â‚¬â€ Angular reactive forms
4.  @name + @type       Ã¢â‚¬â€ standard form fields
5.  @name               Ã¢â‚¬â€ when type is not needed
6.  @aria-label         Ã¢â‚¬â€ accessibility attribute
7.  @placeholder        Ã¢â‚¬â€ input fields
8.  normalize-space(.)  Ã¢â‚¬â€ buttons/links with unique text
9.  @routerlink         Ã¢â‚¬â€ Angular navigation
10. @href               Ã¢â‚¬â€ static links
```

### Ã¢ÂÅ’ Never use

```
@id='mat-input-3'          dynamic Angular Material ID
@id='cdk-overlay-1'        dynamic CDK overlay ID
(//input)[2]               positional index
//div[3]/form/input[1]     structural path
@class only                breaks on any styling change
```

### Examples

```java
// Ã¢Å“â€¦ Correct
@FindBy(xpath = "//input[@id='email']")
@FindBy(xpath = "//input[@formcontrolname='password']")
@FindBy(xpath = "//button[normalize-space(.)='Log In']")
@FindBy(xpath = "//mat-select[@formcontrolname='borough']")

// Ã¢ÂÅ’ Wrong
@FindBy(xpath = "//input[@id='mat-input-0']")     // dynamic
@FindBy(xpath = "(//input)[2]")                    // positional
@FindBy(css   = "input.form-control")              // CSS not allowed
```

---

## 16. Complete End-to-End Example

**Scenario:** Automate a login test.

### Step 1 Ã¢â‚¬â€ Run the crawler on the login page

```bash
mvn test -Dsurefire.suiteXmlFiles=crawler_suite.xml \
         -Denvironment=stg -DbrowserName=chrome \
         -Dinv.email=admin@app.com -Dinv.password=secret
```

### Step 2 Ã¢â‚¬â€ Review the generated Page Object

Open `src/test/java/.../uiActions/LoginPage.java` and the `.txt` report.
Remove all locators not marked `UNIQUE Ã¢Å“â€œ`.

### Step 3 Ã¢â‚¬â€ Add business-logic methods to LoginPage

```java
public void login(String email, String password) {
    waitForElementPresent(driver, emailField);
    clearAndType(emailField, email);
    clearAndType(passwordField, password);
    fluentWaitUntilElementToBeClickable(loginButton);
    safeClick(loginButton);
    waitUntillPageLoad();
}

public String getDashboardTitle() {
    waitForElementPresent(driver, dashboardHeader);
    return safeGetText(dashboardHeader);
}
```

### Step 4 Ã¢â‚¬â€ Add test data to Excel

Add a sheet named `LoginSheet` to `YourApp_STG_TestData.xlsx`:

| testCaseName | email | password | runMode |
|---|---|---|---|
| TC_001 Ã¢â‚¬â€ Valid Login | user@app.com | Pass123! | Y |
| TC_002 Ã¢â‚¬â€ Skip Me | skip@app.com | xxx | N |

### Step 5 Ã¢â‚¬â€ Create the test class

```java
@DataProvider(name = "loginData")
public Object[][] loginData() throws IOException {
    return getData("LoginSheet");
}

@Test(dataProvider = "loginData", priority = 1)
public void testLogin(String testCaseName, String email,
                      String password, String runMode) throws Exception {
    if ("N".equalsIgnoreCase(runMode))
        throw new SkipException("Skipping: " + testCaseName);

    step("Open login page");
    driver.get(baseURL);

    step("Login with " + email);
    LoginPage page = new LoginPage(driver);
    page.login(email, password);

    step("Verify dashboard title");
    verifyText("Dashboard", page.getDashboardTitle());
}
```

### Step 6 Ã¢â‚¬â€ Compile and run

```bash
mvn compile test-compile
mvn test -Dtest=Test_Login -Denvironment=stg -DbrowserName=chrome
```

Expected output:
```
Tests run: 1, Failures: 0, Errors: 0, Skipped: 1
BUILD SUCCESS
```

---

## 17. Troubleshooting

| Problem | Likely cause | Fix |
|---------|-------------|-----|
| `NoSuchElementException` | Locator is dynamic or not `UNIQUE Ã¢Å“â€œ` | Re-run crawler; use a stable XPath |
| `StaleElementReferenceException` | DOM re-rendered after element was found | Use `safeClick()` / `safeGetText()` / `clearAndType()` |
| `TimeoutException` on wait | Page is slow or element is conditional | Increase timeout in `waitForElementPresent(element, 120)` |
| `SessionNotCreatedException` | ChromeDriver version mismatch | Update `chromedriver.exe` to match Chrome version |
| `Cannot read config.properties` | Wrong working directory | Run `mvn test` from the project root |
| Corporate proxy blocking ChromeDriver download | Proxy not configured | Set `proxy.enabled=true` in `sdk-config.yaml` |
| Excel `NullPointerException` | Wrong sheet name in `getData()` | Check sheet name matches exactly (case-sensitive) |
| `BUILD FAILURE` on compile | Import not found | Verify SDK dependency version in `pom.xml` |

---

*Framework Automation SDK Ã¢â‚¬â€ `com.test.automation:functional-test-automation-sdk:1.2.5`*  
*Maintained by OTI QA Automation Team*
