# TestBase API Reference

`com.test.automation.sdk.testbase.TestBase`

All **Page Objects** (`uiActions` classes) and **Test Classes** must extend `TestBase`.  
This class provides the full Selenium helper library Ã¢â‚¬â€ never use raw Selenium APIs directly in your classes.

---

## Table of Contents

1. [Lifecycle & Setup](#1-lifecycle--setup)
2. [Navigation](#2-navigation)
3. [Test Data (Excel)](#3-test-data-excel)
4. [Waiting Ã¢â‚¬â€ Visibility & Presence](#4-waiting--visibility--presence)
5. [Waiting Ã¢â‚¬â€ Clickability](#5-waiting--clickability)
6. [Waiting Ã¢â‚¬â€ Disappearance](#6-waiting--disappearance)
7. [Waiting Ã¢â‚¬â€ Attribute / Value](#7-waiting--attribute--value)
8. [Waiting Ã¢â‚¬â€ Page Load](#8-waiting--page-load)
9. [Text Entry](#9-text-entry)
10. [Clicks](#10-clicks)
11. [Dropdowns & Select](#11-dropdowns--select)
12. [Checkboxes & Radio Buttons](#12-checkboxes--radio-buttons)
13. [Mouse & Keyboard Actions](#13-mouse--keyboard-actions)
14. [Frames](#14-frames)
15. [Windows & Tabs](#15-windows--tabs)
16. [Alerts](#16-alerts)
17. [Scrolling & JavaScript](#17-scrolling--javascript)
18. [Screenshots & Reporting](#18-screenshots--reporting)
19. [Text Verification](#19-text-verification)
20. [Data Generators](#20-data-generators)
21. [File Upload](#21-file-upload)
22. [Page Reload Helpers](#22-page-reload-helpers)
23. [Generic List Resolver & ElementAction](#23-generic-list-resolver--elementaction)
24. [Repeating Groups](#24-repeating-groups)
25. [Bootstrap / Custom Dropdowns](#25-bootstrap--custom-dropdowns)
26. [Table Helpers](#26-table-helpers)
27. [Label Harvesters](#27-label-harvesters)
28. [Collection Utilities](#28-collection-utilities)

---

## 1. Lifecycle & Setup

These methods are called automatically by TestNG hooks Ã¢â‚¬â€ you rarely call them directly.

| Method | Signature | Description |
|--------|-----------|-------------|
| `setUp` | `setUp(String environment, String browserName)` | `@BeforeClass` Ã¢â‚¬â€ resolves environment, Excel file, and base URL, then opens the browser. |
| `afterClass` | `afterClass()` | `@AfterClass` Ã¢â‚¬â€ closes browser and flushes Extent reports. |
| `beforeMethod` | `beforeMethod(Method result)` | `@BeforeMethod` Ã¢â‚¬â€ handles retry logic by reinitializing the browser on retries. |
| `initialization` | `initialization(String browser, String baseUrl)` | Opens the browser and navigates to the base URL. Falls back to `config.properties` if empty strings are passed. |
| `loadData` | `loadData()` | Loads `config.properties` into the `Prop` field. Called automatically. |
| `closeBrowser` | `closeBrowser()` | Quits the WebDriver session and flushes reporting. |

---

## 2. Navigation

| Method | Signature | Description |
|--------|-----------|-------------|
| `getUrl` | `getUrl(String url)` | Navigates to the URL, maximizes the window, and waits for page load. |
| `setBaseUrl` | `setBaseUrl(String environment)` | Resolves `baseURL` from `config.properties` for the given environment key (`dev`, `tst`, `stg`, `nonprod`, `prod`). |
| `setXlsName` | `setXlsName(String environment)` | Resolves the Excel test data file name for the given environment. |

**Usage in test:**
```java
// Navigate back to home after a test
driver.get(baseURL);
waitUntillPageLoad();
```

---

## 3. Test Data (Excel)

| Method | Signature | Description |
|--------|-----------|-------------|
| `getData` | `getData(String sheetName)` | Reads the Excel file set by `setXlsName()` and returns a 2D data array for `@DataProvider`. |
| `getData` | `getData(String excelFileName, String sheetName)` | Reads an explicitly specified Excel file. |
| `selectExcelData` | `selectExcelData(String sheetName, String sqlQuery)` | Queries the Excel sheet with a SQL expression and returns filtered rows. |

**Typical usage in test:**
```java
@DataProvider(name = "myData")
public Object[][] myData() throws IOException {
    return getData("MySheet");
}
```

---

## 4. Waiting Ã¢â‚¬â€ Visibility & Presence

Use these methods **in Page Objects** before reading an element's text or attributes.

| Method | Signature | Timeout | Description |
|--------|-----------|---------|-------------|
| `waitForElementPresent` | `waitForElementPresent(WebDriver driver, WebElement element)` | 60 s | Waits until the element is visible. **Preferred for Page Objects.** |
| `waitForElementPresent` | `waitForElementPresent(WebElement element)` | 60 s | Static shorthand Ã¢â‚¬â€ uses the shared `driver`. |
| `waitForElementPresent` | `waitForElementPresent(WebElement element, int timeout)` | custom | Waits with a custom timeout. |
| `waitForElementPresent` | `waitForElementPresent(By locator)` | 120 s | Waits by `By` locator. |
| `waitForElement` | `waitForElement(WebDriver driver, int timeoutInSeconds, WebElement element)` | custom | Explicit wait by timeout value. |
| `waitForElement` | `waitForElement(WebDriver driver, WebElement element, long timeoutInSeconds)` | custom | Returns the element after it becomes clickable. |
| `fluentWaitForElementPresent` | `fluentWaitForElementPresent(WebElement element)` | 60 s / 2 s poll | FluentWait Ã¢â‚¬â€ ignores `NoSuchElementException` and `StaleElementReferenceException`. |
| `fluentWaitForElementPresent` | `fluentWaitForElementPresent(WebDriver driver, WebElement element)` | 60 s / 2 s poll | Static overload. |
| `fluentWaitForElement` | `fluentWaitForElement(WebElement element)` | 120 s / 5 s poll | Waits for both visibility AND clickability. |
| `waitForTextPresent` | `waitForTextPresent(WebElement element, String text)` | 120 s | Waits until the element contains the expected text. |
| `waitUntilTitleIsPresent` | `waitUntilTitleIsPresent(WebDriver driver, String titleText)` | 120 s | Waits for the page title to contain the text. |

**Example in a Page Object:**
```java
public String getStatusText() {
    waitForElementPresent(driver, statusLabel);
    return statusLabel.getText().trim();
}
```

---

## 5. Waiting Ã¢â‚¬â€ Clickability

Use these methods **before clicking** any element.

| Method | Signature | Timeout | Description |
|--------|-----------|---------|-------------|
| `fluentWaitUntilElementToBeClickable` | `fluentWaitUntilElementToBeClickable(WebElement element)` | 120 s / 5 s poll | **Primary method** Ã¢â‚¬â€ waits for visibility then clickability. Ignores stale/timeout exceptions. |
| `waitUntilElementToBeClickable` | `waitUntilElementToBeClickable(WebElement element)` | 60 s | Standard `WebDriverWait` clickability check. |
| `waitUntilButtonIsClickable` | `waitUntilButtonIsClickable(By locator)` | 60 s | Waits by `By` locator and returns the element. |
| `elementIsClickable` | `elementIsClickable(WebElement element, WebDriver driver, long timeoutSeconds)` | custom | Returns `true`/`false` Ã¢â‚¬â€ useful for conditional checks without throwing. |

**Example in a Page Object:**
```java
public void clickSubmit() {
    fluentWaitUntilElementToBeClickable(submitButton);
    submitButton.click();
}
```

---

## 6. Waiting Ã¢â‚¬â€ Disappearance

| Method | Signature | Timeout | Description |
|--------|-----------|---------|-------------|
| `waitForElementToDisappear` | `waitForElementToDisappear(By locator)` | 60 s | Waits for element to become invisible or absent. |
| `waitForElementToDisappear` | `waitForElementToDisappear(By locator, long timeoutSeconds)` | custom | Same with custom timeout. |
| `waitForElementToDisappear` | `waitForElementToDisappear(WebElement element, long timeoutSeconds)` | custom | WebElement overload. |

**Example:**
```java
// Wait for a loading spinner to disappear
waitForElementToDisappear(By.xpath("//mat-spinner"), 30);
```

---

## 7. Waiting Ã¢â‚¬â€ Attribute / Value

| Method | Signature | Description |
|--------|-----------|-------------|
| `waitForAttributeToBe` | `waitForAttributeToBe(WebElement element, String attribute, String expectedValue, long timeoutSeconds)` | Waits until `element.getAttribute(attribute)` equals `expectedValue`. |
| `waitForAttributeToContain` | `waitForAttributeToContain(WebElement element, String attribute, String substring, long timeoutSeconds)` | Waits until `element.getAttribute(attribute)` contains `substring`. |

**Example:**
```java
// Wait for the class attribute to include 'active'
waitForAttributeToContain(tabElement, "class", "active", 30);
```

---

## 8. Waiting Ã¢â‚¬â€ Page Load

| Method | Signature | Timeout | Description |
|--------|-----------|---------|-------------|
| `waitUntillPageLoad` | `waitUntillPageLoad()` | 120 s | **Preferred.** Waits for `document.readyState === 'complete'`. Call after any navigation. |
| `waitForPageToLoad` | `waitForPageToLoad(long timeoutSeconds)` | custom | Same with configurable timeout. Asserts failure if the page doesn't load. |

---

## 9. Text Entry

| Method | Signature | Description |
|--------|-----------|-------------|
| `clearAndType` | `clearAndType(WebElement element, String text)` | **Primary text input method.** Clears the field, then types. Retries up to 3Ãƒâ€” on stale/not-interactable exceptions. |

> Ã¢Å¡Â Ã¯Â¸Â **Never** use raw `element.sendKeys()` in Page Objects. Always use `clearAndType()`.

**Example:**
```java
public void enterEmail(String email) {
    waitForElementPresent(driver, emailField);
    clearAndType(emailField, email);
}
```

---

## 10. Clicks

| Method | Signature | Description |
|--------|-----------|-------------|
| `safeClick` | `safeClick(WebElement element)` | Fluent-waits for clickability then clicks. Retries 3Ãƒâ€” on WebDriver exceptions. **Use for any click that may have timing issues.** |
| `clickOnElementbyJavaScript` | `clickOnElementbyJavaScript(WebElement element)` | Clicks via JavaScript executor. Use when normal click is intercepted by overlays. |

**Example:**
```java
public void clickSave() {
    fluentWaitUntilElementToBeClickable(saveButton);
    safeClick(saveButton);
}
```

---

## 11. Dropdowns & Select

These methods work with native HTML `<select>` elements.

| Method | Signature | Description |
|--------|-----------|-------------|
| `selectOptionInDropDownBox` | `selectOptionInDropDownBox(WebElement element, String value)` | Selects an option by matching visible text. |
| `visibleInDropDownList` | `visibleInDropDownList(WebElement element, String textValue)` | Selects by visible text using `Select.selectByVisibleText()`. |
| `selectByIndex` | `selectByIndex(WebElement element, int index)` | Selects by zero-based index. |
| `selectByValue` | `selectByValue(WebElement element, String value)` | Selects by the option's `value` attribute. |
| `getSelectedOption` | `getSelectedOption(WebElement element)` | Returns the text of the currently selected option. |
| `getAllDropdownOptions` | `getAllDropdownOptions(WebElement element)` | Returns a `List<String>` of all option texts. |

> For Angular Material `<mat-select>` dropdowns, click the trigger element, then click the `mat-option` directly Ã¢â‚¬â€ do not use `Select` API.

---

## 12. Checkboxes & Radio Buttons

| Method | Signature | Description |
|--------|-----------|-------------|
| `selectCheckbox` | `selectCheckbox(WebElement element)` | Clicks the checkbox only if it is **not** already selected (idempotent). |
| `deselectCheckbox` | `deselectCheckbox(WebElement element)` | Clicks the checkbox only if it **is** selected (idempotent). |

---

## 13. Mouse & Keyboard Actions

| Method | Signature | Description |
|--------|-----------|-------------|
| `hoverOverElement` | `hoverOverElement(WebElement element)` | Moves mouse over the element (hover). |
| `doubleClick` | `doubleClick(WebElement element)` | Double-clicks the element. |
| `rightClick` | `rightClick(WebElement element)` | Context-clicks (right-click) the element. |
| `dragAndDrop` | `dragAndDrop(WebElement source, WebElement target)` | Drags `source` and drops it on `target`. |
| `pressKey` | `pressKey(WebElement element, CharSequence key)` | Clicks the element then sends a special key (e.g. `Keys.TAB`, `Keys.ENTER`). |
| `highlightMe` | `highlightMe(WebDriver driver, WebElement element)` | Highlights an element with a yellow border (debugging only). |

**Example:**
```java
// Press TAB to move to next field
pressKey(emailField, Keys.TAB);
```

---

## 14. Frames

| Method | Signature | Description |
|--------|-----------|-------------|
| `switchtoFrame` | `switchtoFrame(String frameName)` | Switches to a named frame (returns to default content first). |
| `switchToFrame` | `switchToFrame(int index)` | Switches to a frame by index. |
| `switchToFrame` | `switchToFrame(WebElement frameElement)` | Switches to a frame identified by a `WebElement`. |
| `switchToChildFrame` | `switchToChildFrame(String parentFrame, String childFrame)` | Switches to parent then child frame. |
| `switchtoDefaultFrame` | `switchtoDefaultFrame()` | Switches back to the main page content. |

---

## 15. Windows & Tabs

| Method | Signature | Description |
|--------|-----------|-------------|
| `getAllWindows` | `getAllWindows()` | Returns an `Iterator<String>` over all open window handles. |
| `switchToWindow` | `switchToWindow(String windowHandle)` | Switches to the given handle, returns the previous handle. |
| `switchToNewWindow` | `switchToNewWindow()` | Stores the current handle in `parentWindow` and switches to the most recently opened window/tab. |
| `switchToParentWindow` | `switchToParentWindow()` | Switches back to the stored `parentWindow` handle. |
| `closeCurrentTabAndSwitchToParent` | `closeCurrentTabAndSwitchToParent()` | Closes the active tab and returns to the parent window. |
| `openNewTab` | `openNewTab()` | Opens a new blank tab via JavaScript and switches to it. |

---

## 16. Alerts

| Method | Signature | Timeout | Description |
|--------|-----------|---------|-------------|
| `waitForAlert` | `waitForAlert(long timeoutSeconds)` | custom | Waits for an alert to appear and returns the `Alert`. |
| `acceptAlert` | `acceptAlert()` | 10 s | Accepts (OK) the alert. |
| `dismissAlert` | `dismissAlert()` | 10 s | Dismisses (Cancel) the alert. |
| `getAlertText` | `getAlertText()` | 10 s | Returns the alert message text. |
| `sendKeysToAlert` | `sendKeysToAlert(String text)` | 10 s | Types text into a prompt alert. |

---

## 17. Scrolling & JavaScript

| Method | Signature | Description |
|--------|-----------|-------------|
| `scrollToElement` | `scrollToElement(WebElement element)` | Scrolls the element into view with a brief pause for UI settling. |
| `scrollToElement` | `scrollToElement(By by, WebDriver driver)` | Scrolls to element located by `By` locator. |
| `scrollToTop` | `scrollToTop()` | Scrolls to the top of the page. |
| `scrollToBottom` | `scrollToBottom()` | Scrolls to the bottom of the page. |
| `executeScript` | `executeScript(String script, Object... args)` | Executes arbitrary JavaScript. Returns the script's return value or `null`. |

**Example:**
```java
// Scroll to an element before clicking it
scrollToElement(submitButton);
safeClick(submitButton);
```

---

## 18. Screenshots & Reporting

| Method | Signature | Description |
|--------|-----------|-------------|
| `getScreenShot` | `getScreenShot(String name)` | Captures a screenshot to the output directory with a timestamp. |
| `getScreenShot` | `getScreenShot(WebDriver driver, ITestResult result, String folderName)` | Captures a screenshot on test failure and attaches it to the Extent report. |
| `captureScreen` | `captureScreen(String fileName)` | Captures a screenshot and returns the absolute file path. |
| `getresult` | `getresult(ITestResult result)` | Logs the TestNG result (PASS/FAIL/SKIP) into the Extent report. |

> Screenshots are saved to the directory configured in `sdk-config.yaml` Ã¢â€ â€™ `screenshots.outputDir` (default: `test-output/screenshots`).

---

## 19. Text Verification

| Method | Signature | Description |
|--------|-----------|-------------|
| `verifyText` | `verifyText(String expectedText, String actualText)` | Asserts that `actualText` equals `expectedText`. Throws a descriptive `AssertionError` on mismatch. |
| `verifyTextOnThePage` | `verifyTextOnThePage(String text)` | Returns `true` if the text is present anywhere in the page source. |
| `safeGetText` | `safeGetText(WebElement element)` | Reads `element.getText()` with up to 3 retries on `StaleElementReferenceException`. Returns trimmed text. |

**Example in a test:**
```java
String actual = safeGetText(confirmationMessage);
verifyText("Application Submitted", actual);
```

---

## 20. Data Generators

| Method | Signature | Description |
|--------|-----------|-------------|
| `randomEmailAddress` | `randomEmailAddress()` | Generates a random `test<6-digits>@doitt.nyc.gov` email. |
| `randomEmailAddress` | `randomEmailAddress(String domain)` | Generates a random email on the provided domain. |
| `randomPassword` | `randomPassword()` | Generates a random `test<6-digits>` password string. |
| `newUniqueUsername` | `newUniqueUsername()` | Generates a timestamp-based unique username (`user<yyMMddhhmmssMs>`). |
| `randomString` | `randomString()` | Returns a random 5-digit numeric string. |

---

## 21. File Upload

| Method | Signature | Description |
|--------|-----------|-------------|
| `uploadFile` | `uploadFile(WebElement fileInput, String filePath)` | Sends the absolute file path to an `<input type="file">` element. Automatically configures `LocalFileDetector` for Selenium Grid runs. |

**Example:**
```java
uploadFile(fileInputElement, "C:\\TestData\\sample.pdf");
```

---

## 22. Page Reload Helpers

| Method | Signature | Description |
|--------|-----------|-------------|
| `reloadPageUntilTextVisible` | `reloadPageUntilTextVisible(String text)` | Refreshes the page up to 20 times until the given text appears in the page source. |
| `reloadPageUntilWebElementVisible` | `reloadPageUntilWebElementVisible(WebElement element)` | Refreshes the page up to 30 times until the element is displayed. |
| `explicitWait` | `explicitWait(int seconds)` | Sets the implicit wait on the WebDriver session. **Prefer targeted waits** over this Ã¢â‚¬â€ it affects all subsequent `findElement` calls. |

---

## 23. Generic List Resolver & ElementAction

`actOnListElement` is the **primary method for interacting with any repeated element list** (nav items, menu items, table rows, tag groups). It replaces all hand-written loops.

### `ElementAction` enum

```java
public enum ElementAction { CLICK, TYPE, SELECT, FIND }
```

### `actOnListElement`

| Parameter | Type | Description |
|---|---|---|
| `elements` | `List<WebElement>` | Any `@FindBy` list |
| `matchText` | `String` | Case-insensitive contains match on element text |
| `action` | `ElementAction` | What to do when match is found |
| `value` | `String` | Value for `TYPE` or `SELECT`; `null` for `CLICK`/`FIND` |

**Returns:** matched `WebElement` or `null`.

```java
// In page object @FindBy:
@FindBy(xpath = "//*[@id='nav-primary']//ul//li")
public List<WebElement> navMenuItems;

// In action method:
public void goToEnroll() {
    actOnListElement(navMenuItems, "New Reservation", ElementAction.CLICK, null);
}

// With a label list (partial id match pattern):
@FindBy(xpath = "//*[contains(@id,'field-label')]")
public List<WebElement> formLabels;

public void clickFieldByLabel(String label) {
    actOnListElement(formLabels, label, ElementAction.CLICK, null);
}
```

**How it works:**
1. Iterates the list, finds item where `getText()` contains `matchText` (case-insensitive).
2. Calls `resolveConfirmedXpath(element)` Ã¢â‚¬â€ tests id/routerlink/href/text candidates live on the DOM.
3. Logs the `UNIQUE Ã¢Å“â€œ` confirmed XPath.
4. Executes the requested action via the confirmed locator.

### `resolveConfirmedXpath`

| Signature | Description |
|---|---|
| `resolveConfirmedXpath(WebElement element)` | Tests XPath candidates against live DOM; returns first `UNIQUE Ã¢Å“â€œ` XPath string or `null`. |

Candidate priority: `@id` Ã¢â€ â€™ `@routerlink` Ã¢â€ â€™ `@href` (last segment) Ã¢â€ â€™ `normalize-space(.)` exact Ã¢â€ â€™ `normalize-space(.)` contains

---

## 24. Repeating Groups

For groups of homogeneous elements (e.g. tag chips, pills, list items with a shared partial id).

| Method | Signature | Description |
|---|---|---|
| `buildGroupItemXpath` | `buildGroupItemXpath(String idStem, String itemText)` | Builds `//*[contains(@id,'stem') and normalize-space(.)='text']` |
| `buildGroupListXpath` | `buildGroupListXpath(String idStem)` | Builds `//*[contains(@id,'stem')]` for the full group |
| `getGroupTexts` | `getGroupTexts(String idStem)` | Returns `List<String>` of all group item texts |
| `clickInGroupByText` | `clickInGroupByText(String idStem, String text)` | Clicks the group item whose text equals `text` |
| `findInGroupByText` | `findInGroupByText(String idStem, String text)` | Returns the `WebElement` matching `text`, or `null` |

**Example:**
```java
// Click a specific tag chip by text
clickInGroupByText("tag-chip", "Manhattan");

// Assert all expected tags are present
List<String> tags = getGroupTexts("tag-chip");
Assert.assertTrue(tags.contains("Manhattan"));
```

---

## 25. Bootstrap / Custom Dropdowns

For Bootstrap `dropdown-menu` and any `<ul>/<li>` custom dropdown (not `<select>`).

| Method | Signature | Description |
|---|---|---|
| `getDropdownMenuItems` | `getDropdownMenuItems(String menuId, String menuClass)` | Returns all `<li>` item texts from an open dropdown container identified by `id` or `class`. |
| `clickDropdownMenuItemByText` | `clickDropdownMenuItemByText(String menuId, String menuClass, String labelContains)` | Clicks the first `<li>` item whose text contains `labelContains`. Dynamic XPath scoped to container. |
| `clickDropdownOptionByRole` | `clickDropdownOptionByRole(String containerId, String itemRole, String labelContains)` | Iterates `role="option"` / `role="menuitem"` children of `containerId`; clicks matching item. |

**Example:**
```java
// Open Bootstrap dropdown then click item
fluentWaitUntilElementToBeClickable(reservationsToggle);
reservationsToggle.click();
clickDropdownMenuItemByText("nav-item-01", "dropdown-menu show", "New Reservation");

// Angular role-based option
clickDropdownOptionByRole("borough-panel", "option", "Manhattan");
```

---

## 26. Table Helpers

For HTML `<table>` elements (not Angular Material `mat-table`).

| Method | Signature | Description |
|---|---|---|
| `getTableRows` | `getTableRows(String tableXpath)` | Returns all body rows as `List<List<String>>` (each inner list = one row's cell texts). Logs every row. |
| `clickTableRowByColumnValue` | `clickTableRowByColumnValue(String tableXpath, int columnIndex, String value, String clickChildTag)` | Finds the first row where column `columnIndex` contains `value`; clicks the row or a child tag (`"a"`, `"button"`, etc.). |
| `getTableColumnValues` | `getTableColumnValues(String tableXpath, int columnIndex)` | Returns all values in a single column across all body rows. |

**Example:**
```java
// Get all rows from a reservation table
List<List<String>> rows = getTableRows("//table[@id='reservation-list']");

// Click the action link in the row where column 2 is "PENDING"
clickTableRowByColumnValue("//table[@id='reservation-list']", 2, "PENDING", "a");

// Assert a specific ID appears in column 0
List<String> ids = getTableColumnValues("//table[@id='reservation-list']", 0);
Assert.assertTrue(ids.contains("RES-001"));
```

---

## 27. Label Harvesters

For pages where form field identification relies on visible `<label>` text.

| Method | Signature | Description |
|---|---|---|
| `getPageLabels` | `getPageLabels(String scopeXpath)` | Returns `Map<String, WebElement>` (label text Ã¢â€ â€™ element) for all `<label>` elements inside `scopeXpath`. |
| `getPageLabels` | `getPageLabels()` | Whole-page overload Ã¢â‚¬â€ scans `//label`. |
| `getPageLabelTexts` | `getPageLabelTexts(String scopeXpath)` | Returns only `List<String>` of label texts. Useful for `Assert.assertEquals`. |

**Example:**
```java
// Assert expected labels are present on the enrollment form
List<String> expected = Arrays.asList("Pole ID", "Borough", "Street Name");
List<String> actual = getPageLabelTexts("//form[@id='enrollment-form']");
Assert.assertTrue(actual.containsAll(expected));

// Navigate to an input via its label's 'for' attribute
Map<String, WebElement> labels = getPageLabels("//form[@id='enrollment-form']");
WebElement poleIdLabel = labels.get("Pole ID");
String inputId = poleIdLabel.getAttribute("for");
WebElement poleInput = driver.findElement(By.id(inputId));
clearAndType(poleInput, "12345");
```

---

## 28. Collection Utilities

| Method | Signature | Description |
|---|---|---|
| `getElementTexts` | `getElementTexts(List<WebElement> elements)` | Extracts trimmed `getText()` from any `List<WebElement>`. Generic replacement for page-specific label collectors. |
| `listDifference` | `listDifference(List<String> listA, List<String> listB)` | Returns items present in `listA` but not in `listB` (non-destructive Ã¢â‚¬â€ operates on a copy of `listA`). |
| `safeAttr` | `safeAttr(WebElement element, String attribute)` | Returns `element.getAttribute(attribute)` or empty string if `null`. |
| `lastHrefSegment` | `lastHrefSegment(WebElement element)` | Returns the last path segment of the element's `href` attribute (e.g. `"enrollment"` from `/app/enrollment`). |

**Example:**
```java
// Compare rendered labels vs expected
List<String> rendered = getElementTexts(labelElements);
List<String> missing = listDifference(expectedLabels, rendered);
Assert.assertTrue("Missing labels: " + missing, missing.isEmpty());
```

*API Reference updated for SDK v1.2.5*

```java
// Ã¢Å“â€¦ Wait then read text
waitForElementPresent(driver, myElement);
String text = safeGetText(myElement);

// Ã¢Å“â€¦ Wait then click
fluentWaitUntilElementToBeClickable(myButton);
safeClick(myButton);

// Ã¢Å“â€¦ Type into a field
waitForElementPresent(driver, inputField);
clearAndType(inputField, "some value");

// Ã¢Å“â€¦ JavaScript click (for intercepted elements)
clickOnElementbyJavaScript(overlayButton);

// Ã¢Å“â€¦ Wait for page to settle after navigation
waitUntillPageLoad();

// Ã¢Å“â€¦ Wait for a spinner to disappear
waitForElementToDisappear(By.xpath("//mat-spinner"), 30);

// Ã¢Å“â€¦ Select from native dropdown
selectOptionInDropDownBox(statusDropdown, "Active");

// Ã¢Å“â€¦ Select from Angular Material mat-select
fluentWaitUntilElementToBeClickable(matSelectTrigger);
matSelectTrigger.click();
waitForElementPresent(driver, matOptionActive);
matOptionActive.click();

// Ã¢Å“â€¦ Assert text
verifyText("Expected Label", safeGetText(resultElement));
```

---

## Quick Reference Ã¢â‚¬â€ Test Class Cheat Sheet

```java
public class Test_MyFeature extends TestBase {

    @DataProvider(name = "myData")
    public Object[][] myData() throws IOException {
        return getData("MySheet");          // reads ExcelName set by @BeforeClass
    }

    @Test(dataProvider = "myData", priority = 1)
    public void testScenario(String testCaseName, String inputField, String runMode) throws Exception {
        if ("N".equalsIgnoreCase(runMode)) throw new SkipException("Skipping: " + testCaseName);

        step("Open the form page");
        MyPage page = new MyPage(driver);
        page.enterValue(inputField);

        step("Submit and verify result");
        page.clickSubmit();
        String result = safeGetText(page.resultLabel);
        verifyText("Success", result);
    }
}
```

---

*Generated for `functional-test-automation-sdk` v1.2.5 Ã¢â‚¬â€ `TestBase` class.*
